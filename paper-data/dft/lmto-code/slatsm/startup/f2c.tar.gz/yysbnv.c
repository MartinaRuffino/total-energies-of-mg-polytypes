/* yysbnv.f -- translated by f2c (version 19970805).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Table of constant values */

static integer c__0 = 0;
static integer c__1 = 1;
static logical c_true = TRUE_;
static doublereal c_b25 = -1.;
static doublereal c_b26 = 0.;
static doublereal c_b34 = 1.;

/* #define RECUR */
/* #define AIX */
/* #define RECUR */
/* Subroutine */ int yysbnv_(mode, apr, api, ldap, ija, offs, nlev, nn1, nn2, 
	w, ldw, ar, ai, lda, ierr)
integer *mode;
doublereal *apr, *api;
integer *ldap, *ija, *offs, *nlev, *nn1, *nn2;
doublereal *w;
integer *ldw;
doublereal *ar, *ai;
integer *lda, *ierr;
{
    /* System generated locals */
    integer ar_dim1, ar_offset, ai_dim1, ai_offset, w_dim1, w_offset, 
	    apr_dim1, apr_dim2, apr_offset, api_dim1, api_dim2, api_offset, 
	    i__1, i__2, i__3;

    /* Local variables */
    integer modl, nmin, mode0, mode1, i__, j, nnmin, m1, n1, n2, m2, nd;
    char cs[1];
    extern /* Subroutine */ int yysp2a_(), rx_();
    doublereal xx;
    extern /* Subroutine */ int isanrg_(), yygefa_(), yyhifa_(), yygedi_(), 
	    yyhidi_(), yygemm_();
    integer nm1, nm2;
    extern /* Subroutine */ int yymsbm_(), psybnv_(), yysbmm_(), yyqinv_();

/* - Inversion of a complex block sparse matrix using Strassen's algorithm
 */
/* ---------------------------------------------------------------- */
/* i Inputs: */
/* i   mode   :1s digit */
/* i           1 only the diagonal parts subblocks of matrix are complex 
*/
/* i             (only case tested so far) */
/* i           2 full matrix is complex */
/* i           3 matrix is hermetian (not tested) */
/* i          10s digit fixes how array is partitioned */
/* i             It is passed as first argument to psybnv */
/* i           0 partitions array into approximately equal numbers */
/* i             of nonzero subblocks */
/* i           1 partitions array into approximately equal dimensions */
/* i   nnmin  :fewest subblocks for which yysbnv calls itself recursively.
 */
/* i   ar,ai  :real,imaginary parts of matrix inverse */
/* i   lda    :leading dimension of ar,ai */
/* i   apr,api:real,imaginary parts of matrix subblocks; see Remarks */
/* i   ldap   :leading dimensions of apr,api */
/* i   ija    :column index packed array pointer data; see Remarks */
/* i   offs   :offsets to first entries in matrix subblocks. NB: offs(1)=0
 */
/* i           Subblock dimension of row(or col) i = offs(i+1) - offs(i) 
*/
/* i   nn1,nn2:range of subblocks which comprise the matrix to be inverted
 */
/* i           the matrix subblock to be inverted consist of the */
/* i           rows and columns  offs(nn1)+1...offs(nn2+1) */
/* i   nlev   :the maximum number of recursion levels allowed. */
/* i           To avoid roundoff errors, nlev=2 is suggested. */
/* i   w,ldw  :complex work array of dimension ldw*n */
/* o Outputs: */
/* o   ar,ai  :inverse of matrix, stored in a(i:j,i:j) with */
/* o           i = offs(nn1)+1 and j = offs(nn2+1). */
/* o   ierr is returned nonzero if matrix could not be inverted. */
/* r Remarks: */
/* r  *yysbnv uses the Strassen algorithm to invert a subblock of a matrix
 */
/* r   stored in block packed form.  The inverse is not assumed to be */
/* r   sparse, and is returned in conventional form in ar,ai.  Arrays */
/* r   ija,offs,apr,api contain data for the matrix; see yysp2a for a */
/* r   description of block matrix storage conventions, the use of these 
*/
/* r   arrays, and how a matrix subblock may be unpacked from them into */
/* r   conventional form. */
/* r */
/* r  *The matrix to be inverted comprises the rows (and columns) */
/* r   offs(nn1)+1...offs(nn2+1) of a.  ysqnv partitions these rows and */
/* r   columns into four subblocks a11,a21,a12,a22.  (See below for how */
/* r   the 1 and 2 partitions are apportioned.)  Let c be the inverse, */
/* r   with subblocks c11,c21,c12,c22.  Then inversion proceeds by: */
/* r      (1) invert   a22 (see below for recursive inversion) */
/* r      (2) generate (c11)^-1 = (a11 - a12 a22^-1 a21) */
/* r      (3) invert   (c11)^-1 */
/* r      (4) generate c21 = -(a22^-1 a21) c11 is */
/* r      (5) generate c12 = -c11 a12 a22^-1 is generated */
/* r      (6) generate c22 = a22^-1 + (a22^-1 a21 c11) (a12 a22^-1) */
/* r   These steps require two inversions, three sparse and three normal 
*/
/* r   multiplications. */
/* r */
/* r  *Partitioning into subblocks.  Partitions 1 and 2 consist of */
/* r   offs(nn1)+1...offs(nm1+1) and offs(nm1+1)+1...offs(nn2+1). */
/* r   nm1 is set in psybnv according to the 10s digit of mode. */
/* r */
/* r  *Inversion of the subblocks.  It is more efficient to allow */
/* r   inversion of a22 to proceed recursively, if your compiler allows */
/* r   it.  Recursion proceeds provided nlev>0, the number of subblocks */
/* r   exceeds nnmin and the dimension of the matrix to be inverted */
/* r   exceeds nmin.  (c11)^-1 is inverted calling yyqinv, which can */
/* r   also proceed recursively. */
/* b Bugs */
/* b   yysbnv has not been tested for the hermetian case, */
/* b   nor handle it efficiently. */
/* ---------------------------------------------------------------- */
/* #ifdefC DEBUG */
/*      character*10 fmt */
/*      data fmt /'(9f10.5)'/ */
/* #endif */
    /* Parameter adjustments */
    api_dim1 = *ldap;
    api_dim2 = *ldap;
    api_offset = api_dim1 * (api_dim2 + 1) + 1;
    api -= api_offset;
    apr_dim1 = *ldap;
    apr_dim2 = *ldap;
    apr_offset = apr_dim1 * (apr_dim2 + 1) + 1;
    apr -= apr_offset;
    ija -= 3;
    --offs;
    w_dim1 = *ldw;
    w_offset = w_dim1 + 1;
    w -= w_offset;
    ai_dim1 = *lda;
    ai_offset = ai_dim1 + 1;
    ai -= ai_offset;
    ar_dim1 = *lda;
    ar_offset = ar_dim1 + 1;
    ar -= ar_offset;

    /* Function Body */
    if (*nn1 > *nn2) {
	return 0;
    }
    *(unsigned char *)cs = ' ';
    if (*mode % 10 == 3) {
	*(unsigned char *)cs = 'h';
    }
    mode0 = *mode % 10;
    mode1 = *mode / 10 % 10;
    isanrg_(&mode1, &c__0, &c__1, "yysbnv:", "10s digit mode", &c_true, 7L, 
	    14L);
    modl = mode0 % 3 * 10;
/*     nmin = smallest rank below which standard inversion is used */
    nmin = 32;
/* --- Partition a into four subblocks according to 10s digit mode --- */
    psybnv_(&mode1, nn1, nn2, &ija[3], &offs[1], &nmin, &nm1, &nm2, &n1, &n2, 
	    &m1, &m2, &nd, &nnmin);
/* #ifdefC DEBUG */
/*      print 334, 'entering yysbnv ',mode,nlev,nn1,nm1,nn2,m1-n1,m2 */
/*  334 format(1x,a,': mode=',i2,': nlev=',i1, */
/*     .       '  nn1=',i2,'  nm1=',i2,'  nn2=',i2, */
/*     .       '  m1=',i3,'  m2=',i3) */
/* #endif */
/* --- Straight yygefa,di if n2 lt nmin --- */
    if (nd <= nmin) {
	yysp2a_(&mode0, nn1, nn2, nn1, nn2, &apr[apr_offset], &api[api_offset]
		, ldap, &ija[3], &offs[1], &ar[ar_offset], &ai[ai_offset], 
		lda);
	if (*(unsigned char *)cs != 'h' || nd == 1) {
	    yygefa_(&ar[n1 + 1 + (n1 + 1) * ar_dim1], &ai[n1 + 1 + (n1 + 1) * 
		    ai_dim1], lda, &nd, &w[w_offset], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    if (nd == 1) {
		yygedi_(&ar[n1 + 1 + (n1 + 1) * ar_dim1], &ai[n1 + 1 + (n1 + 
			1) * ai_dim1], lda, &nd, &w[w_offset], &xx, &w[(
			w_dim1 << 1) + 1], &xx, &c__1);
	    } else {
		yygedi_(&ar[n1 + 1 + (n1 + 1) * ar_dim1], &ai[n1 + 1 + (n1 + 
			1) * ai_dim1], lda, &nd, &w[w_offset], &xx, &w[(
			w_dim1 << 1) + 1], &w[w_dim1 * 3 + 1], &c__1);
	    }
	} else {
	    yyhifa_(&ar[n1 + 1 + (n1 + 1) * ar_dim1], &ai[n1 + 1 + (n1 + 1) * 
		    ai_dim1], lda, &nd, &w[w_offset], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    yyhidi_(&ar[n1 + 1 + (n1 + 1) * ar_dim1], &ai[n1 + 1 + (n1 + 1) * 
		    ai_dim1], lda, &nd, &w[w_offset], &xx, &i__, &w[(w_dim1 <<
		     1) + 1], &w[w_dim1 * 3 + 1], &c__1);
	    i__1 = n2;
	    for (i__ = n1 + 1; i__ <= i__1; ++i__) {
		i__2 = i__;
		for (j = n1 + 1; j <= i__2; ++j) {
		    ar[i__ + j * ar_dim1] = ar[j + i__ * ar_dim1];
/* L10: */
		    ai[i__ + j * ai_dim1] = -ai[j + i__ * ai_dim1];
		}
	    }
	}
/* #ifdefC DEBUG */
/*        print *, 'exit yysbnv, used standard LU decomposition' */
/* #endif */
	return 0;
    }
    if (*lda < n2) {
	rx_("yysbnv: lda lt n2", 17L);
    }
/* --- R1 = a22^-1 in a22 --- */
    if (m2 < nmin) {
	i__2 = nm1 + 1;
	i__1 = nm1 + 1;
	yysp2a_(&mode0, &i__2, nn2, &i__1, nn2, &apr[apr_offset], &api[
		api_offset], ldap, &ija[3], &offs[1], &ar[ar_offset], &ai[
		ai_offset], lda);
	if (*(unsigned char *)cs == 'h') {
	    yyhifa_(&ar[m1 + 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (m1 + 1) * 
		    ai_dim1], lda, &m2, &w[w_offset], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    yyhidi_(&ar[m1 + 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (m1 + 1) * 
		    ai_dim1], lda, &m2, &w[w_offset], &xx, &i__, &w[(w_dim1 <<
		     1) + 1], &w[w_dim1 * 3 + 1], &c__1);
	    i__2 = n2;
	    for (i__ = m1 + 1; i__ <= i__2; ++i__) {
		i__1 = i__;
		for (j = m1 + 1; j <= i__1; ++j) {
		    ar[i__ + j * ar_dim1] = ar[j + i__ * ar_dim1];
/* L12: */
		    ai[i__ + j * ai_dim1] = -ai[j + i__ * ai_dim1];
		}
	    }
	} else {
	    yygefa_(&ar[m1 + 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (m1 + 1) * 
		    ai_dim1], lda, &m2, &w[w_offset], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    yygedi_(&ar[m1 + 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (m1 + 1) * 
		    ai_dim1], lda, &m2, &w[w_offset], &xx, &w[(w_dim1 << 1) + 
		    1], &w[w_dim1 * 3 + 1], &c__1);
	}
/* #ifdef RECUR */
    } else if (nm2 > nnmin && *nlev > 0) {
	i__1 = *nlev - 1;
	i__2 = nm1 + 1;
	i__3 = *nn2;
	yysbnv_(mode, &apr[apr_offset], &api[api_offset], ldap, &ija[3], &
		offs[1], &i__1, &i__2, &i__3, &w[w_offset], ldw, &ar[
		ar_offset], &ai[ai_offset], lda, ierr);
/* #ifdef AIX | SUN-ULTRA */
	mode1 = *mode / 10 % 10;
	psybnv_(&mode1, nn1, nn2, &ija[3], &offs[1], &nmin, &nm1, &nm2, &n1, &
		n2, &m1, &m2, &nd, &nnmin);
/* #endif */
/* #ifdefC DEBUG */
/*        print 333, 'recursive call exit',nlev,n2-n1,m1-n1,m2 */
/* #endif */
/* #endif RECUR */
    } else {
	i__1 = nm1 + 1;
	i__2 = nm1 + 1;
	yysp2a_(&mode0, &i__1, nn2, &i__2, nn2, &apr[apr_offset], &api[
		api_offset], ldap, &ija[3], &offs[1], &ar[ar_offset], &ai[
		ai_offset], lda);
/* Computing MAX */
	i__2 = *nlev - 1;
	i__1 = max(i__2,0);
	yyqinv_(cs, &ar[m1 + 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (m1 + 1) * 
		ai_dim1], lda, &i__1, &m2, &w[w_offset], ldw, ierr, 1L);
    }
    if (*ierr != 0) {
	return 0;
    }
/*     call yprm(.false.,'R1',2,6,fmt,ar(1+m1,1+m1),lda,m2,lda,m2) */
/* --- R3 = a22^-1 a21 in w(2); uses w(1+m1:n2,1+n1+m1:n1+2*m1) --- */
/*     NB: R3 must be preserved to make c21 */
/*      call yygemm('N','N',m2,m1-n1,m2,1d0,ar(1+m1,1+m1),ai(1+m1,1+m1), 
*/
/*     .  lda,ar(1+m1,1+n1),ai(1+m1,1+n1),lda,0d0, */
/*     .  w(1+m1,1+n1),w(1+m1,1+n1+m1),ldw) */
    i__1 = nm1 + 1;
    yymsbm_(&modl, &i__1, nn2, nn1, &nm1, &m2, &apr[apr_offset], &api[
	    api_offset], ldap, &ija[3], &offs[1], &ar[m1 + 1 + ar_dim1], &ai[
	    m1 + 1 + ai_dim1], lda, &w[m1 + 1 + w_dim1], &w[m1 + 1 + (m1 + 1) 
	    * w_dim1], ldw);
/*     call yprm(.false.,'R3',2,6,fmt,w(1+m1,1),ldw,m2,m1,m1) */
/* --- R5 = (a11 - a12 a22^-1 a21) in a11 --- */
/*      call yygemm('N','N',m1-n1,m1-n1,m2,-1d0,ar(1+n1,1+m1), */
/*     .  ai(1+n1,1+m1),lda,w(1+m1,1+n1),w(1+m1,1+n1+m1),ldw,1d0, */
/*     .  ar(1+n1,1+n1),ai(1+n1,1+n1),lda) */
/*      call yprm(.false.,'R5',2,6,fmt,ar,lda,m1,lda,m1) */
    yysp2a_(&mode0, nn1, &nm1, nn1, &nm1, &apr[apr_offset], &api[api_offset], 
	    ldap, &ija[3], &offs[1], &ar[ar_offset], &ai[ai_offset], lda);
    i__1 = modl + 2;
    i__2 = nm1 + 1;
    i__3 = m1 - n1;
    yysbmm_(&i__1, nn1, &nm1, &i__2, nn2, &i__3, &apr[apr_offset], &api[
	    api_offset], ldap, &ija[3], &offs[1], &w[(n1 + 1) * w_dim1 + 1], &
	    w[(n1 + 1 + m1) * w_dim1 + 1], ldw, &ar[(n1 + 1) * ar_dim1 + 1], &
	    ai[(n1 + 1) * ai_dim1 + 1], lda);
/*     call yprm(.false.,'R5',2,6,fmt,ar,lda,m1,lda,m1) */
/* --- c11 = -R6 = -R5^-1 = (a11 - a12 a22^-1 a21)^-1 in a11 --- */
    if (m1 - n1 < nmin) {
	if (*(unsigned char *)cs == 'h') {
	    i__1 = m1 - n1;
	    yyhifa_(&ar[n1 + 1 + (n1 + 1) * ar_dim1], &ai[n1 + 1 + (n1 + 1) * 
		    ai_dim1], lda, &i__1, &w[w_offset], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    i__1 = m1 - n1;
	    yyhidi_(&ar[n1 + 1 + (n1 + 1) * ar_dim1], &ai[n1 + 1 + (n1 + 1) * 
		    ai_dim1], lda, &i__1, &w[w_offset], &xx, &i__, &w[(w_dim1 
		    << 1) + 1], &w[w_dim1 * 3 + 1], &c__1);
	    i__1 = n2;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		i__2 = i__;
		for (j = 1; j <= i__2; ++j) {
		    ar[i__ + j * ar_dim1] = ar[j + i__ * ar_dim1];
/* L16: */
		    ai[i__ + j * ai_dim1] = -ai[j + i__ * ai_dim1];
		}
	    }
	} else {
	    i__2 = m1 - n1;
	    yygefa_(&ar[n1 + 1 + (n1 + 1) * ar_dim1], &ai[n1 + 1 + (n1 + 1) * 
		    ai_dim1], lda, &i__2, &w[w_offset], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    i__2 = m1 - n1;
	    yygedi_(&ar[n1 + 1 + (n1 + 1) * ar_dim1], &ai[n1 + 1 + (n1 + 1) * 
		    ai_dim1], lda, &i__2, &w[w_offset], &xx, &w[(w_dim1 << 1) 
		    + 1], &w[w_dim1 * 3 + 1], &c__1);
	}
    } else {
/* Computing MAX */
	i__1 = *nlev - 1;
	i__2 = max(i__1,0);
	i__3 = m1 - n1;
	yyqinv_(cs, &ar[n1 + 1 + (n1 + 1) * ar_dim1], &ai[n1 + 1 + (n1 + 1) * 
		ai_dim1], lda, &i__2, &i__3, &w[w_offset], ldw, ierr, 1L);
    }
    if (*ierr != 0) {
	return 0;
    }
/*     call yprm(.false.,'-R6',2,6,fmt,ar,lda,m1,lda,m1) */
/* --- c21 = R3 * R6 = -a22^-1 a21 c11 in a21 --- */
    i__2 = m1 - n1;
    i__1 = m1 - n1;
    yygemm_("N", "N", &m2, &i__2, &i__1, &c_b25, &w[m1 + 1 + (n1 + 1) * 
	    w_dim1], &w[m1 + 1 + (n1 + 1 + m1) * w_dim1], ldw, &ar[n1 + 1 + (
	    n1 + 1) * ar_dim1], &ai[n1 + 1 + (n1 + 1) * ai_dim1], lda, &c_b26,
	     &ar[m1 + 1 + (n1 + 1) * ar_dim1], &ai[m1 + 1 + (n1 + 1) * 
	    ai_dim1], lda, 1L, 1L);
/*     call yprm(.false.,'c21',2,6,fmt,ar(1+m1,1),lda,m2,lda,m1) */
/* ... Possibly add a special branch for the hermetian case */
    if (FALSE_) {
    } else {
/*   --- R2 = a12 * a22^-1 in w(1) --- */
/*       call yygemm('N','N',m1-n1,m2,m2,1d0,ar(1+n1,1+m1), */
/*    .    ai(1+n1,1+m1),lda,ar(1+m1,1+m1),ai(1+m1,1+m1),lda,0d0, */
/*    .    w(1+n1,1),w(1+n1,1+m2),ldw) */
	i__2 = nm1 + 1;
	yysbmm_(&modl, nn1, &nm1, &i__2, nn2, &m2, &apr[apr_offset], &api[
		api_offset], ldap, &ija[3], &offs[1], &ar[(m1 + 1) * ar_dim1 
		+ 1], &ai[(m1 + 1) * ai_dim1 + 1], lda, &w[w_dim1 + 1], &w[(
		m2 + 1) * w_dim1 + 1], ldw);
/*       call yprm(.false.,'R2',2,6,fmt,w,ldw,m1,m2,m2) */
/*   --- c12 = R6 * R2 = -c11 a12 a22^-1 --- */
	i__2 = m1 - n1;
	i__1 = m1 - n1;
	yygemm_("N", "N", &i__2, &m2, &i__1, &c_b25, &ar[n1 + 1 + (n1 + 1) * 
		ar_dim1], &ai[n1 + 1 + (n1 + 1) * ai_dim1], lda, &w[n1 + 1 + 
		w_dim1], &w[n1 + 1 + (m2 + 1) * w_dim1], ldw, &c_b26, &ar[n1 
		+ 1 + (m1 + 1) * ar_dim1], &ai[n1 + 1 + (m1 + 1) * ai_dim1], 
		lda, 1L, 1L);
/*       call yprm(.false.,'c12',2,6,fmt,ar(1,1+m1),lda,m1,lda,m2) */
/*   --- c22 = R1 - c21 * R2 = a22^-1 + a22^-1 a21 c11 a12 a22^-1 --- 
*/
	i__2 = m1 - n1;
	yygemm_("N", "N", &m2, &m2, &i__2, &c_b25, &ar[m1 + 1 + (n1 + 1) * 
		ar_dim1], &ai[m1 + 1 + (n1 + 1) * ai_dim1], lda, &w[n1 + 1 + 
		w_dim1], &w[n1 + 1 + (m2 + 1) * w_dim1], ldw, &c_b34, &ar[m1 
		+ 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (m1 + 1) * ai_dim1], 
		lda, 1L, 1L);
    }
/* #ifdefC DEBUG */
/* C     call yprm(.false.,'a^-1',2,6,fmt,ar(1+n1,1+n1),lda,nd,lda,nd) */
/*      print 333, 'exiting  yysbnv',nlev,n2-n1,m1-n1,m2 */
/*  333 format(1x,a,': nlev=',i1,'  ndim=',i3,' partitioned into',2i3) */
/* #endif */
} /* yysbnv_ */

/* Subroutine */ int psybnv_(mode, nn1, nn2, ija, offs, nmin, nm1, nm2, n1, 
	n2, m1, m2, nd, nnmin)
integer *mode, *nn1, *nn2, *ija, *offs, *nmin, *nm1, *nm2, *n1, *n2, *m1, *m2,
	 *nd, *nnmin;
{
    /* System generated locals */
    integer i__1, i__2, i__3;

    /* Local variables */
    integer iblk, nblk, k, ic, ir;

/* - Return parameters that partition block sparse array into two parts */
/* ---------------------------------------------------------------------- 
*/
/* i Inputs */
/* i   mode:fixes how the array is partitioned */
/* i        mode=0 partitions array into approximately equal numbers */
/* i               of nonzero subblocks */
/* i        mode=1 partitions array into approximately equal dimensions */
/* i        mode>1 uses input nm1 */
/* i   nn1 :range of subblocks which comprise the matrix to be inverted */
/* r   nn2  the matrix subblock to be inverted consist of the */
/* r        rows and columns  offs(nn1)+1...offs(nn2+1) */
/* i   ija :column index packed array pointer data */
/* i   offs:table of offsets to array subblocks */
/* i   nmin:smallest rank below which standard inversion is used */
/* io Inputs/Outputs */
/* io  nm1 : number of blocks to lower partition of array; see Remarks */
/* io        How nm1 is set depends on mode. */
/* o Outputs */
/* o   nm1 : number of blocks to lower partition of array */
/* o   nm2 : number of blocks to upper partition of array */
/* o   n1  : offset to first column in array - 1 */
/* o   n2  : offset to last column in array */
/* o   m1  : dimension of lower partition + n1 */
/* o   m2  : dimension of upper partition */
/* o   nd  : dimension of the matrix to be inverted */
/* o  nnmin:fewest subblocks for which yysbnv calls itself recursively. */
/* r Remarks */
/* r   psybnv supplies parameters partitioning a array in block sparse */
/* r   format in two.  The array rows (or columns) may be described in */
/* r   terms of number of subblocks, with nn1 and nn2 input: */
/* r */
/* r            (1  nn1     nm1     nn2 ) */
/* r                        <-- nm2 --> */
/* r */
/* r   nm1 may be calculated internally or is input, depending on mode. */
/* r   In terms of true array dimensions, the parameters are: */
/* r */
/* r            (1  n1      m1      n2 ) */
/* r                <------ nd ------> */
/* r                        <-- m2 --> */
/* r */
/* u Updates */
/* ---------------------------------------------------------------------- 
*/
    /* Parameter adjustments */
    --offs;
    ija -= 3;

    /* Function Body */
    if (*nn2 > *nn1) {
	if (*mode == 0) {
/*   --- Partition into approx. equal nonzero subblocks --- */
	    nblk = 0;
	    i__1 = *nn2;
	    for (ir = *nn1; ir <= i__1; ++ir) {
		++nblk;
		i__2 = ija[(ir + 1 << 1) + 1] - 1;
		for (k = ija[(ir << 1) + 1]; k <= i__2; ++k) {
		    ic = ija[(k << 1) + 1];
		    if (ic < *nn1 || ic > *nn2) {
			goto L11;
		    }
		    ++nblk;
L11:
		    ;
		}
/* L10: */
	    }
/* ...   Count to half the total number of subblocks */
	    iblk = 0;
	    i__1 = *nn2;
	    for (ir = *nn1; ir <= i__1; ++ir) {
		++iblk;
		i__2 = ija[(ir + 1 << 1) + 1] - 1;
		for (k = ija[(ir << 1) + 1]; k <= i__2; ++k) {
		    ic = ija[(k << 1) + 1];
		    if (ic < *nn1 || ic > *nn2) {
			goto L21;
		    }
		    ++iblk;
L21:
		    ;
		}
		if (iblk << 1 > nblk) {
		    *nm1 = ir - 1;
		    goto L22;
		}
/* L20: */
	    }
L22:
/* --- Partition into approximately equal dimensions --- */
	    ;
	} else if (*mode == 1) {
	    *nd = (offs[*nn2 + 1] + offs[*nn1]) / 2;
/* Computing MIN */
	    i__1 = (*nn1 + *nn2) / 2 + 1;
	    *nm1 = min(i__1,*nn2);
L31:
	    if (offs[*nm1] < *nd) {
		++(*nm1);
		goto L31;
	    }
L32:
	    if ((i__1 = offs[*nm1] - *nd, abs(i__1)) > (i__2 = offs[*nm1 - 1] 
		    - *nd, abs(i__2))) {
		--(*nm1);
		if (*nm1 > 1) {
		    goto L32;
		}
	    }
	    --(*nm1);
	}
    }
/* Computing MAX */
/* Computing MIN */
    i__2 = *nm1, i__3 = *nn2 - 1;
    i__1 = min(i__2,i__3);
    *nm1 = max(i__1,*nn1);
    *nm2 = *nn2 - *nm1;
    *n1 = offs[*nn1];
    *n2 = offs[*nn2 + 1];
    *nd = *n2 - *n1;
    *m1 = offs[*nm1 + 1];
    *m2 = *n2 - *m1;
/* ... Find some reasonable nnmin */
    *nnmin = 0;
L40:
    ++(*nnmin);
    if (*nnmin < *nn2) {
	if (offs[*nnmin + 1] < *nmin) {
	    goto L40;
	}
    }
    --(*nnmin);
} /* psybnv_ */

