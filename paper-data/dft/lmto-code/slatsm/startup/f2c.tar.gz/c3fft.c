/* djohn.f -- translated by f2c (version 19970805).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    integer ims, ivs, ies, nm, nv, ne, mx, lx, mlim, mstep, llim, lstep, 
	    nustep, ivlim, ilim, md2lim, ld2lim;
} mfftpa_;

#define mfftpa_1 mfftpa_

/* Table of constant values */

static integer c__0 = 0;
static integer c__1 = 1;

/* Subroutine */ int c2fft_(c__, id, nm, nn, wm, wn, isig, iord, iwork, ierr)
doublecomplex *c__;
integer *id, *nm, *nn;
doublereal *wm, *wn;
integer *isig, *iord, *iwork, *ierr;
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    extern /* Subroutine */ int mfftp_(), mfftz0_(), mfftdv_(), mfftiv_(), 
	    mfftov_();

/* ***purpose: */
/*       this routine performs a 2-dimensional complex fourier transform, 
*/
/*       of order nm*nn. */
/* ***usage: */
/*       the user is expected to provide the data in a 2-dimensional */
/*       complex array c, dimensioned in the calling program c(id,nn); */
/*       id can be different from nm, and it is recommended that it is */
/*       chosen equal to nm+1 if nm is even or to nm if nm is odd. */
/*       the elements c(k,*),nm<k<=id must be zeroed. the routine is */
/*       intended for repeated usage, thus separate set-up and */
/*       operating calls are available : the user should always perform */
/*       a set-up call ( isig=0 ) passing the chosen parameters, before */
/*       performing the actual transform ( isig= +1 or -1 ); the user can 
*/
/*       choose whether to obtain the results of the direct transform */
/*       in natural order (isig=-1,iord=1) or leave them in the */
/*      'bit-reversed' order( isig=-1,iord=0); this choice saves */
/*       some computer time, and it is recommended in cases discussed */
/*       in the long write-up. analogously,the inverse transform accepts 
*/
/*       input ( please note! ) data in natural order ( isig=1,iord=1), */
/*       or data already subjected to a bit-reversal permutation( isig=1 
*/
/*       iord=0 ). */
/* ***parameters : */
/*       input : */
/*       c : array to be transformed; declared complex c(id,nn) in the */
/*           calling program; */
/*       id : first dimension of c in the calling program */
/*       isig : option flag : isig=0 : set-up run, c not used */
/*                            isig=-1: direct transform */
/*                            isig=+1: inverse transform */
/*       wm,wn : integer arrays , used to host tables for the transform; 
*/
/*               dimensioned in the calling program at least (4*nm+14) */
/*               and (4*nn+14) respectively; if isig.ne.0 ,they are */
/*               assumed to have been set by a previous call with isig=0 
*/
/*               (all other arguments unchanged), and never have been */
/*               modified since then; */
/*               if nm=nn, wm and wn do not need to be distinct; */
/*       nm : order of the transform along the columns of c */
/*       nn : order of the transform along the rows of c */
/*       iord : option flag : =1 : output in natural order (isig=-1) */
/*                                 input in natural order  (isig=+1) */
/*                            =0 : output in bit-reversed order(isig=-1) 
*/
/*                                 input in bit-reversed order(isig=+1) */
/*       iwork : integer array, used as work area for reordering if iord= 
*/
/*                1, it must be at least max(nm,nn) words long. */
/*                it is unused if iord=0. */

/* ***output : */
/*       c : transformed array */
/*       wm, wn : only if isig=0, wm and wn are filled with the */
/*               appropriate  tables (twiddle factors). */
/*       iwork : undefined */
/*       ierr  : error code : =0 : successful */
/*                            =1 : data dimensions are not correct */
/*                            =2 : prime factors different from 2,3,5 */
/*                                 are present in data dimensions */
/*                            =3 : tables not correctly initialized */

    /* Parameter adjustments */
    --iwork;
    wn -= -14;
    wm -= -14;
    --c__;

    /* Function Body */
    if (*id < *nm) {
	*ierr = 1;
	return 0;
    }
    *ierr = 0;
    if (*isig == 0) {
	mfftp_(nm, wm, &wm[-14], &c__0, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	if (*nn != *nm) {
	    mfftp_(nn, wn, &wn[-14], &c__0, ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	} else {
	    i__1 = (*nm << 1) + 7;
	    mfftz0_(&wm[-14], &c__1, &i__1, &wn[-14], &c__1);
	}
	return 0;
    } else if (*isig > 0) {
	if (*iord != 0) {
	    mfftov_(&c__[1], &c__1, id, nm, nn, &wm[*nm * 3], &iwork[1]);
	    mfftov_(&c__[1], id, &c__1, nn, nm, &wn[*nn * 3], &iwork[1]);
	}
	mfftiv_(&c__[1], &c__1, id, nm, nn, &wm[-14], wm, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	mfftiv_(&c__[1], id, &c__1, nn, nm, &wn[-14], wn, ierr);
	if (*ierr != 0) {
	    return 0;
	}
    } else {
	mfftdv_(&c__[1], &c__1, id, nm, nn, &wm[-14], wm, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	mfftdv_(&c__[1], id, &c__1, nn, nm, &wn[-14], wn, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	if (*iord != 0) {
	    mfftov_(&c__[1], &c__1, id, nm, nn, &wm[*nm * 2], &iwork[1]);
	    mfftov_(&c__[1], id, &c__1, nn, nm, &wn[*nn * 2], &iwork[1]);
	}
    }
} /* c2fft_ */

/* Subroutine */ int c3fft_(c__, id, nl, nm, nn, wl, wm, wn, iopt, isig, iord,
	 iwork, ierr)
doublecomplex *c__;
integer *id, *nl, *nm, *nn;
doublereal *wl, *wm, *wn;
integer *iopt, *isig, *iord, *iwork, *ierr;
{
    /* System generated locals */
    integer i__1, i__2;

    /* Local variables */
    extern /* Subroutine */ int mfftp_(), mfftz0_(), mfftdm_(), mfftim_(), 
	    mfftds_(), mfftdv_(), mfftom_(), mfftis_(), mfftiv_(), mfftov_();

/* ***purpose: */
/*       this routine performs a 3-dimensional complex fourier transform, 
*/
/*       of order nl*nm*nn  . */
/*       it is a user interface for a package (mfft), specially designed 
*/
/*       for high performance on cray x-mp machines. */
/* ***usage: */
/*       the user is expected to provide the data in a 3-dimensional */
/*       complex array c, dimensioned in the calling program c(id,nm,nn); 
*/
/*       id can be different from nl, and it is recommended that it is */
/*       chosen odd for maximum performance. the routine is */
/*       intended for repeated usage, thus separate set-up and */
/*       operating calls are available : the user should always perform */
/*       a set-up call ( isig=0 ) passing the chosen parameters, before */
/*       performing the actual transform ( isig= +1 or -1 ); the user can 
*/
/*       choose whether to obtain the results of the direct transform */
/*       in natural order (isig=-1,iord=1) or leave them in the */
/*       bit-reversed  order( isig=-1,iord=0); this choice saves */
/*       some computer time, and it is recommended in cases discussed */
/*       in the long write-up. analogously, the inverse transform accepts 
*/
/*       input ( please note! ) data in natural order ( isig=1,iord=1), */
/*       or data already subjected to a bit-reversal permutation( isig=1 
*/
/*       iord=0). */
/*       a special treatment is available to speed up the transform of */
/*       small matrices. this treatment is activated by the flag iopt. in 
*/
/*       this case the tables for the second dimension ( wm ) are larger, 
*/
/*       but the increase in performance is substantial when nm<32. */
/* ***arguments : */
/*       input : */
/*       c : array to be transformed; declared complex c(id,nm,nn) in the 
*/
/*           calling program; */
/*       id : first dimension of c in the calling program */
/*       isig : option flag : isig=0 : set-up run, c not used */
/*                            isig=-1: direct transform */
/*                            isig=+1: inverse transform */
/*       wl,wm,wn : integer arrays,used to host tables for the transforms 
*/
/*               dimensioned in the calling program at least (4*nl+14) */
/*               (4*nm+14) and (4*nn+14) respectively; if iopt=1 */
/*               wm must be dimensioned at least (4*nm*(id+1)+14) */
/*               if isig.ne.0, they are assumed to have been set by a */
/*               previous call with isig=0 and other arguments equal, and 
*/
/*               never have been modified ; */
/*               when the corresponding orders are equal, they do not */
/*               need to be distinct. */
/*       nl : order of the transform along the columns of c */
/*       nm : order of the transform along the rows of c */
/*       nn : order of the transform along the third dimension of c */
/*       iopt : option flag : =0 : normal treatment */
/*                            =1 : special treatment for improving */
/*                                 vectorization on matrices with */
/*                                 small nl; requires long wm(see);if */
/*                                 requested, must be present in both */
/*                                 the set-up and transform calls; */
/*       iord : option flag : =1 : output in natural order (isig=-1) */
/*                                 input in natural order  (isig=+1) */
/*                            =0 : output in bit-reversed order(isig=-1) 
*/
/*                                 input in bit-reversed order(isig=+1) */
/*       iwork : integer array, used as work area for reordering if */
/*               iord=1; it must be at least max(nl,nm,nn) words long. */

/*        output : */
/*       c : transformed array */
/*       wl, wm, wn : only if isig=0, wl,wm and wn are filled with the */
/*                     appropriate tables */
/*       iwork : undefined */
/*       ierr  : error code : =0 : successful */
/*                          : =1 : data dimensions are not correct */
/*                            =2 : prime factors different from 2,3,5 */
/*                                 are present in data dimensions */
/*                            =3 : tables not correctly initialized */
    /* Parameter adjustments */
    --iwork;
    wn -= -14;
    wm -= -14;
    wl -= -14;

    /* Function Body */
    if (*id < *nl) {
	*ierr = 1;
	return 0;
    }
    *ierr = 0;
    if (*isig == 0) {
	i__1 = *id * *iopt;
	mfftp_(nm, wm, &wm[-14], &i__1, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	if (*nm != *nn) {
	    mfftp_(nn, wn, &wn[-14], &c__0, ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	} else {
	    i__1 = (*nm << 1) + 7;
	    mfftz0_(&wm[-14], &c__1, &i__1, &wn[-14], &c__1);
	}
	if (*nl == *nm) {
	    i__1 = (*nm << 1) + 7;
	    mfftz0_(&wm[-14], &c__1, &i__1, &wl[-14], &c__1);
	} else if (*nl == *nn) {
	    i__1 = (*nn << 1) + 7;
	    mfftz0_(&wn[-14], &c__1, &i__1, &wl[-14], &c__1);
	} else {
	    mfftp_(nl, wl, &wl[-14], &c__0, ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	}
	return 0;
    } else if (*isig > 0) {
	if (*iord != 0) {
	    i__1 = *nm * *nn;
	    mfftov_(c__, &c__1, id, nl, &i__1, &wl[*nl * 3], &iwork[1]);
	    i__1 = *id * *nm;
	    i__2 = *id * *nm;
	    mfftov_(c__, &i__1, &c__1, nn, &i__2, &wn[*nn * 3], &iwork[1]);
	    i__1 = *id * *nm;
	    mfftom_(c__, id, &i__1, &c__1, nm, nn, nl, &wm[*nm * 3], &iwork[1]
		    );
	}
	i__1 = *nm * *nn;
	mfftiv_(c__, &c__1, id, nl, &i__1, &wl[-14], wl, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	if (*iopt == 0) {
	    i__1 = *id * *nm;
	    mfftim_(c__, id, &i__1, &c__1, nm, nn, nl, &wm[-14], wm, ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	} else {
	    i__1 = *id * *nm;
	    mfftis_(c__, id, &i__1, &c__1, nm, nn, nl, &wm[-14], wm, ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	}
	i__1 = *id * *nm;
	i__2 = *id * *nm;
	mfftiv_(c__, &i__1, &c__1, nn, &i__2, &wn[-14], wn, ierr);
	if (*ierr != 0) {
	    return 0;
	}
    } else {
	i__1 = *nm * *nn;
	mfftdv_(c__, &c__1, id, nl, &i__1, &wl[-14], wl, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	if (*iopt == 0) {
	    i__1 = *id * *nm;
	    mfftdm_(c__, id, &i__1, &c__1, nm, nn, nl, &wm[-14], wm, ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	} else {
	    i__1 = *id * *nm;
	    mfftds_(c__, id, &i__1, &c__1, nm, nn, nl, &wm[-14], wm, ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	}
	i__1 = *id * *nm;
	i__2 = *id * *nm;
	mfftdv_(c__, &i__1, &c__1, nn, &i__2, &wn[-14], wn, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	if (*iord != 0) {
	    i__1 = *nm * *nn;
	    mfftov_(c__, &c__1, id, nl, &i__1, &wl[*nl * 2], &iwork[1]);
	    i__1 = *id * *nm;
	    i__2 = *id * *nm;
	    mfftov_(c__, &i__1, &c__1, nn, &i__2, &wn[*nn * 2], &iwork[1]);
	    i__1 = *id * *nm;
	    mfftom_(c__, id, &i__1, &c__1, nm, nn, nl, &wm[*nm * 2], &iwork[1]
		    );
	}
    }
} /* c3fft_ */

/* Subroutine */ int r2fft_(c__, id, nm, nn, wm, wn, isig, iord, iwork, ierr)
doublecomplex *c__;
integer *id, *nm, *nn;
doublereal *wm, *wn;
integer *isig, *iord, *iwork, *ierr;
{
    /* System generated locals */
    integer i__1, i__2;

    /* Local variables */
    extern /* Subroutine */ int mfftp_(), mfftz0_(), mfftrd_(), mfftdv_(), 
	    mfftri_(), mfftiv_(), mfftrp_(), mfftov_();
    integer nm1;


/* ***purpose: */
/*       this routine performs a 2-dimensional real fourier transform, */
/*       of order nm*nn. */
/* ***usage: */
/*       the user is expected to provide the data in a 2-dimensional */
/*       real array c, dimensioned in the calling program c(id,nn) */
/*       and equivalenced to a complex array ccom(id/2,nn). */
/*       when a direct trasnform is performed, half of the output */
/*       coefficients are contained in ccom(i,j) as follows */
/*        x(i,j)= ccom(i,j) with i=1,(nm/2+1) and j=1,nn */
/*       the remaining ones are obtained exploiting the conjugated */
/*       symmetry relation */
/*        x(i,j) = conjg(ccom(nm-i+2,1+mod(nn-j+1,nn))) */
/*       with i=nm/2+2,nm  and  j=1,nn */
/*       nm (actual first dimension of data) must be an even number; */
/*       id (declared first dimension) must be gr. or eq. to nm+2. */
/*       the elements c(k,*), nm<k<=id must be zeroed. the routine is */
/*       intended for repeated usage, thus separate set-up and */
/*       operating calls are available : the user should always perform */
/*       a set-up call ( isig=0 ) passing the chosen parameters, before */
/*       performing the actual transform ( isig= +1 or -1 ); the user can 
*/
/*       choose whether to obtain the results of the direct transform */
/*       in natural order (isig=-1,iord=1) or leave them in the */
/*       bit-reversed  order( isig=-1,iord=0); this choice saves */
/*       some computer time, and it is recommended in cases discussed */
/*       in the long write-up. analogously, the inverse transform accepts 
*/
/*       input ( please note! ) data in natural order ( isig=1,iord=1), */
/*       or data already subjected to a bit-reversal permutation( isig=1 
*/
/*       iord=0 ). */
/* ***parameters : */
/*       input : */
/*       c : array to be transformed; declared real c(id,nn) in the */
/*           calling program; */
/*       id : first dimension of c in the calling program */
/*            it must be an even number equal to nm+2. */
/*       isig : option flag : isig=0 : set-up run, c not used */
/*                            isig=-1: direct transform */
/*                            isig=+1: inverse transform */
/*       wm,wn : integer arrays , used to host tables for the transform; 
*/
/*               dimensioned in the calling program in this way : */
/*               wm : at least (6*nm+14) */
/*               wn : at least (4*nn+14) */
/*               if isig.ne.0 ,they are assumed to have been set */
/*                by a previous call with isig=0 and */
/*               all the other arguments unchanged, and never have been */
/*               modified since then; */
/*               if nm=nn, wm and wn do not need to be distinct; */
/*       nm : order of the transform along the columns of c */
/*       nn : order of the transform along the rows of c */
/*       iord : option flag : =1 : output in natural order (isig=-1) */
/*                                 input in natural order  (isig=+1) */
/*                            =0 : output in bit-reversed order(isig=-1) 
*/
/*                                 input in bit-reversed order(isig=+1) */
/*                                 warning:the first dimension is ordered 
*/
/*                                 in any case because of post-processing 
*/
/*                                 (for direct) and pre-processing for */
/*                                 inverse real transforms */
/*       iwork : integer array, used as work area for reordering if iord= 
*/
/*               1, must be at least max(nm,nn) words long. */

/* ***output : */
/*       c : transformed array */
/*       wm, wn : only if isig=0, wm and wn are filled with the */
/*               appropriate  tables */
/*       iwork : undefined */
/*       ierr  : error code : =0 : successful */
/*                            =1 : wrong id parameter */
/*                            =2 : prime factors different from 2,3,5 */
/*                                 are present in data dimensions */
/*                            =3 : tables not correctly initialized */
/*                            =4 : first dimension is an odd number */


    /* Parameter adjustments */
    --iwork;
    wn -= -14;
    wm -= -14;
    --c__;

    /* Function Body */
    if (*id < *nm + 2) {
	*ierr = 1;
	return 0;
    }
    nm1 = *nm / 2;
    if (nm1 << 1 != *nm) {
	*ierr = 4;
	return 0;
    }
    *ierr = 0;

    if (*isig == 0) {
	mfftrp_(nm, &wm[*nm * 4]);
	mfftp_(&nm1, wm, &wm[-14], &c__0, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	if (*nn != nm1) {
	    mfftp_(nn, wn, &wn[-14], &c__0, ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	} else {
	    i__1 = (nm1 << 1) + 7;
	    mfftz0_(&wm[-14], &c__1, &i__1, &wn[-14], &c__1);
	}
	return 0;
    } else if (*isig > 0) {
	if (*iord != 0) {
	    i__1 = *id / 2;
	    i__2 = nm1 + 1;
	    mfftov_(&c__[1], &i__1, &c__1, nn, &i__2, &wn[*nn * 3], &iwork[1])
		    ;
	}
	i__1 = *id / 2;
	i__2 = nm1 + 1;
	mfftiv_(&c__[1], &i__1, &c__1, nn, &i__2, &wn[-14], wn, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	i__1 = *id / 2;
	mfftri_(&c__[1], &c__1, &i__1, &nm1, nn, &wm[*nm * 4]);
	i__1 = *id / 2;
	mfftov_(&c__[1], &c__1, &i__1, &nm1, nn, &wm[nm1 * 3], &iwork[1]);
	i__1 = *id / 2;
	mfftiv_(&c__[1], &c__1, &i__1, &nm1, nn, &wm[-14], wm, ierr);
	if (*ierr != 0) {
	    return 0;
	}
    } else {
	i__1 = *id / 2;
	mfftdv_(&c__[1], &c__1, &i__1, &nm1, nn, &wm[-14], wm, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	i__1 = *id / 2;
	mfftov_(&c__[1], &c__1, &i__1, &nm1, nn, &wm[nm1 * 2], &iwork[1]);
	i__1 = *id / 2;
	mfftrd_(&c__[1], &c__1, &i__1, &nm1, nn, &wm[*nm * 4]);
	i__1 = *id / 2;
	i__2 = nm1 + 1;
	mfftdv_(&c__[1], &i__1, &c__1, nn, &i__2, &wn[-14], wn, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	if (*iord != 0) {
	    i__1 = *id / 2;
	    i__2 = nm1 + 1;
	    mfftov_(&c__[1], &i__1, &c__1, nn, &i__2, &wn[*nn * 2], &iwork[1])
		    ;
	}

    }

} /* r2fft_ */

/*     ###########    fft1 ends here     ################### */
/* Subroutine */ int r3fft_(c__, id, nl, nm, nn, wl, wm, wn, iopt, isig, iord,
	 iwork, ierr)
doublecomplex *c__;
integer *id, *nl, *nm, *nn;
doublereal *wl, *wm, *wn;
integer *iopt, *isig, *iord, *iwork, *ierr;
{
    /* System generated locals */
    integer i__1, i__2, i__3;

    /* Local variables */
    integer nmpn;
    extern /* Subroutine */ int mfftp_(), mfftz0_(), mfftdm_(), mfftim_(), 
	    mfftrd_(), mfftds_(), mfftdv_(), mfftri_(), mfftom_(), mfftis_(), 
	    mfftiv_(), mfftrp_(), mfftov_();
    integer nl1;


/* ***purpose: */
/*       this routine performs a 3-dimensional real fourier transform, */
/*       of order nl*nm*nn  . */
/* ***usage: */
/*       the user is expected to provide the data in a 3-dimensional */
/*       real array c, dimensioned in the calling program c(id,nm,nn); */
/*       id has to be an even integer, equal to nl+2. */
/*       for output data arrengement see notes to r2fft here above. */
/*       this routine is */
/*       intended for repeated usage, thus separate set-up and */
/*       and operating calls are available: the user should in any case */
/*       perform a set-up call (isig=0) passing the parameters before */
/*       performing an actual transform ( isig= +1 or -1 ); the user can 
*/
/*       choose whether to obtain the results of the direct transform */
/*       in natural order (isig=-1,iord=1) or leave them in the */
/*       bit-reversed  order( isig=-1,iord=0); this choice saves */
/*       some computer time, and it is recommended in cases discussed */
/*       in the long write-up. analogously, the inverse transform accepts 
*/
/*       input ( please note! ) data in natural order ( isig=1,iord=1), */
/*       or data already subjected to a bit-reversal permutation( isig=1 
*/
/*       iord=0). */
/*       a special treatment is available to speed up the transform of */
/*       small matrices. this treatment is activated by the flag iopt. in 
*/
/*       this case the tables for the second dimension ( wm ) are larger, 
*/
/*       but the increase in performance is substantial when nm<32. */
/* ***arguments : */
/*       input : */
/*       c : array to be transformed; declared complex c(id,nm,nn) in the 
*/
/*           calling program; */
/*       id : first dimension of c in the calling program */
/*            it has to be an even integer .ge. nl+2. */
/*       isig : option flag : isig=0 : set-up run, c not used */
/*                            isig=-1: direct transform */
/*                            isig=+1: inverse transform */
/*       wl,wm,wn : integer arrays,used to host tables for the transforms 
*/
/*               dimensioned in the calling program at least (6*nl+14) */
/*               (4*nm+14) and (4*nn+14) respectively; if */
/*               iopt=1, wm must be dimensioned at least 4*nm*(id/2+1)+14 
*/
/*               if isig.ne.0, they are assumed to have been set by a */
/*               previous call with isig=0 and other arguments equal, and 
*/
/*               never have been modified ; */
/*               when the corresponding orders are equal, they do not */
/*               need to be distinct */
/*       nl : order of the transform along the columns of c */
/*            it has to be an even integer. */
/*       nm : order of the transform along the rows of c */
/*       nn : order of the transform along the third dimension of c */
/*       iopt : option flag : =0 : normal treatment */
/*                            =1 : special treatment for improving */
/*                                 vectorization on matrices with */
/*                                 small nl; requires long wm(see);if */
/*                                 requested, must be present in both */
/*                                 the set-up and transform calls; */
/*       iord : option flag : =1 : output in natural order (isig=-1) */
/*                                 input in natural order  (isig=+1) */
/*                            =0 : output in bit-reversed order(isig=-1) 
*/
/*                                 input in bit-reversed order(isig=+1) */
/*       iwork : integer array, used as work area for reordering if */
/*               iord=1; it must be at least max(nl,nm,nn) words long. */

/*        output : */
/*       c : transformed array */
/*       wl, wm, wn : only if isig=0, wl,wm and wn are filled with the */
/*                     appropriate tables */
/*       iwork : undefined */
/*       ierr  : error code : =0 : successful */
/*                            =1 : wrong id parameter */
/*                            =2 : prime factors different from 2,3,5 */
/*                                 are present in data dimensions */
/*                            =3 : tables not correctly initialized */
/*                            =4 : first dimension is an odd number */




    /* Parameter adjustments */
    --iwork;
    wn -= -14;
    wm -= -14;
    wl -= -14;
    --c__;

    /* Function Body */
    if (*id < *nl + 2) {
	*ierr = 1;
	return 0;
    }
    nl1 = *nl / 2;
    if (nl1 << 1 != *nl) {
	*ierr = 4;
	return 0;
    }
    *ierr = 0;
    nmpn = *nm * *nn;


    if (*isig == 0) {
	i__1 = *id / 2 * *iopt;
	mfftp_(nm, wm, &wm[-14], &i__1, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	mfftrp_(nl, &wl[*nl * 4]);
	if (nl1 != *nm) {
	    mfftp_(&nl1, wl, &wl[-14], &c__0, ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	} else {
	    i__1 = (*nm << 1) + 7;
	    mfftz0_(&wm[-14], &c__1, &i__1, &wl[-14], &c__1);
	}

	if (*nm == *nn) {
	    i__1 = (*nm << 1) + 7;
	    mfftz0_(&wm[-14], &c__1, &i__1, &wn[-14], &c__1);
	} else if (*nn == nl1) {
	    i__1 = (nl1 << 1) + 7;
	    mfftz0_(&wl[-14], &c__1, &i__1, &wn[-14], &c__1);
	} else {
	    mfftp_(nn, wn, &wn[-14], &c__0, ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	}
	return 0;

    } else if (*isig > 0) {

	if (*iord != 0) {
	    i__1 = *id / 2;
	    i__2 = *id / 2 * *nm;
	    i__3 = nl1 + 1;
	    mfftom_(&c__[1], &i__1, &i__2, &c__1, nm, nn, &i__3, &wm[*nm * 3],
		     &iwork[1]);
	    i__1 = *id / 2 * *nm;
	    i__2 = *id / 2 * *nm;
	    mfftov_(&c__[1], &i__1, &c__1, nn, &i__2, &wn[*nn * 3], &iwork[1])
		    ;
	}

	i__1 = *id / 2 * *nm;
	i__2 = *id / 2 * *nm;
	mfftiv_(&c__[1], &i__1, &c__1, nn, &i__2, &wn[-14], wn, ierr);
	if (*ierr != 0) {
	    return 0;
	}

	if (*iopt == 0) {
	    i__1 = *id / 2;
	    i__2 = *id / 2 * *nm;
	    i__3 = nl1 + 1;
	    mfftim_(&c__[1], &i__1, &i__2, &c__1, nm, nn, &i__3, &wm[-14], wm,
		     ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	} else {
	    i__1 = *id / 2;
	    i__2 = *id / 2 * *nm;
	    i__3 = nl1 + 1;
	    mfftis_(&c__[1], &i__1, &i__2, &c__1, nm, nn, &i__3, &wm[-14], wm,
		     ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	}

	i__1 = *id / 2;
	mfftri_(&c__[1], &c__1, &i__1, &nl1, &nmpn, &wl[*nl * 4]);
	i__1 = *id / 2;
	mfftov_(&c__[1], &c__1, &i__1, &nl1, &nmpn, &wl[nl1 * 3], &iwork[1]);
	i__1 = *id / 2;
	mfftiv_(&c__[1], &c__1, &i__1, &nl1, &nmpn, &wl[-14], wl, ierr);
	if (*ierr != 0) {
	    return 0;
	}


    } else {


	i__1 = *id / 2;
	mfftdv_(&c__[1], &c__1, &i__1, &nl1, &nmpn, &wl[-14], wl, ierr);
	if (*ierr != 0) {
	    return 0;
	}
	i__1 = *id / 2;
	mfftov_(&c__[1], &c__1, &i__1, &nl1, &nmpn, &wl[nl1 * 2], &iwork[1]);
	i__1 = *id / 2;
	mfftrd_(&c__[1], &c__1, &i__1, &nl1, &nmpn, &wl[*nl * 4]);


	if (*iopt == 0) {
	    i__1 = *id / 2;
	    i__2 = *id / 2 * *nm;
	    i__3 = nl1 + 1;
	    mfftdm_(&c__[1], &i__1, &i__2, &c__1, nm, nn, &i__3, &wm[-14], wm,
		     ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	} else {
	    i__1 = *id / 2;
	    i__2 = *id / 2 * *nm;
	    i__3 = nl1 + 1;
	    mfftds_(&c__[1], &i__1, &i__2, &c__1, nm, nn, &i__3, &wm[-14], wm,
		     ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	}

	i__1 = *id / 2 * *nm;
	i__2 = *id / 2 * *nm;
	mfftdv_(&c__[1], &i__1, &c__1, nn, &i__2, &wn[-14], wn, ierr);
	if (*ierr != 0) {
	    return 0;
	}

	if (*iord != 0) {
	    i__1 = *id / 2 * *nm;
	    i__2 = *id / 2 * *nm;
	    mfftov_(&c__[1], &i__1, &c__1, nn, &i__2, &wn[*nn * 2], &iwork[1])
		    ;
	    i__1 = *id / 2;
	    i__2 = *id / 2 * *nm;
	    i__3 = nl1 + 1;
	    mfftom_(&c__[1], &i__1, &i__2, &c__1, nm, nn, &i__3, &wm[*nm * 2],
		     &iwork[1]);
	}

    }

} /* r3fft_ */

/* Subroutine */ int mfftdm_(c__, imsx, ivsx, iesx, nmx, nvx, nex, tables, w, 
	ierr)
doublecomplex *c__;
integer *imsx, *ivsx, *iesx, *nmx, *nvx, *nex, *tables;
doublereal *w;
integer *ierr;
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    integer ifac;
    extern /* Subroutine */ int mfftc6_(), mfftb6_(), mffta6_();
    integer im;

/*   purpose: */
/*       this subroutine performs a direct fourier transform along */
/*       the second dimension of a 3-dimensional matrix, using the */
/*       gentleman-sande algorithm. */
/*       the sequence to be transformed is c[imsx,nmx], whose components 
*/
/*       are the 2-vectors c(m)[ivsx,nvx [iesx,nex]]. */
/*       see ref.[1] for notations. */
/*  example: */
/*       let c be a 3-d matrix c(n1,n2,n3), declared via */
/*              dimension c(nn1,n2,n3) */
/*       with nn1.ge.n1 */
/*       then its dft along the second dimension is obtained by */
/*              call mfftdm(c,nn1,nn1*n2,1,n2,n3,n1,tables,ierr) */
/*  implementation: */
/*       the transformation is implemented through repeated calls to the 
*/
/*       "butterfly" transformation mfft?6; parameters of the "butterfly" 
*/
/*       are communicated through the common block mfftpa. */
/*  arguments: */
/*    input  : */
/*       c : array to be transformed. */
/*       imsx,ivsx,iesx,nmx,nvx,nex: these arguments define the structure 
*/
/*           of c according to the definitions above. they are unchanged 
*/
/*           on output */
/*       tables : array prepared by mfftp. it  is not changed on output. 
*/
/*                it should be declared integer tables(4*nm+14); */
/*                it must be initialized by mfftp before usage. */
/*    output: */
/*       c : transform of the original array; "bit reversed" order */
/*       ierr : error code : =0 : successful */
/*                         : =3 :  'tables' not correctly initialized */
/*  loading the common block : constants */
    /* Parameter adjustments */
    tables -= -14;
    --c__;

    /* Function Body */
    mfftpa_1.ims = *imsx;
    mfftpa_1.ivs = *ivsx;
    mfftpa_1.ies = *iesx;
    mfftpa_1.nm = *nmx;
    mfftpa_1.nv = *nvx;
    mfftpa_1.ne = *nex;
    mfftpa_1.ivlim = (mfftpa_1.nv - 1) * mfftpa_1.ivs;
    mfftpa_1.ilim = (mfftpa_1.ne - 1) * mfftpa_1.ies;
    mfftpa_1.mstep = mfftpa_1.ims;
/*  loading the common block : iteration-dependent quantities: initializa 
*/
    mfftpa_1.lx = 1;
    mfftpa_1.mx = mfftpa_1.nm;
/*  select the highest factor of nm */
    ifac = tables[-1];
    switch ((int)ifac) {
	case 1:  goto L200;
	case 2:  goto L300;
	case 3:  goto L500;
    }
    *ierr = 3;
    return 0;
/* ...  radix 5 loop */
L500:
    i__1 = tables[-12];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 5;
	mfftpa_1.nustep = mfftpa_1.mx * mfftpa_1.mstep;
	mfftpa_1.mlim = mfftpa_1.nustep - mfftpa_1.mstep;
	mfftpa_1.lstep = mfftpa_1.nustep * 5;
	mfftpa_1.llim = mfftpa_1.nm * mfftpa_1.mstep - mfftpa_1.lstep;
	mfftc6_(&c__[1], w);
	mfftpa_1.lx *= 5;
/* L510: */
    }
/* ..  radix 3 loop */
L300:
    i__1 = tables[-13];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 3;
	mfftpa_1.nustep = mfftpa_1.mx * mfftpa_1.mstep;
	mfftpa_1.mlim = mfftpa_1.nustep - mfftpa_1.mstep;
	mfftpa_1.lstep = mfftpa_1.nustep * 3;
	mfftpa_1.llim = mfftpa_1.nm * mfftpa_1.mstep - mfftpa_1.lstep;
	mfftb6_(&c__[1], w);
	mfftpa_1.lx *= 3;
/* L310: */
    }
/* ..  radix 2 loop */
L200:
    i__1 = tables[-14];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 2;
	mfftpa_1.nustep = mfftpa_1.mx * mfftpa_1.mstep;
	mfftpa_1.mlim = mfftpa_1.nustep - mfftpa_1.mstep;
	mfftpa_1.md2lim = mfftpa_1.nustep / 2 - mfftpa_1.mstep;
	mfftpa_1.lstep = mfftpa_1.nustep << 1;
	mfftpa_1.llim = mfftpa_1.nm * mfftpa_1.mstep - mfftpa_1.lstep;
	mffta6_(&c__[1], w);
	mfftpa_1.lx += mfftpa_1.lx;
/* L210: */
    }
} /* mfftdm_ */

/* Subroutine */ int mfftds_(c__, imsx, ivsx, iesx, nmx, nvx, nex, tables, w, 
	ierr)
doublecomplex *c__;
integer *imsx, *ivsx, *iesx, *nmx, *nvx, *nex, *tables;
doublereal *w;
integer *ierr;
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    integer ifac;
    static integer ibase;
    extern /* Subroutine */ int mffta8_(), mfftb8_(), mfftc8_();
    integer im;

/*   purpose: */
/*       the same as mfftdm.    it is a variant of mfftdm */
/*       aimed at optimal performance on matrices having the */
/*       first dimension smaller than 64. it requires that mfftp has */
/*       been called with id .ne. 0 */
/*  implementation: */
/*       the transformation is implemented through repeated calls to the 
*/
/*       "butterfly" transformation mfft?8; parameters of the "butterfly" 
*/
/*       are communicated through the common block mfftpa. */
/*  arguments: */
/*    input  : */
/*       c : array to be transformed. */
/*       imsx,ivsx,iesx,nmx,nvx,nex: these arguments define the structure 
*/
/*           of c according to the definitions above. they are unchanged 
*/
/*           on output */
/*       tables : array prepared by mfftp. it  is not changed on output. 
*/
/*                it should be declared integer tables(4*nm+14); */
/*                it must be initialized by mfftp before usage. */
/*    output: */
/*       c : transform of the original array; "bit reversed" order */
/*       ierr : error code : =0 : successful */
/*                         : =3 :  'tables' not correctly initialized */
/*  loading the common block : constants */
    /* Parameter adjustments */
    tables -= -14;
    --c__;

    /* Function Body */
    mfftpa_1.ims = *imsx;
    mfftpa_1.ivs = *ivsx;
    mfftpa_1.nm = *nmx;
    mfftpa_1.nv = *nvx;
    mfftpa_1.ne = *nex;
    mfftpa_1.ivlim = (mfftpa_1.nv - 1) * mfftpa_1.ivs;
    mfftpa_1.mstep = mfftpa_1.ims;
/*  loading the common block : iteration-dependent quantities: initializa 
*/
    mfftpa_1.lx = 1;
    mfftpa_1.mx = mfftpa_1.nm;
    ibase = mfftpa_1.nm << 1;
/*  select the highest factor of nm */
    ifac = tables[-1];
    switch ((int)ifac) {
	case 1:  goto L200;
	case 2:  goto L300;
	case 3:  goto L500;
    }
    *ierr = 3;
    return 0;
/* ...  radix 5 loop */
L500:
    i__1 = tables[-12];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 5;
	mfftpa_1.nustep = mfftpa_1.mx * mfftpa_1.mstep;
	mfftpa_1.ilim = mfftpa_1.nustep - 1;
	mfftpa_1.lstep = mfftpa_1.nustep * 5;
	mfftpa_1.llim = mfftpa_1.nm * mfftpa_1.mstep - mfftpa_1.lstep;
	mfftc8_(&c__[1], &w[ibase * 2]);
	mfftpa_1.lx *= 5;
	ibase += mfftpa_1.nustep << 2;
/* L510: */
    }
/* ..  radix 3 loop */
L300:
    i__1 = tables[-13];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 3;
	mfftpa_1.nustep = mfftpa_1.mx * mfftpa_1.mstep;
	mfftpa_1.ilim = mfftpa_1.nustep - 1;
	mfftpa_1.lstep = mfftpa_1.nustep * 3;
	mfftpa_1.llim = mfftpa_1.nm * mfftpa_1.mstep - mfftpa_1.lstep;
	mfftb8_(&c__[1], &w[ibase * 2]);
	mfftpa_1.lx *= 3;
	ibase += mfftpa_1.nustep << 1;
/* L310: */
    }
/* ..  radix 2 loop */
L200:
    i__1 = tables[-14];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 2;
	mfftpa_1.nustep = mfftpa_1.mx * mfftpa_1.mstep;
	mfftpa_1.ilim = mfftpa_1.nustep - 1;
	mfftpa_1.md2lim = mfftpa_1.nustep / 2 - mfftpa_1.mstep;
	mfftpa_1.lstep = mfftpa_1.nustep << 1;
	mfftpa_1.llim = mfftpa_1.nm * mfftpa_1.mstep - mfftpa_1.lstep;
	mffta8_(&c__[1], &w[ibase * 2]);
	mfftpa_1.lx += mfftpa_1.lx;
	ibase += mfftpa_1.nustep;
/* L210: */
    }
} /* mfftds_ */

/* Subroutine */ int mfftdv_(c__, ivsx, iesx, nvx, nex, tables, w, ierr)
doublecomplex *c__;
integer *ivsx, *iesx, *nvx, *nex, *tables;
doublereal *w;
integer *ierr;
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    integer ifac;
    extern /* Subroutine */ int mffta4_(), mfftb4_(), mfftc4_();
    integer im;

/*   purpose: */
/*       this subroutine performs a direct fourier transform along */
/*       one dimension of a 2-dimensional matrix, using the */
/*       gentleman-sande algorithm; no reordering is performed. */
/*       the sequence to be transformed is c[ivsx,nvx], whose components 
*/
/*       are the vectors c(m)[iesx,nex]. */
/*       see ref.[1] for notations. */
/*  example: */
/*       let c be a 2-d matrix c(n1,n2) declared via */
/*                 dimension c(id,n2) */
/*       with id.ge.n1. */
/*       then the dft along the first dimension is obtained by */
/*                 call mfftdv(c,1,id,n1,n2,tables,ierr) */
/*       the dft along the second dimension is obtained by */
/*                 call mfftdv(c,id,1,n2,n1,tables,ierr) */
/*  implementation: */
/*       the transformation is implemented through repeated calls to the 
*/
/*       "butterfly" transformation mfft?4; parameters of the "butterfly" 
*/
/*       are communicated through the common block mfftpa. */
/*  arguments: */
/*       c : array to be transformed. */
/*       ivsx,iesx,nvx,nex: these arguments define the structure of */
/*           c according to the definitions above. they are unchanged on 
*/
/*           output; */
/*       tables : array prepared by mfftp. it  is not changed on output. 
*/
/*                it should be declared integer tables(4*nm+14); */
/*                it must be initialized by mfftp before usage. */
/*    output: */
/*       c : transform of the original array; "bit reversed" order */
/*       ierr : error code : =0 : successful */
/*                         : =3 :  'tables' not correctly initialized */
/*  loading the common block : constants */
    /* Parameter adjustments */
    tables -= -14;
    --c__;

    /* Function Body */
    mfftpa_1.ivs = *ivsx;
    mfftpa_1.ies = *iesx;
    mfftpa_1.nv = *nvx;
    mfftpa_1.ne = *nex;
    mfftpa_1.ilim = (mfftpa_1.ne - 1) * mfftpa_1.ies;
    mfftpa_1.mstep = mfftpa_1.ivs;
/*  loading the common block : iteration-dependent quantities: initializa 
*/
    mfftpa_1.lx = 1;
    mfftpa_1.mx = mfftpa_1.nv;
/*  select the highest factor of nv */
    ifac = tables[-1];
    switch ((int)ifac) {
	case 1:  goto L200;
	case 2:  goto L300;
	case 3:  goto L500;
    }
    *ierr = 3;
    return 0;
/* ...  radix 5 loop */
L500:
    i__1 = tables[-12];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 5;
	mfftpa_1.nustep = mfftpa_1.mx * mfftpa_1.mstep;
	mfftpa_1.mlim = mfftpa_1.nustep - mfftpa_1.mstep;
	mfftpa_1.lstep = mfftpa_1.nustep * 5;
	mfftpa_1.llim = mfftpa_1.nv * mfftpa_1.mstep - mfftpa_1.lstep;
	mfftc4_(&c__[1], w);
	mfftpa_1.lx *= 5;
/* L510: */
    }
/* ..  radix 3 loop */
L300:
    i__1 = tables[-13];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 3;
	mfftpa_1.nustep = mfftpa_1.mx * mfftpa_1.mstep;
	mfftpa_1.mlim = mfftpa_1.nustep - mfftpa_1.mstep;
	mfftpa_1.lstep = mfftpa_1.nustep * 3;
	mfftpa_1.llim = mfftpa_1.nv * mfftpa_1.mstep - mfftpa_1.lstep;
	mfftb4_(&c__[1], w);
	mfftpa_1.lx *= 3;
/* L310: */
    }
/* ..  radix 2 loop */
L200:
    i__1 = tables[-14];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 2;
	mfftpa_1.nustep = mfftpa_1.mx * mfftpa_1.mstep;
	mfftpa_1.mlim = mfftpa_1.nustep - mfftpa_1.mstep;
	mfftpa_1.md2lim = mfftpa_1.nustep / 2 - mfftpa_1.mstep;
	mfftpa_1.lstep = mfftpa_1.nustep << 1;
	mfftpa_1.llim = mfftpa_1.nv * mfftpa_1.mstep - mfftpa_1.lstep;
	mffta4_(&c__[1], w);
	mfftpa_1.lx += mfftpa_1.lx;
/* L210: */
    }
} /* mfftdv_ */

/* Subroutine */ int mfftim_(c__, imsx, ivsx, iesx, nmx, nvx, nex, tables, w, 
	ierr)
doublecomplex *c__;
integer *imsx, *ivsx, *iesx, *nmx, *nvx, *nex, *tables;
doublereal *w;
integer *ierr;
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    integer ifac;
    extern /* Subroutine */ int mffta7_(), mfftb7_(), mfftc7_();
    integer im;

/*   purpose: */
/*       this subroutine performs an inverse fourier transform along */
/*       the second dimension of a 3-dimensional matrix, using the */
/*       cooley-tukey algorithm. */
/*       the input sequence is assumed to have been subjected to a */
/*       "bit reversal" permutation, through a call to mfftom, or */
/*       because it is the output of mfftdm. */
/*       the sequence to be transformed is c[imsx,nmx], whose components 
*/
/*       are the 2-vectors c(m)[ivsx,nvx [iesx,nex]]. */
/*       see ref.[1] for notations. */
/*  example: */
/*       let c be a 3-d matrix c(n1,n2,n3), declared via */
/*              dimension c(nn1,n2,n3) */
/*       with nn1.ge.n1 */
/*       then its idft along the second dimension is obtained by */
/*              call mfftim(c,nn1,nn1*n2,1,n2,n3,n1,tables,ierr) */
/*  implementation: */
/*       the transformation is implemented through repeated calls to the 
*/
/*       "butterfly" transformation mfft?7; parameters of the "butterfly" 
*/
/*       are communicated through the common block mfftpa. */
/*  arguments: */
/*    input  : */
/*       c : array to be transformed. */
/*       imsx,ivsx,iesx,nmx,nvx,nex: these arguments define the structure 
*/
/*           of c according to the definitions above. they are unchanged 
*/
/*           on output */
/*       tables : array prepared by mfftp. it  is not changed on output. 
*/
/*                it should be declared integer tables(4*nm+14); */
/*                it must be initialized by mfftp before usage. */
/*    output: */
/*       c : transform of the original array; */
/*       ierr : error code : =0 : successful */
/*                         : =3 :  'tables' not correctly initialized */
/*  loading the common block : constants */
    /* Parameter adjustments */
    tables -= -14;
    --c__;

    /* Function Body */
    mfftpa_1.ims = *imsx;
    mfftpa_1.ivs = *ivsx;
    mfftpa_1.ies = *iesx;
    mfftpa_1.nm = *nmx;
    mfftpa_1.nv = *nvx;
    mfftpa_1.ne = *nex;
    mfftpa_1.ivlim = (mfftpa_1.nv - 1) * mfftpa_1.ivs;
    mfftpa_1.ilim = (mfftpa_1.ne - 1) * mfftpa_1.ies;
    mfftpa_1.lstep = mfftpa_1.ims;
/*  loading the common block : iteration-dependent quantities: initializa 
*/
    mfftpa_1.lx = 1;
    mfftpa_1.mx = mfftpa_1.nm;
    ifac = tables[-1];
    if (ifac > 3) {
	*ierr = 3;
	return 0;
    }
/* ..   radix 2 loop */
/* L200: */
    i__1 = tables[-14];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 2;
	mfftpa_1.nustep = mfftpa_1.lx * mfftpa_1.lstep;
	mfftpa_1.llim = mfftpa_1.nustep - mfftpa_1.lstep;
	mfftpa_1.ld2lim = mfftpa_1.nustep / 2 - mfftpa_1.lstep;
	mfftpa_1.mstep = mfftpa_1.nustep << 1;
	mfftpa_1.mlim = mfftpa_1.nm * mfftpa_1.lstep - mfftpa_1.mstep;
	mffta7_(&c__[1], w);
	mfftpa_1.lx += mfftpa_1.lx;
/* L210: */
    }
    if (ifac == 1) {
	return 0;
    }
/* ..   radix 3 loop */
/* L300: */
    i__1 = tables[-13];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 3;
	mfftpa_1.nustep = mfftpa_1.lx * mfftpa_1.lstep;
	mfftpa_1.llim = mfftpa_1.nustep - mfftpa_1.lstep;
	mfftpa_1.mstep = mfftpa_1.nustep * 3;
	mfftpa_1.mlim = mfftpa_1.nm * mfftpa_1.lstep - mfftpa_1.mstep;
	mfftb7_(&c__[1], w);
	mfftpa_1.lx *= 3;
/* L310: */
    }
    if (ifac == 2) {
	return 0;
    }
/* ..   radix 5 loop */
/* L500: */
    i__1 = tables[-12];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 5;
	mfftpa_1.nustep = mfftpa_1.lx * mfftpa_1.lstep;
	mfftpa_1.llim = mfftpa_1.nustep - mfftpa_1.lstep;
	mfftpa_1.mstep = mfftpa_1.nustep * 5;
	mfftpa_1.mlim = mfftpa_1.nm * mfftpa_1.lstep - mfftpa_1.mstep;
	mfftc7_(&c__[1], w);
	mfftpa_1.lx *= 5;
/* L510: */
    }
} /* mfftim_ */

/* Subroutine */ int mfftis_(c__, imsx, ivsx, iesx, nmx, nvx, nex, tables, w, 
	ierr)
doublecomplex *c__;
integer *imsx, *ivsx, *iesx, *nmx, *nvx, *nex, *tables;
doublereal *w;
integer *ierr;
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    integer ifac;
    static integer ibase;
    extern /* Subroutine */ int mffta9_(), mfftb9_(), mfftc9_();
    integer im;

/*   purpose: */
/*       the same as mfftim.  it is a variant of mfftim, optimized for */
/*       maximum performance on matrices whose first dimension is */
/*       less than 64. */
/*       it requires that tables has been prepared by a call to mfftp */
/*       with id .ne. 0 . */
/*  implementation: */
/*       the transformation is implemented through repeated calls to the 
*/
/*       "butterfly" transformation mfft?9; parameters of the "butterfly" 
*/
/*       are communicated through the common block mfftpa. */
/*  arguments: */
/*    input: */
/*       c : array to be transformed. */
/*       imsx,ivsx,iesx,nmx,nvx,nex: these arguments define the structure 
*/
/*           of c according to the definitions above. they are unchanged 
*/
/*           on output */
/*       tables : array prepared by mfftp. it  is not changed on output. 
*/
/*                it should be declared integer tables(4*nm+14); */
/*                it must be initialized by mfftp before usage. */
/*    output: */
/*       c : transform of the original array; "bit reversed" order */
/*       ierr : error code : =0 : successful */
/*                         : =3 :  'tables' not correctly initialized */
/*  loading the common block : constants */
    /* Parameter adjustments */
    tables -= -14;
    --c__;

    /* Function Body */
    mfftpa_1.ims = *imsx;
    mfftpa_1.ivs = *ivsx;
    mfftpa_1.ies = 1;
    mfftpa_1.nm = *nmx;
    mfftpa_1.nv = *nvx;
    mfftpa_1.ne = *nex;
    mfftpa_1.ivlim = (mfftpa_1.nv - 1) * mfftpa_1.ivs;
    mfftpa_1.lstep = mfftpa_1.ims;
/*  loading the common block : iteration-dependent quantities: initializa 
*/
    mfftpa_1.lx = 1;
    mfftpa_1.mx = mfftpa_1.nm;
    ibase = (mfftpa_1.ims + 2) * mfftpa_1.nm;
    ifac = tables[-1];
    if (ifac > 3) {
	*ierr = 3;
	return 0;
    }
/* ..   radix 2 loop */
/* L200: */
    i__1 = tables[-14];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 2;
	mfftpa_1.nustep = mfftpa_1.lx * mfftpa_1.lstep;
	mfftpa_1.ilim = mfftpa_1.nustep - 1;
	mfftpa_1.mstep = mfftpa_1.nustep << 1;
	mfftpa_1.mlim = mfftpa_1.nm * mfftpa_1.lstep - mfftpa_1.mstep;
	mffta9_(&c__[1], &w[ibase * 2]);
	mfftpa_1.lx += mfftpa_1.lx;
	ibase += mfftpa_1.nustep;
/* L210: */
    }
    if (ifac == 1) {
	return 0;
    }
/* ..   radix 3 loop */
/* L300: */
    i__1 = tables[-13];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 3;
	mfftpa_1.nustep = mfftpa_1.lx * mfftpa_1.lstep;
	mfftpa_1.ilim = mfftpa_1.nustep - 1;
	mfftpa_1.mstep = mfftpa_1.nustep * 3;
	mfftpa_1.mlim = mfftpa_1.nm * mfftpa_1.lstep - mfftpa_1.mstep;
	mfftb9_(&c__[1], &w[ibase * 2]);
	mfftpa_1.lx *= 3;
	ibase += mfftpa_1.nustep << 1;
/* L310: */
    }
    if (ifac == 2) {
	return 0;
    }
/* ..   radix 5 loop */
/* L500: */
    i__1 = tables[-12];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 5;
	mfftpa_1.nustep = mfftpa_1.lx * mfftpa_1.lstep;
	mfftpa_1.ilim = mfftpa_1.nustep - 1;
	mfftpa_1.mstep = mfftpa_1.nustep * 5;
	mfftpa_1.mlim = mfftpa_1.nm * mfftpa_1.lstep - mfftpa_1.mstep;
	mfftc9_(&c__[1], &w[ibase * 2]);
	mfftpa_1.lx *= 5;
	ibase += mfftpa_1.nustep << 2;
/* L510: */
    }
} /* mfftis_ */

/* Subroutine */ int mfftiv_(c__, ivsx, iesx, nvx, nex, tables, w, ierr)
doublecomplex *c__;
integer *ivsx, *iesx, *nvx, *nex, *tables;
doublereal *w;
integer *ierr;
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    integer ifac;
    extern /* Subroutine */ int mffta5_(), mfftb5_(), mfftc5_();
    integer im;


/*   purpose: */
/*       this subroutine performs an inverse fourier transform along */
/*       one dimension of a 2-dimensional matrix, using the */
/*       cooley-tukey algorithm. */
/*       the input matrix is assumed to have been subjected */
/*        to a "bit-reversal" reordering ( through mfftov or */
/*       because it is the output of mffdv and has not been reordered) */
/*       the sequence to be transformed is c[ivsx,nvx], whose components 
*/
/*       are the vectors c(m)[iesx,nex]. */
/*       see ref.[1] for notations. */
/*  example: */
/*       let c be a 2-d matrix c(n1,n2) declared via */
/*                 dimension c(id,n2) */
/*       with id.ge.n1. */
/*       then the idft along the first dimension is obtained by */
/*                 call mfftiv(c,1,id,n1,n2,tables,ierr) */
/*       the idft along the second dimension is obtained by */
/*                 call mfftiv(c,id,1,n2,n1,tables,ierr) */
/*  implementation: */
/*       the transformation is implemented through repeated calls to the 
*/
/*       "butterfly" transformation mfft?5; parameters of the "butterfly" 
*/
/*       are communicated through the common block mfftpa. */
/*  arguments: */
/*       c : array to be transformed. */
/*       ivsx,iesx,nvx,nex: these arguments define the structure of */
/*           c according to the definitions above. they are unchanged on 
*/
/*           output; */
/*       tables : array prepared by mfftp. it  is not changed on output. 
*/
/*                it should be declared integer tables(4*nm+14); */
/*                it must be initialized by mfftp before usage. */
/*  output: */
/*       c : transform of the original array; "bit reversed" order */
/*       ierr : error code : =0 : successful */
/*                         : =3 :  'tables' not correctly initialized */
/*  loading the common block : constants */
    /* Parameter adjustments */
    tables -= -14;
    --c__;

    /* Function Body */
    mfftpa_1.ivs = *ivsx;
    mfftpa_1.ies = *iesx;
    mfftpa_1.nv = *nvx;
    mfftpa_1.ne = *nex;
    mfftpa_1.ilim = (mfftpa_1.ne - 1) * mfftpa_1.ies;
    mfftpa_1.lstep = mfftpa_1.ivs;
/*  loading the common block : iteration-dependent quantities: initializa 
*/
    mfftpa_1.lx = 1;
    mfftpa_1.mx = mfftpa_1.nv;
/*  select the highest factor of nv */
    ifac = tables[-1];
    if (ifac > 3) {
	*ierr = 3;
	return 0;
    }
/* ..  radix 2 loop */
/* L200: */
    i__1 = tables[-14];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 2;
	mfftpa_1.nustep = mfftpa_1.lx * mfftpa_1.lstep;
	mfftpa_1.llim = mfftpa_1.nustep - mfftpa_1.lstep;
	mfftpa_1.ld2lim = mfftpa_1.nustep / 2 - mfftpa_1.lstep;
	mfftpa_1.mstep = mfftpa_1.nustep << 1;
	mfftpa_1.mlim = mfftpa_1.nv * mfftpa_1.lstep - mfftpa_1.mstep;
	mffta5_(&c__[1], w);
	mfftpa_1.lx += mfftpa_1.lx;
/* L210: */
    }
    if (ifac == 1) {
	return 0;
    }
/* ..  radix 3 loop */
/* L300: */
    i__1 = tables[-13];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 3;
	mfftpa_1.nustep = mfftpa_1.lx * mfftpa_1.lstep;
	mfftpa_1.llim = mfftpa_1.nustep - mfftpa_1.lstep;
	mfftpa_1.mstep = mfftpa_1.nustep * 3;
	mfftpa_1.mlim = mfftpa_1.nv * mfftpa_1.lstep - mfftpa_1.mstep;
	mfftb5_(&c__[1], w);
	mfftpa_1.lx *= 3;
/* L310: */
    }
    if (ifac == 2) {
	return 0;
    }
/* ..   radix 5 loop */
/* L500: */
    i__1 = tables[-12];
    for (im = 1; im <= i__1; ++im) {
	mfftpa_1.mx /= 5;
	mfftpa_1.nustep = mfftpa_1.lx * mfftpa_1.lstep;
	mfftpa_1.llim = mfftpa_1.nustep - mfftpa_1.lstep;
	mfftpa_1.mstep = mfftpa_1.nustep * 5;
	mfftpa_1.mlim = mfftpa_1.nv * mfftpa_1.lstep - mfftpa_1.mstep;
	mfftc5_(&c__[1], w);
	mfftpa_1.lx *= 5;
/* L510: */
    }
} /* mfftiv_ */

/* Subroutine */ int mfftom_(c__, ims, ivs, ies, nm, nv, ne, index, itemp)
doublecomplex *c__;
integer *ims, *ivs, *ies, *nm, *nv, *ne, *index, *itemp;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7;

    /* Local variables */
    integer jlim, i3lim, i__, j;
    doublecomplex t;
    integer idest, i3;


/*   purpose : */
/*     this routine performs a reordering of a vector-of-2 vectors */
/*     of complex c[ims,nm [ivs,nv [ies,ne]]], according to a */
/*     permutation index "index". */
/*     see ref.[1] for notations, and comments to mfftdm above. */
/*  arguments */
/*     c : vector-of-2 vectors to be reordered */
/*     ims,ivs,ies,nm,nv,ne: these arguments describe the structure of */
/*     c, according to the above definition; */
/*     index: integer array , containing the permutation index  ; */
/*            it is nm elements long ; prepared by mfftp. */
/*     iwork: integer array, of length at least nm, used as workspace; */

    /* Parameter adjustments */
    c_dim1 = *ims - 1 + 1;

    /* Function Body */
    i3lim = (*nv - 1) * *ivs;
    jlim = (*ne - 1) * *ies;
    i__1 = *nm - 1;
    for (i__ = 0; i__ <= i__1; ++i__) {
/* L1: */
	itemp[i__] = index[i__];
    }
    i__1 = *nm - 3;
    for (i__ = 1; i__ <= i__1; ++i__) {
L2:
	if (itemp[i__] != i__) {
	    idest = itemp[i__];
	    i__2 = i3lim;
	    i__3 = *ivs;
	    for (i3 = 0; i__3 < 0 ? i3 >= i__2 : i3 <= i__2; i3 += i__3) {
		i__4 = i3 + jlim;
		i__5 = *ies;
		for (j = i3; i__5 < 0 ? j >= i__4 : j <= i__4; j += i__5) {
		    i__6 = j + i__ * c_dim1;
		    t.r = c__[i__6].r, t.i = c__[i__6].i;
		    i__6 = j + i__ * c_dim1;
		    i__7 = j + idest * c_dim1;
		    c__[i__6].r = c__[i__7].r, c__[i__6].i = c__[i__7].i;
		    i__6 = j + idest * c_dim1;
		    c__[i__6].r = t.r, c__[i__6].i = t.i;
/* L3: */
		}
	    }
	    itemp[i__] = itemp[idest];
	    itemp[idest] = idest;
	    goto L2;
	}
/* L4: */
    }
} /* mfftom_ */

/* Subroutine */ int mfftov_(c__, ivs, ies, nv, ne, index, itemp)
doublecomplex *c__;
integer *ivs, *ies, *nv, *ne, *index, *itemp;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5;

    /* Local variables */
    integer i__, j;
    doublecomplex t;
    integer neies, idest;


/*   purpose : */
/*     this routine performs a reordering of a vector-of-vectors */
/*     of complex c[ivs,nv [ies,ne]], according to a */
/*     permutation index "index". */
/*     see ref.[1] for notations, and comments to mfftdv. */
/*  arguments */
/*     c : vector-of-vectors to be reordered */
/*     ivs,ies,nv,ne: these arguments describe the structure of */
/*     c, according to the above definition; */
/*     index: integer array , containing the permutation index ; */
/*            it is nv elements long; prepared by mfftp. */
/*     iwork: integer array, of length at least nv, used as workspace; */

    /* Parameter adjustments */
    c_dim1 = *ivs;
    --c__;

    /* Function Body */
    neies = *ne * *ies;
    i__1 = *nv - 1;
    for (i__ = 0; i__ <= i__1; ++i__) {
/* L1: */
	itemp[i__] = index[i__];
    }
    i__1 = *nv - 3;
    for (i__ = 1; i__ <= i__1; ++i__) {
L2:
	if (itemp[i__] != i__) {
	    idest = itemp[i__];
	    i__2 = neies;
	    i__3 = *ies;
	    for (j = 1; i__3 < 0 ? j >= i__2 : j <= i__2; j += i__3) {
		i__4 = j + i__ * c_dim1;
		t.r = c__[i__4].r, t.i = c__[i__4].i;
		i__4 = j + i__ * c_dim1;
		i__5 = j + idest * c_dim1;
		c__[i__4].r = c__[i__5].r, c__[i__4].i = c__[i__5].i;
		i__4 = j + idest * c_dim1;
		c__[i__4].r = t.r, c__[i__4].i = t.i;
/* L3: */
	    }
	    itemp[i__] = itemp[idest];
	    itemp[idest] = idest;
	    goto L2;
	}
/* L4: */
    }
} /* mfftov_ */

/* Subroutine */ int mfftp_(n, w, iw, id, ierr)
integer *n;
doublereal *w;
integer *iw, *id, *ierr;
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    double atan(), cos(), sin();

    /* Local variables */
    doublereal pi2dn;
    integer i__;
    extern /* Subroutine */ int mfftp1_(), mfftp2_(), mfftp4_();


/*     this subroutine prepares tables for use by the mfft */
/*     routines. the parameters are */

/*     n : is the order of the transform; */

/*     w : array of length at least 4*n+14  words if id=0, */
/*      and 4*n*(id+1)+14 if id > 0 ; this array is filled */
/*      by the present routine, and should not be modified by the */
/*      user; it is required by all the operating routines; */
/*      the routines mfftis and mfftds */
/*      require that w has been filled by a call to mfftp with */
/*      id .gt. 0 ; all the routines do not modify the contents */
/*      of w ; */
/*      warning: different portions of w are handled as complex or */
/*               integer variables by different routines. */

/*     id : if id .eq. 0 the tables are set for a normal */
/*      transform; if id .gt. 0 the tables are set for both */
/*      a normal and a "special" transform (i.e. optimized for small */
/*      first dimension data arrays, see ref.[2]); in this case it */
/*      should be equal to the first dimension of the array to be */
/*      transformed, as declared in the calling program. */

/*     ierr : error code : =0 : successful */
/*                       : =2 : factorization error */


/* ************************************************************ */

/*      reference information : layout of w */

/*  in all cases */

/* word address      type    n. of el. word length   purpose */

/*  0                integer      14      14     factorization of n */

/*  14               complex     n       2*n     exp(i*p/(2*n)*k),k= */
/*                                               0,n-1 */
/*  3*n+14           integer     n        n      permutation index:kofi */
/*  2*n+14           integer     n        n      permutation index:iofk */

/*  only if id .gt. 0 */

/*  4*n+14           complex    n*id     2*n*id  tables for mfftds */
/*  4*n+2*n*id+14    complex    n*id     2*n*id  tables for mfftis */



/* ****************************************************************** */
/* ...  factorization of n in iw(-14)..w(-1) */
    /* Parameter adjustments */
    iw -= -14;

    /* Function Body */
    mfftp1_(&iw[-14], n, ierr);
    if (*ierr != 0) {
	return 0;
    }

/*     preparation of permutation indexes in w(n)..w(2*n-1) */
/*     warning : iw(0)..iw(n-1) used as a work space */
    mfftp2_(&w[*n * 2], &w[*n * 3], w, &iw[-14], n);

/*     preparation of phase factor table in w(0)..w(2n-1) */
    w[0] = 1.;
    w[1] = 0.;
    pi2dn = atan(1.) * 8. / *n;
    i__1 = *n - 1;
    for (i__ = 1; i__ <= i__1; ++i__) {
	w[i__ * 2] = cos(pi2dn * i__);
	w[(i__ << 1) + 1] = sin(pi2dn * i__);
/* L1: */
    }

/*     if tables for special transform are requested */
    if (*id > 0) {
	mfftp4_(w, &w[*n * 4], &iw[-14], n, id);
    }

} /* mfftp_ */

/* Subroutine */ int mfftrd_(c__, isv, ise, nv, ne, rw)
doublecomplex *c__;
integer *isv, *ise, *nv, *ne;
doublecomplex *rw;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5;
    doublereal d__1;
    doublecomplex z__1, z__2, z__3, z__4, z__5, z__6, z__7, z__8, z__9;

    /* Builtin functions */
    void d_cnjg();
    double d_imag();

    /* Local variables */
    doublecomplex t1, t2;
    integer ie, iv;


/*   purpose: */
/*       this routine performs the post-processing phase for */
/*       real 2-dimensional dft's, according to formula (2.7) */
/*       in ref.[1]. */
/*       post-processing acts after computing the complex dft */
/*       and eventual reordering (calls to mfftdv and mfftov). */
/*       it applies to a vector-of-vectors-of-complex */
/*               c[ivs,nv [ies,ne]]. */
/*       see ref.[1] for notations. */

/*   arguments: */
/*      input: */
/*       c : data array, output from mfftdv, mfftov; to be declared */
/*                      real c(ise*2,ne) */
/*           in the calling program. */
/*     isv : separation of elements in a column of c (usually 1) */
/*     ise : separation of elements in a row of c, divided by 2 */
/*      nv : no. of elements to be processed in a column of c */
/*      ne : no. of elements in a row of c, divided by 2. */
/*      rw : complex array of lenght at least nv; it must */
/*           be initialized by a call to mfftrp; it remains */
/*           unchanged in output. */

/*  output : post-processed array c */



    /* Parameter adjustments */
    c_dim1 = *isv - 1 + 1;

    /* Function Body */
    if (*nv > 1) {
	i__1 = (*nv - 1) / 2;
	for (iv = 1; iv <= i__1; ++iv) {
	    i__2 = (*ne - 1) * *ise;
	    i__3 = *ise;
	    for (ie = 0; i__3 < 0 ? ie >= i__2 : ie <= i__2; ie += i__3) {

		i__4 = ie + iv * c_dim1;
		t1.r = c__[i__4].r, t1.i = c__[i__4].i;
		i__4 = ie + (*nv - iv) * c_dim1;
		t2.r = c__[i__4].r, t2.i = c__[i__4].i;
		i__4 = ie + iv * c_dim1;
		d_cnjg(&z__4, &t2);
		z__3.r = t1.r + z__4.r, z__3.i = t1.i + z__4.i;
		i__5 = iv;
		d_cnjg(&z__7, &t2);
		z__6.r = t1.r - z__7.r, z__6.i = t1.i - z__7.i;
		z__5.r = rw[i__5].r * z__6.r - rw[i__5].i * z__6.i, z__5.i = 
			rw[i__5].r * z__6.i + rw[i__5].i * z__6.r;
		z__2.r = z__3.r + z__5.r, z__2.i = z__3.i + z__5.i;
		z__1.r = z__2.r * .5, z__1.i = z__2.i * .5;
		c__[i__4].r = z__1.r, c__[i__4].i = z__1.i;
		i__4 = ie + (*nv - iv) * c_dim1;
		d_cnjg(&z__5, &t2);
		z__4.r = t1.r + z__5.r, z__4.i = t1.i + z__5.i;
		d_cnjg(&z__3, &z__4);
		i__5 = iv;
		d_cnjg(&z__9, &t2);
		z__8.r = t1.r - z__9.r, z__8.i = t1.i - z__9.i;
		z__7.r = rw[i__5].r * z__8.r - rw[i__5].i * z__8.i, z__7.i = 
			rw[i__5].r * z__8.i + rw[i__5].i * z__8.r;
		d_cnjg(&z__6, &z__7);
		z__2.r = z__3.r - z__6.r, z__2.i = z__3.i - z__6.i;
		z__1.r = z__2.r * .5, z__1.i = z__2.i * .5;
		c__[i__4].r = z__1.r, c__[i__4].i = z__1.i;

/* L190: */
	    }
/* L200: */
	}


	if (iv << 1 == *nv) {
	    i__1 = (*ne - 1) * *ise;
	    i__3 = *ise;
	    for (ie = 0; i__3 < 0 ? ie >= i__1 : ie <= i__1; ie += i__3) {
		i__2 = ie + iv * c_dim1;
		d_cnjg(&z__1, &c__[ie + iv * c_dim1]);
		c__[i__2].r = z__1.r, c__[i__2].i = z__1.i;
/* L210: */
	    }

	}

    }
    i__3 = (*ne - 1) * *ise;
    i__1 = *ise;
    for (ie = 0; i__1 < 0 ? ie >= i__3 : ie <= i__3; ie += i__1) {
	i__2 = ie;
	t1.r = c__[i__2].r, t1.i = c__[i__2].i;
	i__2 = ie;
	d__1 = t1.r + d_imag(&t1);
	c__[i__2].r = d__1, c__[i__2].i = 0.;
	i__2 = ie + *nv * c_dim1;
	d__1 = t1.r - d_imag(&t1);
	c__[i__2].r = d__1, c__[i__2].i = 0.;
/* L300: */
    }


} /* mfftrd_ */

/* Subroutine */ int mfftri_(c__, isv, ise, nv, ne, rw)
doublecomplex *c__;
integer *isv, *ise, *nv, *ne;
doublecomplex *rw;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4;
    doublereal d__1;
    doublecomplex z__1, z__2, z__3, z__4, z__5, z__6, z__7, z__8, z__9;

    /* Builtin functions */
    void d_cnjg();

    /* Local variables */
    doublecomplex t1, t2;
    integer ie, iv;
    doublereal rm, rp;


/*   purpose: */
/*       this routine performs the pre-processing phase for */
/*       real 2-dimensional inverse dft's (see formula (2.7) */
/*       in ref.[1]). */
/*       pre-processing acts on sequental data before a call to */
/*       mfftov an before computing the idft (a call to mfftiv) */
/*       and eventual reordering (calls to mfftiv and mfftov). */
/*       it applies to a vector-of-vectors-of-complex */
/*               c[ivs,nv [ies,ne]]. */
/*       see ref.[1] for notations. */

/*   arguments: */
/*      input: */
/*       c : data array, output from mfftdv, mfftov; to be declared */
/*                      real c(ise*2,ne) */
/*           in the calling program. */
/*     isv : separation of elements in a column of c (usually 1) */
/*     ise : separation of elements in a row of c, divided by 2 */
/*      nv : no. of elements to be processed in a column of c */
/*      ne : no. of elements in a row of c, divided by 2. */
/*      rw : complex array of lenght at least nv; it must */
/*           be initialized by a call to mfftrp; it remains */
/*           unchanged in output. */

/*  output : post-processed array c */




    /* Parameter adjustments */
    c_dim1 = *isv - 1 + 1;

    /* Function Body */
    if (*nv > 1) {

	i__1 = (*nv - 1) / 2;
	for (iv = 1; iv <= i__1; ++iv) {
	    i__2 = (*ne - 1) * *ise;
	    i__3 = *ise;
	    for (ie = 0; i__3 < 0 ? ie >= i__2 : ie <= i__2; ie += i__3) {
		i__4 = ie + iv * c_dim1;
		t1.r = c__[i__4].r, t1.i = c__[i__4].i;
		i__4 = ie + (*nv - iv) * c_dim1;
		t2.r = c__[i__4].r, t2.i = c__[i__4].i;

		i__4 = ie + iv * c_dim1;
		d_cnjg(&z__3, &t2);
		z__2.r = t1.r + z__3.r, z__2.i = t1.i + z__3.i;
		d_cnjg(&z__5, &rw[iv]);
		d_cnjg(&z__7, &t2);
		z__6.r = t1.r - z__7.r, z__6.i = t1.i - z__7.i;
		z__4.r = z__5.r * z__6.r - z__5.i * z__6.i, z__4.i = z__5.r * 
			z__6.i + z__5.i * z__6.r;
		z__1.r = z__2.r + z__4.r, z__1.i = z__2.i + z__4.i;
		c__[i__4].r = z__1.r, c__[i__4].i = z__1.i;
		i__4 = ie + (*nv - iv) * c_dim1;
		d_cnjg(&z__4, &t2);
		z__3.r = t1.r + z__4.r, z__3.i = t1.i + z__4.i;
		d_cnjg(&z__2, &z__3);
		d_cnjg(&z__7, &rw[iv]);
		d_cnjg(&z__9, &t2);
		z__8.r = t1.r - z__9.r, z__8.i = t1.i - z__9.i;
		z__6.r = z__7.r * z__8.r - z__7.i * z__8.i, z__6.i = z__7.r * 
			z__8.i + z__7.i * z__8.r;
		d_cnjg(&z__5, &z__6);
		z__1.r = z__2.r - z__5.r, z__1.i = z__2.i - z__5.i;
		c__[i__4].r = z__1.r, c__[i__4].i = z__1.i;
/* L190: */
	    }
/* L200: */
	}


	if (iv << 1 == *nv) {

	    i__1 = (*ne - 1) * *ise;
	    i__3 = *ise;
	    for (ie = 0; i__3 < 0 ? ie >= i__1 : ie <= i__1; ie += i__3) {
		i__2 = ie + iv * c_dim1;
		d_cnjg(&z__2, &c__[ie + iv * c_dim1]);
		d__1 = 2.;
		z__1.r = d__1 * z__2.r, z__1.i = d__1 * z__2.i;
		c__[i__2].r = z__1.r, c__[i__2].i = z__1.i;
/* L210: */
	    }


	}

    }


    i__3 = (*ne - 1) * *ise;
    i__1 = *ise;
    for (ie = 0; i__1 < 0 ? ie >= i__3 : ie <= i__3; ie += i__1) {
	i__2 = ie;
	i__4 = ie + *nv * c_dim1;
	rp = c__[i__2].r + c__[i__4].r;
	i__2 = ie;
	i__4 = ie + *nv * c_dim1;
	rm = c__[i__2].r - c__[i__4].r;
	i__2 = ie;
	z__1.r = rp, z__1.i = rm;
	c__[i__2].r = z__1.r, c__[i__2].i = z__1.i;
/* L220: */
    }


} /* mfftri_ */

/* Subroutine */ int mfftrp_(nn, rw)
integer *nn;
doublecomplex *rw;
{
    /* System generated locals */
    integer i__1, i__2;
    doublereal d__1, d__2;
    doublecomplex z__1;

    /* Builtin functions */
    double atan(), sin(), cos();

    /* Local variables */
    integer i__;
    doublereal phase, pi2;


/*  this routine prepares the phase factor tables to be used in the */
/*  post-processing phase in real transforms, i.e. r2fft and r3fft. */

/*  the definition of phase factors we use is the following */

/*             rw(iv) = -i*exp(-i*2*pi/nn*iv) */

/*  where the symbols are: */

/*  i: imaginary unit */
/*  nn : number of real elements */
/*  iv: running index from 0 to nn-1 */






    pi2 = atan(1.) * 8;
    phase = pi2 / *nn;
    rw[0].r = 0., rw[0].i = -1.;


    i__1 = *nn - 1;
    for (i__ = 1; i__ <= i__1; ++i__) {
	i__2 = i__;
	d__1 = -sin(i__ * phase);
	d__2 = -cos(i__ * phase);
	z__1.r = d__1, z__1.i = d__2;
	rw[i__2].r = z__1.r, rw[i__2].i = z__1.i;
/* L10: */
    }


} /* mfftrp_ */

/* Subroutine */ int mffta4_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3;

    /* Builtin functions */
    void d_cnjg();
    double d_imag();

    /* Local variables */
    doublecomplex f;
    integer i__;
    doublecomplex t0;
    integer mu, lam, muf;


/*   purpose: */
/*       elementary gentleman-sande radix 2 step applied to a vector-of */
/*       vectors-of-complex c[ivs,nv [ies,ne]]. see ref.[1] for notations 
*/
/*       this routine can be used only by routine mfftdv, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    if (mfftpa_1.mx > mfftpa_1.lx << 1) {
	i__1 = mfftpa_1.llim;
	i__2 = mfftpa_1.lstep;
	for (lam = 0; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam += i__2) {
	    muf = mfftpa_1.lx;
	    i__3 = lam + mfftpa_1.md2lim;
	    i__4 = mfftpa_1.mstep;
	    for (mu = lam + mfftpa_1.mstep; i__4 < 0 ? mu >= i__3 : mu <= 
		    i__3; mu += i__4) {
		d_cnjg(&z__1, &fac[muf]);
		f.r = z__1.r, f.i = z__1.i;
		i__5 = mu + mfftpa_1.ilim;
		i__6 = mfftpa_1.ies;
		for (i__ = mu; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += 
			i__6) {
		    i__7 = i__;
		    t0.r = c__[i__7].r, t0.i = c__[i__7].i;
		    i__7 = i__;
		    i__8 = i__ + c_dim1;
		    z__1.r = t0.r + c__[i__8].r, z__1.i = t0.i + c__[i__8].i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__ + c_dim1;
		    z__2.r = t0.r - c__[i__8].r, z__2.i = t0.i - c__[i__8].i;
		    z__1.r = z__2.r * f.r - z__2.i * f.i, z__1.i = z__2.r * 
			    f.i + z__2.i * f.r;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L80: */
		}
		muf += mfftpa_1.lx;
/* L90: */
	    }
	    muf -= mfftpa_1.lx;
	    i__4 = lam + mfftpa_1.mlim;
	    i__3 = mfftpa_1.mstep;
	    for (mu = lam + mfftpa_1.md2lim + (mfftpa_1.mstep << 1); i__3 < 0 
		    ? mu >= i__4 : mu <= i__4; mu += i__3) {
		i__6 = muf;
		z__1.r = -fac[i__6].r, z__1.i = -fac[i__6].i;
		f.r = z__1.r, f.i = z__1.i;
		i__6 = mu + mfftpa_1.ilim;
		i__5 = mfftpa_1.ies;
		for (i__ = mu; i__5 < 0 ? i__ >= i__6 : i__ <= i__6; i__ += 
			i__5) {
		    i__7 = i__;
		    t0.r = c__[i__7].r, t0.i = c__[i__7].i;
		    i__7 = i__;
		    i__8 = i__ + c_dim1;
		    z__1.r = t0.r + c__[i__8].r, z__1.i = t0.i + c__[i__8].i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__ + c_dim1;
		    z__2.r = t0.r - c__[i__8].r, z__2.i = t0.i - c__[i__8].i;
		    z__1.r = z__2.r * f.r - z__2.i * f.i, z__1.i = z__2.r * 
			    f.i + z__2.i * f.r;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L81: */
		}
		muf -= mfftpa_1.lx;
/* L91: */
	    }
	    i__3 = mfftpa_1.md2lim + mfftpa_1.mstep + lam + mfftpa_1.ilim;
	    i__4 = mfftpa_1.ies;
	    for (i__ = mfftpa_1.md2lim + mfftpa_1.mstep + lam; i__4 < 0 ? i__ 
		    >= i__3 : i__ <= i__3; i__ += i__4) {
		i__5 = i__;
		t0.r = c__[i__5].r, t0.i = c__[i__5].i;
		i__5 = i__;
		i__6 = i__ + c_dim1;
		z__1.r = t0.r + c__[i__6].r, z__1.i = t0.i + c__[i__6].i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
		i__5 = i__ + c_dim1;
		i__6 = i__ + c_dim1;
		z__2.r = t0.r - c__[i__6].r, z__2.i = t0.i - c__[i__6].i;
		d__1 = d_imag(&z__2);
		i__7 = i__ + c_dim1;
		z__3.r = t0.r - c__[i__7].r, z__3.i = t0.i - c__[i__7].i;
		d__2 = -z__3.r;
		z__1.r = d__1, z__1.i = d__2;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
/* L82: */
	    }
	    i__4 = lam + mfftpa_1.ilim;
	    i__3 = mfftpa_1.ies;
	    for (i__ = lam; i__3 < 0 ? i__ >= i__4 : i__ <= i__4; i__ += i__3)
		     {
		i__5 = i__;
		t0.r = c__[i__5].r, t0.i = c__[i__5].i;
		i__5 = i__;
		i__6 = i__ + c_dim1;
		z__1.r = t0.r + c__[i__6].r, z__1.i = t0.i + c__[i__6].i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
		i__5 = i__ + c_dim1;
		i__6 = i__ + c_dim1;
		z__1.r = t0.r - c__[i__6].r, z__1.i = t0.i - c__[i__6].i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
/* L83: */
	    }
/* L100: */
	}
    } else {
	if (mfftpa_1.mx == 1) {
	    goto L1000;
	}
/* if mx > 1 come here */
	muf = mfftpa_1.lx;
	i__2 = mfftpa_1.md2lim;
	i__1 = mfftpa_1.mstep;
	for (mu = mfftpa_1.mstep; i__1 < 0 ? mu >= i__2 : mu <= i__2; mu += 
		i__1) {
	    d_cnjg(&z__1, &fac[muf]);
	    f.r = z__1.r, f.i = z__1.i;
	    i__3 = mu + mfftpa_1.llim;
	    i__4 = mfftpa_1.lstep;
	    for (lam = mu; i__4 < 0 ? lam >= i__3 : lam <= i__3; lam += i__4) 
		    {
		i__5 = lam + mfftpa_1.ilim;
		i__6 = mfftpa_1.ies;
		for (i__ = lam; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += 
			i__6) {
		    i__7 = i__;
		    t0.r = c__[i__7].r, t0.i = c__[i__7].i;
		    i__7 = i__;
		    i__8 = i__ + c_dim1;
		    z__1.r = t0.r + c__[i__8].r, z__1.i = t0.i + c__[i__8].i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__ + c_dim1;
		    z__2.r = t0.r - c__[i__8].r, z__2.i = t0.i - c__[i__8].i;
		    z__1.r = z__2.r * f.r - z__2.i * f.i, z__1.i = z__2.r * 
			    f.i + z__2.i * f.r;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L180: */
		}
/* L190: */
	    }
	    muf += mfftpa_1.lx;
/* L200: */
	}
	muf -= mfftpa_1.lx;
	i__1 = mfftpa_1.mlim;
	i__2 = mfftpa_1.mstep;
	for (mu = mfftpa_1.md2lim + (mfftpa_1.mstep << 1); i__2 < 0 ? mu >= 
		i__1 : mu <= i__1; mu += i__2) {
	    i__4 = muf;
	    z__1.r = -fac[i__4].r, z__1.i = -fac[i__4].i;
	    f.r = z__1.r, f.i = z__1.i;
	    i__4 = mu + mfftpa_1.llim;
	    i__3 = mfftpa_1.lstep;
	    for (lam = mu; i__3 < 0 ? lam >= i__4 : lam <= i__4; lam += i__3) 
		    {
		i__6 = lam + mfftpa_1.ilim;
		i__5 = mfftpa_1.ies;
		for (i__ = lam; i__5 < 0 ? i__ >= i__6 : i__ <= i__6; i__ += 
			i__5) {
		    i__7 = i__;
		    t0.r = c__[i__7].r, t0.i = c__[i__7].i;
		    i__7 = i__;
		    i__8 = i__ + c_dim1;
		    z__1.r = t0.r + c__[i__8].r, z__1.i = t0.i + c__[i__8].i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__ + c_dim1;
		    z__2.r = t0.r - c__[i__8].r, z__2.i = t0.i - c__[i__8].i;
		    z__1.r = z__2.r * f.r - z__2.i * f.i, z__1.i = z__2.r * 
			    f.i + z__2.i * f.r;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L181: */
		}
/* L191: */
	    }
	    muf -= mfftpa_1.lx;
/* L201: */
	}
	i__2 = mfftpa_1.md2lim + mfftpa_1.mstep + mfftpa_1.llim;
	i__1 = mfftpa_1.lstep;
	for (lam = mfftpa_1.md2lim + mfftpa_1.mstep; i__1 < 0 ? lam >= i__2 : 
		lam <= i__2; lam += i__1) {
	    i__3 = lam + mfftpa_1.ilim;
	    i__4 = mfftpa_1.ies;
	    for (i__ = lam; i__4 < 0 ? i__ >= i__3 : i__ <= i__3; i__ += i__4)
		     {
		i__5 = i__;
		t0.r = c__[i__5].r, t0.i = c__[i__5].i;
		i__5 = i__;
		i__6 = i__ + c_dim1;
		z__1.r = t0.r + c__[i__6].r, z__1.i = t0.i + c__[i__6].i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
		i__5 = i__ + c_dim1;
		i__6 = i__ + c_dim1;
		z__2.r = t0.r - c__[i__6].r, z__2.i = t0.i - c__[i__6].i;
		d__1 = d_imag(&z__2);
		i__7 = i__ + c_dim1;
		z__3.r = t0.r - c__[i__7].r, z__3.i = t0.i - c__[i__7].i;
		d__2 = -z__3.r;
		z__1.r = d__1, z__1.i = d__2;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
/* L182: */
	    }
/* L192: */
	}
L1000:
	i__1 = mfftpa_1.llim;
	i__2 = mfftpa_1.lstep;
	for (lam = 0; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam += i__2) {
	    i__4 = lam + mfftpa_1.ilim;
	    i__3 = mfftpa_1.ies;
	    for (i__ = lam; i__3 < 0 ? i__ >= i__4 : i__ <= i__4; i__ += i__3)
		     {
		i__5 = i__;
		t0.r = c__[i__5].r, t0.i = c__[i__5].i;
		i__5 = i__;
		i__6 = i__ + c_dim1;
		z__1.r = t0.r + c__[i__6].r, z__1.i = t0.i + c__[i__6].i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
		i__5 = i__ + c_dim1;
		i__6 = i__ + c_dim1;
		z__1.r = t0.r - c__[i__6].r, z__1.i = t0.i - c__[i__6].i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
/* L183: */
	    }
/* L193: */
	}
    }
} /* mffta4_ */

/* Subroutine */ int mffta5_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2;

    /* Builtin functions */
    void d_cnjg();
    double d_imag();

    /* Local variables */
    integer lamf;
    doublecomplex f;
    integer i__;
    doublecomplex t0;
    integer mu, lam;


/*   purpose: */
/*       elementary cooley-tukey radix 2 step applied to a vector-of */
/*       vectors-of-complex c[ivs,nv [ies,ne]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftiv, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    if (mfftpa_1.mx << 1 >= mfftpa_1.lx) {
	if (mfftpa_1.lx == 1) {
	    goto L1000;
	}
	lamf = mfftpa_1.mx;
	i__1 = mfftpa_1.ld2lim;
	i__2 = mfftpa_1.lstep;
	for (lam = mfftpa_1.lstep; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam 
		+= i__2) {
	    i__3 = lamf;
	    f.r = fac[i__3].r, f.i = fac[i__3].i;
	    i__3 = lam + mfftpa_1.mlim;
	    i__4 = mfftpa_1.mstep;
	    for (mu = lam; i__4 < 0 ? mu >= i__3 : mu <= i__3; mu += i__4) {
		i__5 = mu + mfftpa_1.ilim;
		i__6 = mfftpa_1.ies;
		for (i__ = mu; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += 
			i__6) {
		    i__7 = i__ + c_dim1;
		    z__1.r = c__[i__7].r * f.r - c__[i__7].i * f.i, z__1.i = 
			    c__[i__7].r * f.i + c__[i__7].i * f.r;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__;
		    z__1.r = c__[i__8].r - t0.r, z__1.i = c__[i__8].i - t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__;
		    i__8 = i__;
		    z__1.r = c__[i__8].r + t0.r, z__1.i = c__[i__8].i + t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L80: */
		}
/* L90: */
	    }
	    lamf += mfftpa_1.mx;
/* L100: */
	}
	lamf -= mfftpa_1.mx;
	i__2 = mfftpa_1.llim;
	i__1 = mfftpa_1.lstep;
	for (lam = mfftpa_1.ld2lim + (mfftpa_1.lstep << 1); i__1 < 0 ? lam >= 
		i__2 : lam <= i__2; lam += i__1) {
	    d_cnjg(&z__2, &fac[lamf]);
	    z__1.r = -z__2.r, z__1.i = -z__2.i;
	    f.r = z__1.r, f.i = z__1.i;
	    i__4 = lam + mfftpa_1.mlim;
	    i__3 = mfftpa_1.mstep;
	    for (mu = lam; i__3 < 0 ? mu >= i__4 : mu <= i__4; mu += i__3) {
		i__6 = mu + mfftpa_1.ilim;
		i__5 = mfftpa_1.ies;
		for (i__ = mu; i__5 < 0 ? i__ >= i__6 : i__ <= i__6; i__ += 
			i__5) {
		    i__7 = i__ + c_dim1;
		    z__1.r = c__[i__7].r * f.r - c__[i__7].i * f.i, z__1.i = 
			    c__[i__7].r * f.i + c__[i__7].i * f.r;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__;
		    z__1.r = c__[i__8].r - t0.r, z__1.i = c__[i__8].i - t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__;
		    i__8 = i__;
		    z__1.r = c__[i__8].r + t0.r, z__1.i = c__[i__8].i + t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L81: */
		}
/* L91: */
	    }
	    lamf -= mfftpa_1.mx;
/* L101: */
	}
	i__1 = mfftpa_1.ld2lim + mfftpa_1.lstep + mfftpa_1.mlim;
	i__2 = mfftpa_1.mstep;
	for (mu = mfftpa_1.ld2lim + mfftpa_1.lstep; i__2 < 0 ? mu >= i__1 : 
		mu <= i__1; mu += i__2) {
	    i__3 = mu + mfftpa_1.ilim;
	    i__4 = mfftpa_1.ies;
	    for (i__ = mu; i__4 < 0 ? i__ >= i__3 : i__ <= i__3; i__ += i__4) 
		    {
		d__1 = -d_imag(&c__[i__ + c_dim1]);
		i__5 = i__ + c_dim1;
		d__2 = c__[i__5].r;
		z__1.r = d__1, z__1.i = d__2;
		t0.r = z__1.r, t0.i = z__1.i;
		i__5 = i__ + c_dim1;
		i__6 = i__;
		z__1.r = c__[i__6].r - t0.r, z__1.i = c__[i__6].i - t0.i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
		i__5 = i__;
		i__6 = i__;
		z__1.r = c__[i__6].r + t0.r, z__1.i = c__[i__6].i + t0.i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
/* L83: */
	    }
/* L93: */
	}
L1000:
	i__2 = mfftpa_1.mlim;
	i__1 = mfftpa_1.mstep;
	for (mu = 0; i__1 < 0 ? mu >= i__2 : mu <= i__2; mu += i__1) {
	    i__4 = mu + mfftpa_1.ilim;
	    i__3 = mfftpa_1.ies;
	    for (i__ = mu; i__3 < 0 ? i__ >= i__4 : i__ <= i__4; i__ += i__3) 
		    {
		i__5 = i__ + c_dim1;
		t0.r = c__[i__5].r, t0.i = c__[i__5].i;
		i__5 = i__ + c_dim1;
		i__6 = i__;
		z__1.r = c__[i__6].r - t0.r, z__1.i = c__[i__6].i - t0.i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
		i__5 = i__;
		i__6 = i__;
		z__1.r = c__[i__6].r + t0.r, z__1.i = c__[i__6].i + t0.i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
/* L82: */
	    }
/* L92: */
	}
    } else {
	i__1 = mfftpa_1.mlim;
	i__2 = mfftpa_1.mstep;
	for (mu = 0; i__2 < 0 ? mu >= i__1 : mu <= i__1; mu += i__2) {
	    lamf = mfftpa_1.mx;
	    i__3 = mu + mfftpa_1.ld2lim;
	    i__4 = mfftpa_1.lstep;
	    for (lam = mu + mfftpa_1.lstep; i__4 < 0 ? lam >= i__3 : lam <= 
		    i__3; lam += i__4) {
		i__5 = lamf;
		f.r = fac[i__5].r, f.i = fac[i__5].i;
		i__5 = lam + mfftpa_1.ilim;
		i__6 = mfftpa_1.ies;
		for (i__ = lam; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += 
			i__6) {
		    i__7 = i__ + c_dim1;
		    z__1.r = c__[i__7].r * f.r - c__[i__7].i * f.i, z__1.i = 
			    c__[i__7].r * f.i + c__[i__7].i * f.r;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__;
		    z__1.r = c__[i__8].r - t0.r, z__1.i = c__[i__8].i - t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__;
		    i__8 = i__;
		    z__1.r = c__[i__8].r + t0.r, z__1.i = c__[i__8].i + t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L180: */
		}
		lamf += mfftpa_1.mx;
/* L190: */
	    }
	    lamf -= mfftpa_1.mx;
	    i__4 = mu + mfftpa_1.llim;
	    i__3 = mfftpa_1.lstep;
	    for (lam = mu + mfftpa_1.ld2lim + (mfftpa_1.lstep << 1); i__3 < 0 
		    ? lam >= i__4 : lam <= i__4; lam += i__3) {
		d_cnjg(&z__2, &fac[lamf]);
		z__1.r = -z__2.r, z__1.i = -z__2.i;
		f.r = z__1.r, f.i = z__1.i;
		i__6 = lam + mfftpa_1.ilim;
		i__5 = mfftpa_1.ies;
		for (i__ = lam; i__5 < 0 ? i__ >= i__6 : i__ <= i__6; i__ += 
			i__5) {
		    i__7 = i__ + c_dim1;
		    z__1.r = c__[i__7].r * f.r - c__[i__7].i * f.i, z__1.i = 
			    c__[i__7].r * f.i + c__[i__7].i * f.r;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__;
		    z__1.r = c__[i__8].r - t0.r, z__1.i = c__[i__8].i - t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__;
		    i__8 = i__;
		    z__1.r = c__[i__8].r + t0.r, z__1.i = c__[i__8].i + t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L181: */
		}
		lamf -= mfftpa_1.mx;
/* L191: */
	    }
	    i__3 = mu + mfftpa_1.ilim;
	    i__4 = mfftpa_1.ies;
	    for (i__ = mu; i__4 < 0 ? i__ >= i__3 : i__ <= i__3; i__ += i__4) 
		    {
		i__5 = i__ + c_dim1;
		t0.r = c__[i__5].r, t0.i = c__[i__5].i;
		i__5 = i__ + c_dim1;
		i__6 = i__;
		z__1.r = c__[i__6].r - t0.r, z__1.i = c__[i__6].i - t0.i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
		i__5 = i__;
		i__6 = i__;
		z__1.r = c__[i__6].r + t0.r, z__1.i = c__[i__6].i + t0.i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
/* L182: */
	    }
	    i__4 = mu + mfftpa_1.ld2lim + mfftpa_1.lstep + mfftpa_1.ilim;
	    i__3 = mfftpa_1.ies;
	    for (i__ = mu + mfftpa_1.ld2lim + mfftpa_1.lstep; i__3 < 0 ? i__ 
		    >= i__4 : i__ <= i__4; i__ += i__3) {
		d__1 = -d_imag(&c__[i__ + c_dim1]);
		i__5 = i__ + c_dim1;
		d__2 = c__[i__5].r;
		z__1.r = d__1, z__1.i = d__2;
		t0.r = z__1.r, t0.i = z__1.i;
		i__5 = i__ + c_dim1;
		i__6 = i__;
		z__1.r = c__[i__6].r - t0.r, z__1.i = c__[i__6].i - t0.i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
		i__5 = i__;
		i__6 = i__;
		z__1.r = c__[i__6].r + t0.r, z__1.i = c__[i__6].i + t0.i;
		c__[i__5].r = z__1.r, c__[i__5].i = z__1.i;
/* L183: */
	    }
/* L200: */
	}
    }
} /* mffta5_ */

/* Subroutine */ int mffta6_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8, i__9, 
	    i__10;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3;

    /* Builtin functions */
    void d_cnjg();
    double d_imag();

    /* Local variables */
    doublecomplex f;
    integer i__;
    doublecomplex t0;
    integer iv, mu, lam, muf;


/*   purpose: */
/*       elementary gentleman-sande radix 2 step applied to a vector-of */
/*       2-vectors-of-complex c[ims,nm [ivs,nv [ies,ne]]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftdm, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    if (mfftpa_1.mx > mfftpa_1.lx << 1) {
	i__1 = mfftpa_1.llim;
	i__2 = mfftpa_1.lstep;
	for (lam = 0; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam += i__2) {
	    muf = mfftpa_1.lx;
	    i__3 = lam + mfftpa_1.md2lim;
	    i__4 = mfftpa_1.mstep;
	    for (mu = lam + mfftpa_1.mstep; i__4 < 0 ? mu >= i__3 : mu <= 
		    i__3; mu += i__4) {
		d_cnjg(&z__1, &fac[muf]);
		f.r = z__1.r, f.i = z__1.i;
		i__5 = mu + mfftpa_1.ivlim;
		i__6 = mfftpa_1.ivs;
		for (iv = mu; i__6 < 0 ? iv >= i__5 : iv <= i__5; iv += i__6) 
			{
		    i__7 = iv + mfftpa_1.ilim;
		    i__8 = mfftpa_1.ies;
		    for (i__ = iv; i__8 < 0 ? i__ >= i__7 : i__ <= i__7; i__ 
			    += i__8) {
			i__9 = i__;
			t0.r = c__[i__9].r, t0.i = c__[i__9].i;
			i__9 = i__;
			i__10 = i__ + c_dim1;
			z__1.r = t0.r + c__[i__10].r, z__1.i = t0.i + c__[
				i__10].i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
			i__9 = i__ + c_dim1;
			i__10 = i__ + c_dim1;
			z__2.r = t0.r - c__[i__10].r, z__2.i = t0.i - c__[
				i__10].i;
			z__1.r = z__2.r * f.r - z__2.i * f.i, z__1.i = z__2.r 
				* f.i + z__2.i * f.r;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L80: */
		    }
		}
		muf += mfftpa_1.lx;
/* L90: */
	    }
	    muf -= mfftpa_1.lx;
	    i__4 = lam + mfftpa_1.mlim;
	    i__3 = mfftpa_1.mstep;
	    for (mu = lam + mfftpa_1.md2lim + (mfftpa_1.mstep << 1); i__3 < 0 
		    ? mu >= i__4 : mu <= i__4; mu += i__3) {
		i__8 = muf;
		z__1.r = -fac[i__8].r, z__1.i = -fac[i__8].i;
		f.r = z__1.r, f.i = z__1.i;
		i__8 = mu + mfftpa_1.ivlim;
		i__7 = mfftpa_1.ivs;
		for (iv = mu; i__7 < 0 ? iv >= i__8 : iv <= i__8; iv += i__7) 
			{
		    i__6 = iv + mfftpa_1.ilim;
		    i__5 = mfftpa_1.ies;
		    for (i__ = iv; i__5 < 0 ? i__ >= i__6 : i__ <= i__6; i__ 
			    += i__5) {
			i__9 = i__;
			t0.r = c__[i__9].r, t0.i = c__[i__9].i;
			i__9 = i__;
			i__10 = i__ + c_dim1;
			z__1.r = t0.r + c__[i__10].r, z__1.i = t0.i + c__[
				i__10].i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
			i__9 = i__ + c_dim1;
			i__10 = i__ + c_dim1;
			z__2.r = t0.r - c__[i__10].r, z__2.i = t0.i - c__[
				i__10].i;
			z__1.r = z__2.r * f.r - z__2.i * f.i, z__1.i = z__2.r 
				* f.i + z__2.i * f.r;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L81: */
		    }
		}
		muf -= mfftpa_1.lx;
/* L91: */
	    }
	    i__3 = mfftpa_1.md2lim + mfftpa_1.mstep + lam + mfftpa_1.ivlim;
	    i__4 = mfftpa_1.ivs;
	    for (iv = mfftpa_1.md2lim + mfftpa_1.mstep + lam; i__4 < 0 ? iv >=
		     i__3 : iv <= i__3; iv += i__4) {
		i__5 = iv + mfftpa_1.ilim;
		i__6 = mfftpa_1.ies;
		for (i__ = iv; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += 
			i__6) {
		    i__7 = i__;
		    t0.r = c__[i__7].r, t0.i = c__[i__7].i;
		    i__7 = i__;
		    i__8 = i__ + c_dim1;
		    z__1.r = t0.r + c__[i__8].r, z__1.i = t0.i + c__[i__8].i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__ + c_dim1;
		    z__2.r = t0.r - c__[i__8].r, z__2.i = t0.i - c__[i__8].i;
		    d__1 = d_imag(&z__2);
		    i__9 = i__ + c_dim1;
		    z__3.r = t0.r - c__[i__9].r, z__3.i = t0.i - c__[i__9].i;
		    d__2 = -z__3.r;
		    z__1.r = d__1, z__1.i = d__2;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L82: */
		}
	    }
	    i__6 = lam + mfftpa_1.ivlim;
	    i__5 = mfftpa_1.ivs;
	    for (iv = lam; i__5 < 0 ? iv >= i__6 : iv <= i__6; iv += i__5) {
		i__4 = iv + mfftpa_1.ilim;
		i__3 = mfftpa_1.ies;
		for (i__ = iv; i__3 < 0 ? i__ >= i__4 : i__ <= i__4; i__ += 
			i__3) {
		    i__7 = i__;
		    t0.r = c__[i__7].r, t0.i = c__[i__7].i;
		    i__7 = i__;
		    i__8 = i__ + c_dim1;
		    z__1.r = t0.r + c__[i__8].r, z__1.i = t0.i + c__[i__8].i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__ + c_dim1;
		    z__1.r = t0.r - c__[i__8].r, z__1.i = t0.i - c__[i__8].i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L83: */
		}
	    }
/* L100: */
	}
    } else {
	if (mfftpa_1.mx == 1) {
	    goto L1000;
	}
/* if mx > 1 come here */
	muf = mfftpa_1.lx;
	i__2 = mfftpa_1.md2lim;
	i__1 = mfftpa_1.mstep;
	for (mu = mfftpa_1.mstep; i__1 < 0 ? mu >= i__2 : mu <= i__2; mu += 
		i__1) {
	    d_cnjg(&z__1, &fac[muf]);
	    f.r = z__1.r, f.i = z__1.i;
	    i__3 = mu + mfftpa_1.llim;
	    i__4 = mfftpa_1.lstep;
	    for (lam = mu; i__4 < 0 ? lam >= i__3 : lam <= i__3; lam += i__4) 
		    {
		i__5 = lam + mfftpa_1.ivlim;
		i__6 = mfftpa_1.ivs;
		for (iv = lam; i__6 < 0 ? iv >= i__5 : iv <= i__5; iv += i__6)
			 {
		    i__7 = iv + mfftpa_1.ilim;
		    i__8 = mfftpa_1.ies;
		    for (i__ = iv; i__8 < 0 ? i__ >= i__7 : i__ <= i__7; i__ 
			    += i__8) {
			i__9 = i__;
			t0.r = c__[i__9].r, t0.i = c__[i__9].i;
			i__9 = i__;
			i__10 = i__ + c_dim1;
			z__1.r = t0.r + c__[i__10].r, z__1.i = t0.i + c__[
				i__10].i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
			i__9 = i__ + c_dim1;
			i__10 = i__ + c_dim1;
			z__2.r = t0.r - c__[i__10].r, z__2.i = t0.i - c__[
				i__10].i;
			z__1.r = z__2.r * f.r - z__2.i * f.i, z__1.i = z__2.r 
				* f.i + z__2.i * f.r;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L180: */
		    }
		}
/* L190: */
	    }
	    muf += mfftpa_1.lx;
/* L200: */
	}
	muf -= mfftpa_1.lx;
	i__1 = mfftpa_1.mlim;
	i__2 = mfftpa_1.mstep;
	for (mu = mfftpa_1.md2lim + (mfftpa_1.mstep << 1); i__2 < 0 ? mu >= 
		i__1 : mu <= i__1; mu += i__2) {
	    i__4 = muf;
	    z__1.r = -fac[i__4].r, z__1.i = -fac[i__4].i;
	    f.r = z__1.r, f.i = z__1.i;
	    i__4 = mu + mfftpa_1.llim;
	    i__3 = mfftpa_1.lstep;
	    for (lam = mu; i__3 < 0 ? lam >= i__4 : lam <= i__4; lam += i__3) 
		    {
		i__8 = lam + mfftpa_1.ivlim;
		i__7 = mfftpa_1.ivs;
		for (iv = lam; i__7 < 0 ? iv >= i__8 : iv <= i__8; iv += i__7)
			 {
		    i__6 = iv + mfftpa_1.ilim;
		    i__5 = mfftpa_1.ies;
		    for (i__ = iv; i__5 < 0 ? i__ >= i__6 : i__ <= i__6; i__ 
			    += i__5) {
			i__9 = i__;
			t0.r = c__[i__9].r, t0.i = c__[i__9].i;
			i__9 = i__;
			i__10 = i__ + c_dim1;
			z__1.r = t0.r + c__[i__10].r, z__1.i = t0.i + c__[
				i__10].i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
			i__9 = i__ + c_dim1;
			i__10 = i__ + c_dim1;
			z__2.r = t0.r - c__[i__10].r, z__2.i = t0.i - c__[
				i__10].i;
			z__1.r = z__2.r * f.r - z__2.i * f.i, z__1.i = z__2.r 
				* f.i + z__2.i * f.r;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L181: */
		    }
		}
/* L191: */
	    }
	    muf -= mfftpa_1.lx;
/* L201: */
	}
	i__2 = mfftpa_1.md2lim + mfftpa_1.mstep + mfftpa_1.llim;
	i__1 = mfftpa_1.lstep;
	for (lam = mfftpa_1.md2lim + mfftpa_1.mstep; i__1 < 0 ? lam >= i__2 : 
		lam <= i__2; lam += i__1) {
	    i__3 = lam + mfftpa_1.ivlim;
	    i__4 = mfftpa_1.ivs;
	    for (iv = lam; i__4 < 0 ? iv >= i__3 : iv <= i__3; iv += i__4) {
		i__5 = iv + mfftpa_1.ilim;
		i__6 = mfftpa_1.ies;
		for (i__ = iv; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += 
			i__6) {
		    i__7 = i__;
		    t0.r = c__[i__7].r, t0.i = c__[i__7].i;
		    i__7 = i__;
		    i__8 = i__ + c_dim1;
		    z__1.r = t0.r + c__[i__8].r, z__1.i = t0.i + c__[i__8].i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__ + c_dim1;
		    z__2.r = t0.r - c__[i__8].r, z__2.i = t0.i - c__[i__8].i;
		    d__1 = d_imag(&z__2);
		    i__9 = i__ + c_dim1;
		    z__3.r = t0.r - c__[i__9].r, z__3.i = t0.i - c__[i__9].i;
		    d__2 = -z__3.r;
		    z__1.r = d__1, z__1.i = d__2;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L182: */
		}
	    }
/* L192: */
	}
L1000:
	i__1 = mfftpa_1.llim;
	i__2 = mfftpa_1.lstep;
	for (lam = 0; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam += i__2) {
	    i__6 = lam + mfftpa_1.ivlim;
	    i__5 = mfftpa_1.ivs;
	    for (iv = lam; i__5 < 0 ? iv >= i__6 : iv <= i__6; iv += i__5) {
		i__4 = iv + mfftpa_1.ilim;
		i__3 = mfftpa_1.ies;
		for (i__ = iv; i__3 < 0 ? i__ >= i__4 : i__ <= i__4; i__ += 
			i__3) {
		    i__7 = i__;
		    t0.r = c__[i__7].r, t0.i = c__[i__7].i;
		    i__7 = i__;
		    i__8 = i__ + c_dim1;
		    z__1.r = t0.r + c__[i__8].r, z__1.i = t0.i + c__[i__8].i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__ + c_dim1;
		    z__1.r = t0.r - c__[i__8].r, z__1.i = t0.i - c__[i__8].i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L183: */
		}
	    }
/* L193: */
	}
    }
} /* mffta6_ */

/* Subroutine */ int mffta7_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8, i__9, 
	    i__10;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2;

    /* Builtin functions */
    void d_cnjg();
    double d_imag();

    /* Local variables */
    integer lamf;
    doublecomplex f;
    integer i__;
    doublecomplex t0;
    integer iv, mu, lam;


/*   purpose: */
/*       elementary cooley-tukey radix 2 step applied to a vector-of */
/*       2-vectors-of-complex c[ims,nm [ivs,nv [ies,ne]]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftim, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    if (mfftpa_1.mx << 1 > mfftpa_1.lx) {
	if (mfftpa_1.lx == 1) {
	    goto L1000;
	}
/*   else here */
	lamf = mfftpa_1.mx;
	i__1 = mfftpa_1.ld2lim;
	i__2 = mfftpa_1.lstep;
	for (lam = mfftpa_1.lstep; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam 
		+= i__2) {
	    i__3 = lamf;
	    f.r = fac[i__3].r, f.i = fac[i__3].i;
	    i__3 = lam + mfftpa_1.mlim;
	    i__4 = mfftpa_1.mstep;
	    for (mu = lam; i__4 < 0 ? mu >= i__3 : mu <= i__3; mu += i__4) {
		i__5 = mu + mfftpa_1.ivlim;
		i__6 = mfftpa_1.ivs;
		for (iv = mu; i__6 < 0 ? iv >= i__5 : iv <= i__5; iv += i__6) 
			{
		    i__7 = iv + mfftpa_1.ilim;
		    i__8 = mfftpa_1.ies;
		    for (i__ = iv; i__8 < 0 ? i__ >= i__7 : i__ <= i__7; i__ 
			    += i__8) {
			i__9 = i__ + c_dim1;
			z__1.r = c__[i__9].r * f.r - c__[i__9].i * f.i, 
				z__1.i = c__[i__9].r * f.i + c__[i__9].i * 
				f.r;
			t0.r = z__1.r, t0.i = z__1.i;
			i__9 = i__ + c_dim1;
			i__10 = i__;
			z__1.r = c__[i__10].r - t0.r, z__1.i = c__[i__10].i - 
				t0.i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
			i__9 = i__;
			i__10 = i__;
			z__1.r = c__[i__10].r + t0.r, z__1.i = c__[i__10].i + 
				t0.i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L80: */
		    }
		}
/* L90: */
	    }
	    lamf += mfftpa_1.mx;
/* L100: */
	}
	lamf -= mfftpa_1.mx;
	i__2 = mfftpa_1.llim;
	i__1 = mfftpa_1.lstep;
	for (lam = mfftpa_1.ld2lim + (mfftpa_1.lstep << 1); i__1 < 0 ? lam >= 
		i__2 : lam <= i__2; lam += i__1) {
	    d_cnjg(&z__2, &fac[lamf]);
	    z__1.r = -z__2.r, z__1.i = -z__2.i;
	    f.r = z__1.r, f.i = z__1.i;
	    i__4 = lam + mfftpa_1.mlim;
	    i__3 = mfftpa_1.mstep;
	    for (mu = lam; i__3 < 0 ? mu >= i__4 : mu <= i__4; mu += i__3) {
		i__8 = mu + mfftpa_1.ivlim;
		i__7 = mfftpa_1.ivs;
		for (iv = mu; i__7 < 0 ? iv >= i__8 : iv <= i__8; iv += i__7) 
			{
		    i__6 = iv + mfftpa_1.ilim;
		    i__5 = mfftpa_1.ies;
		    for (i__ = iv; i__5 < 0 ? i__ >= i__6 : i__ <= i__6; i__ 
			    += i__5) {
			i__9 = i__ + c_dim1;
			z__1.r = c__[i__9].r * f.r - c__[i__9].i * f.i, 
				z__1.i = c__[i__9].r * f.i + c__[i__9].i * 
				f.r;
			t0.r = z__1.r, t0.i = z__1.i;
			i__9 = i__ + c_dim1;
			i__10 = i__;
			z__1.r = c__[i__10].r - t0.r, z__1.i = c__[i__10].i - 
				t0.i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
			i__9 = i__;
			i__10 = i__;
			z__1.r = c__[i__10].r + t0.r, z__1.i = c__[i__10].i + 
				t0.i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L81: */
		    }
		}
/* L91: */
	    }
	    lamf -= mfftpa_1.mx;
/* L101: */
	}
	i__1 = mfftpa_1.ld2lim + mfftpa_1.lstep + mfftpa_1.mlim;
	i__2 = mfftpa_1.mstep;
	for (mu = mfftpa_1.ld2lim + mfftpa_1.lstep; i__2 < 0 ? mu >= i__1 : 
		mu <= i__1; mu += i__2) {
	    i__3 = mu + mfftpa_1.ivlim;
	    i__4 = mfftpa_1.ivs;
	    for (iv = mu; i__4 < 0 ? iv >= i__3 : iv <= i__3; iv += i__4) {
		i__5 = iv + mfftpa_1.ilim;
		i__6 = mfftpa_1.ies;
		for (i__ = iv; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += 
			i__6) {
		    d__1 = -d_imag(&c__[i__ + c_dim1]);
		    i__7 = i__ + c_dim1;
		    d__2 = c__[i__7].r;
		    z__1.r = d__1, z__1.i = d__2;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__;
		    z__1.r = c__[i__8].r - t0.r, z__1.i = c__[i__8].i - t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__;
		    i__8 = i__;
		    z__1.r = c__[i__8].r + t0.r, z__1.i = c__[i__8].i + t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L83: */
		}
	    }
/* L93: */
	}
L1000:
	i__2 = mfftpa_1.mlim;
	i__1 = mfftpa_1.mstep;
	for (mu = 0; i__1 < 0 ? mu >= i__2 : mu <= i__2; mu += i__1) {
	    i__6 = mu + mfftpa_1.ivlim;
	    i__5 = mfftpa_1.ivs;
	    for (iv = mu; i__5 < 0 ? iv >= i__6 : iv <= i__6; iv += i__5) {
		i__4 = iv + mfftpa_1.ilim;
		i__3 = mfftpa_1.ies;
		for (i__ = iv; i__3 < 0 ? i__ >= i__4 : i__ <= i__4; i__ += 
			i__3) {
		    i__7 = i__ + c_dim1;
		    t0.r = c__[i__7].r, t0.i = c__[i__7].i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__;
		    z__1.r = c__[i__8].r - t0.r, z__1.i = c__[i__8].i - t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__;
		    i__8 = i__;
		    z__1.r = c__[i__8].r + t0.r, z__1.i = c__[i__8].i + t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L82: */
		}
	    }
/* L92: */
	}
    } else {
	i__1 = mfftpa_1.mlim;
	i__2 = mfftpa_1.mstep;
	for (mu = 0; i__2 < 0 ? mu >= i__1 : mu <= i__1; mu += i__2) {
	    lamf = mfftpa_1.mx;
	    i__3 = mu + mfftpa_1.ld2lim;
	    i__4 = mfftpa_1.lstep;
	    for (lam = mu + mfftpa_1.lstep; i__4 < 0 ? lam >= i__3 : lam <= 
		    i__3; lam += i__4) {
		i__5 = lamf;
		f.r = fac[i__5].r, f.i = fac[i__5].i;
		i__5 = lam + mfftpa_1.ivlim;
		i__6 = mfftpa_1.ivs;
		for (iv = lam; i__6 < 0 ? iv >= i__5 : iv <= i__5; iv += i__6)
			 {
		    i__7 = iv + mfftpa_1.ilim;
		    i__8 = mfftpa_1.ies;
		    for (i__ = iv; i__8 < 0 ? i__ >= i__7 : i__ <= i__7; i__ 
			    += i__8) {
			i__9 = i__ + c_dim1;
			z__1.r = c__[i__9].r * f.r - c__[i__9].i * f.i, 
				z__1.i = c__[i__9].r * f.i + c__[i__9].i * 
				f.r;
			t0.r = z__1.r, t0.i = z__1.i;
			i__9 = i__ + c_dim1;
			i__10 = i__;
			z__1.r = c__[i__10].r - t0.r, z__1.i = c__[i__10].i - 
				t0.i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
			i__9 = i__;
			i__10 = i__;
			z__1.r = c__[i__10].r + t0.r, z__1.i = c__[i__10].i + 
				t0.i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L180: */
		    }
		}
		lamf += mfftpa_1.mx;
/* L190: */
	    }
	    lamf -= mfftpa_1.mx;
	    i__4 = mu + mfftpa_1.llim;
	    i__3 = mfftpa_1.lstep;
	    for (lam = mu + mfftpa_1.ld2lim + (mfftpa_1.lstep << 1); i__3 < 0 
		    ? lam >= i__4 : lam <= i__4; lam += i__3) {
		d_cnjg(&z__2, &fac[lamf]);
		z__1.r = -z__2.r, z__1.i = -z__2.i;
		f.r = z__1.r, f.i = z__1.i;
		i__8 = lam + mfftpa_1.ivlim;
		i__7 = mfftpa_1.ivs;
		for (iv = lam; i__7 < 0 ? iv >= i__8 : iv <= i__8; iv += i__7)
			 {
		    i__6 = iv + mfftpa_1.ilim;
		    i__5 = mfftpa_1.ies;
		    for (i__ = iv; i__5 < 0 ? i__ >= i__6 : i__ <= i__6; i__ 
			    += i__5) {
			i__9 = i__ + c_dim1;
			z__1.r = c__[i__9].r * f.r - c__[i__9].i * f.i, 
				z__1.i = c__[i__9].r * f.i + c__[i__9].i * 
				f.r;
			t0.r = z__1.r, t0.i = z__1.i;
			i__9 = i__ + c_dim1;
			i__10 = i__;
			z__1.r = c__[i__10].r - t0.r, z__1.i = c__[i__10].i - 
				t0.i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
			i__9 = i__;
			i__10 = i__;
			z__1.r = c__[i__10].r + t0.r, z__1.i = c__[i__10].i + 
				t0.i;
			c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L181: */
		    }
		}
		lamf -= mfftpa_1.mx;
/* L191: */
	    }
	    i__3 = mu + mfftpa_1.ivlim;
	    i__4 = mfftpa_1.ivs;
	    for (iv = mu; i__4 < 0 ? iv >= i__3 : iv <= i__3; iv += i__4) {
		i__5 = iv + mfftpa_1.ilim;
		i__6 = mfftpa_1.ies;
		for (i__ = iv; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += 
			i__6) {
		    i__7 = i__ + c_dim1;
		    t0.r = c__[i__7].r, t0.i = c__[i__7].i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__;
		    z__1.r = c__[i__8].r - t0.r, z__1.i = c__[i__8].i - t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__;
		    i__8 = i__;
		    z__1.r = c__[i__8].r + t0.r, z__1.i = c__[i__8].i + t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L182: */
		}
	    }
	    i__6 = mu + mfftpa_1.ld2lim + mfftpa_1.lstep + mfftpa_1.ivlim;
	    i__5 = mfftpa_1.ivs;
	    for (iv = mu + mfftpa_1.ld2lim + mfftpa_1.lstep; i__5 < 0 ? iv >= 
		    i__6 : iv <= i__6; iv += i__5) {
		i__4 = iv + mfftpa_1.ilim;
		i__3 = mfftpa_1.ies;
		for (i__ = iv; i__3 < 0 ? i__ >= i__4 : i__ <= i__4; i__ += 
			i__3) {
		    d__1 = -d_imag(&c__[i__ + c_dim1]);
		    i__7 = i__ + c_dim1;
		    d__2 = c__[i__7].r;
		    z__1.r = d__1, z__1.i = d__2;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__7 = i__ + c_dim1;
		    i__8 = i__;
		    z__1.r = c__[i__8].r - t0.r, z__1.i = c__[i__8].i - t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		    i__7 = i__;
		    i__8 = i__;
		    z__1.r = c__[i__8].r + t0.r, z__1.i = c__[i__8].i + t0.i;
		    c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L183: */
		}
	    }
/* L200: */
	}
    }
} /* mffta7_ */

/* Subroutine */ int mffta8_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8;
    doublecomplex z__1, z__2;

    /* Local variables */
    integer imuf;
    doublecomplex t0;
    integer iv, lam, imu;


/*   purpose: */
/*       elementary gentleman-sande radix-2 step applied to a vector-of- 
*/
/*       2-vectors-of-complex [ims,nm [ivs,nv [ies,ne]]], optimized for */
/*       small ne matrices. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftdm, which controls 
*/
/*       its operation through common mfftpa. */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */


    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    if (mfftpa_1.mx != 1) {

	i__1 = mfftpa_1.llim;
	i__2 = mfftpa_1.lstep;
	for (lam = 0; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam += i__2) {
	    i__3 = lam + mfftpa_1.ivlim;
	    i__4 = mfftpa_1.ivs;
	    for (iv = lam; i__4 < 0 ? iv >= i__3 : iv <= i__3; iv += i__4) {
		imuf = 0;
		i__5 = iv + mfftpa_1.ilim;
		for (imu = iv; imu <= i__5; ++imu) {
		    i__6 = imu;
		    t0.r = c__[i__6].r, t0.i = c__[i__6].i;
		    i__6 = imu;
		    i__7 = imu + c_dim1;
		    z__1.r = t0.r + c__[i__7].r, z__1.i = t0.i + c__[i__7].i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + c_dim1;
		    i__7 = imu + c_dim1;
		    z__2.r = t0.r - c__[i__7].r, z__2.i = t0.i - c__[i__7].i;
		    i__8 = imuf;
		    z__1.r = z__2.r * fac[i__8].r - z__2.i * fac[i__8].i, 
			    z__1.i = z__2.r * fac[i__8].i + z__2.i * fac[i__8]
			    .r;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    ++imuf;
/* L100: */
		}
/* L150: */
	    }
/* L200: */
	}

    } else {
	i__2 = mfftpa_1.llim;
	i__1 = mfftpa_1.lstep;
	for (lam = 0; i__1 < 0 ? lam >= i__2 : lam <= i__2; lam += i__1) {
	    i__4 = lam + mfftpa_1.ivlim;
	    i__3 = mfftpa_1.ivs;
	    for (iv = lam; i__3 < 0 ? iv >= i__4 : iv <= i__4; iv += i__3) {
		i__5 = iv + mfftpa_1.ilim;
		for (imu = iv; imu <= i__5; ++imu) {
		    i__6 = imu;
		    t0.r = c__[i__6].r, t0.i = c__[i__6].i;
		    i__6 = imu;
		    i__7 = imu + c_dim1;
		    z__1.r = t0.r + c__[i__7].r, z__1.i = t0.i + c__[i__7].i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + c_dim1;
		    i__7 = imu + c_dim1;
		    z__1.r = t0.r - c__[i__7].r, z__1.i = t0.i - c__[i__7].i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L300: */
		}
/* L350: */
	    }
/* L400: */
	}
    }

} /* mffta8_ */

/* Subroutine */ int mffta9_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7;
    doublecomplex z__1;

    /* Local variables */
    integer ilam, ilamf;
    doublecomplex t0;
    integer iv, mu;


/*   purpose: */
/*       elementary cooley-tukey radix-2 step applied to a vector-of- */
/*       2-vectors-of-complex [ims,nm [ivs,nv [ies,ne]]], optimized for */
/*       small ne matrices. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftim, which controls 
*/
/*       its operation through common mfftpa. */


    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    if (mfftpa_1.lx != 1) {

	i__1 = mfftpa_1.mlim;
	i__2 = mfftpa_1.mstep;
	for (mu = 0; i__2 < 0 ? mu >= i__1 : mu <= i__1; mu += i__2) {
	    i__3 = mu + mfftpa_1.ivlim;
	    i__4 = mfftpa_1.ivs;
	    for (iv = mu; i__4 < 0 ? iv >= i__3 : iv <= i__3; iv += i__4) {
		ilamf = 0;
		i__5 = iv + mfftpa_1.ilim;
		for (ilam = iv; ilam <= i__5; ++ilam) {
		    i__6 = ilam + c_dim1;
		    i__7 = ilamf;
		    z__1.r = c__[i__6].r * fac[i__7].r - c__[i__6].i * fac[
			    i__7].i, z__1.i = c__[i__6].r * fac[i__7].i + c__[
			    i__6].i * fac[i__7].r;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__6 = ilam + c_dim1;
		    i__7 = ilam;
		    z__1.r = c__[i__7].r - t0.r, z__1.i = c__[i__7].i - t0.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam;
		    i__7 = ilam;
		    z__1.r = c__[i__7].r + t0.r, z__1.i = c__[i__7].i + t0.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    ++ilamf;
/* L100: */
		}
/* L150: */
	    }
/* L200: */
	}

    } else {
	i__2 = mfftpa_1.mlim;
	i__1 = mfftpa_1.mstep;
	for (mu = 0; i__1 < 0 ? mu >= i__2 : mu <= i__2; mu += i__1) {
	    i__4 = mu + mfftpa_1.ivlim;
	    i__3 = mfftpa_1.ivs;
	    for (iv = mu; i__3 < 0 ? iv >= i__4 : iv <= i__4; iv += i__3) {
		i__5 = iv + mfftpa_1.ilim;
		for (ilam = iv; ilam <= i__5; ++ilam) {
		    i__6 = ilam + c_dim1;
		    t0.r = c__[i__6].r, t0.i = c__[i__6].i;
		    i__6 = ilam + c_dim1;
		    i__7 = ilam;
		    z__1.r = c__[i__7].r - t0.r, z__1.i = c__[i__7].i - t0.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam;
		    i__7 = ilam;
		    z__1.r = c__[i__7].r + t0.r, z__1.i = c__[i__7].i + t0.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L300: */
		}
/* L350: */
	    }
/* L400: */
	}
    }

} /* mffta9_ */

/* Subroutine */ int mfftb4_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3;

    /* Builtin functions */
    void d_cnjg();
    double d_imag();

    /* Local variables */
    integer i__;
    doublecomplex f1, f2, t0, t1, t2;
    integer mu, lam, muf;


/*   purpose: */
/*       elementary gentleman-sande radix 3 step applied to a vector-of */
/*       vectors-of-complex c[ivs,nv [ies,ne]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftdv, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

/* ..  mu > 1 */
    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    muf = mfftpa_1.lx;
    i__1 = mfftpa_1.mlim;
    i__2 = mfftpa_1.mstep;
    for (mu = mfftpa_1.mstep; i__2 < 0 ? mu >= i__1 : mu <= i__1; mu += i__2) 
	    {
	d_cnjg(&z__1, &fac[muf]);
	f1.r = z__1.r, f1.i = z__1.i;
	d_cnjg(&z__1, &fac[muf * 2]);
	f2.r = z__1.r, f2.i = z__1.i;
	i__3 = mu + mfftpa_1.llim;
	i__4 = mfftpa_1.lstep;
	for (lam = mu; i__4 < 0 ? lam >= i__3 : lam <= i__3; lam += i__4) {
	    i__5 = lam + mfftpa_1.ilim;
	    i__6 = mfftpa_1.ies;
	    for (i__ = lam; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += i__6)
		     {
		i__7 = i__ + c_dim1;
		i__8 = i__ + (c_dim1 << 1);
		z__1.r = c__[i__7].r + c__[i__8].r, z__1.i = c__[i__7].i + 
			c__[i__8].i;
		t0.r = z__1.r, t0.i = z__1.i;
		i__7 = i__;
		z__2.r = t0.r * .5, z__2.i = t0.i * .5;
		z__1.r = c__[i__7].r - z__2.r, z__1.i = c__[i__7].i - z__2.i;
		t1.r = z__1.r, t1.i = z__1.i;
		i__7 = i__ + c_dim1;
		i__8 = i__ + (c_dim1 << 1);
		z__2.r = c__[i__7].r - c__[i__8].r, z__2.i = c__[i__7].i - 
			c__[i__8].i;
		z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
			.86602540378443864;
		t2.r = z__1.r, t2.i = z__1.i;
		i__7 = i__;
		i__8 = i__;
		z__1.r = c__[i__8].r + t0.r, z__1.i = c__[i__8].i + t0.i;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		i__7 = i__ + c_dim1;
		d__1 = -d_imag(&t2);
		d__2 = t2.r;
		z__3.r = d__1, z__3.i = d__2;
		z__2.r = t1.r - z__3.r, z__2.i = t1.i - z__3.i;
		z__1.r = z__2.r * f1.r - z__2.i * f1.i, z__1.i = z__2.r * 
			f1.i + z__2.i * f1.r;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		i__7 = i__ + (c_dim1 << 1);
		d__1 = -d_imag(&t2);
		d__2 = t2.r;
		z__3.r = d__1, z__3.i = d__2;
		z__2.r = t1.r + z__3.r, z__2.i = t1.i + z__3.i;
		z__1.r = z__2.r * f2.r - z__2.i * f2.i, z__1.i = z__2.r * 
			f2.i + z__2.i * f2.r;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L180: */
	    }
/* L190: */
	}
	muf += mfftpa_1.lx;
/* L200: */
    }
/* ..  mu=0 */
/* L1000: */
    i__2 = mfftpa_1.llim;
    i__1 = mfftpa_1.lstep;
    for (lam = 0; i__1 < 0 ? lam >= i__2 : lam <= i__2; lam += i__1) {
	i__4 = lam + mfftpa_1.ilim;
	i__3 = mfftpa_1.ies;
	for (i__ = lam; i__3 < 0 ? i__ >= i__4 : i__ <= i__4; i__ += i__3) {
	    i__6 = i__ + c_dim1;
	    i__5 = i__ + (c_dim1 << 1);
	    z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + c__[
		    i__5].i;
	    t0.r = z__1.r, t0.i = z__1.i;
	    i__6 = i__;
	    z__2.r = t0.r * .5, z__2.i = t0.i * .5;
	    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - z__2.i;
	    t1.r = z__1.r, t1.i = z__1.i;
	    i__6 = i__ + c_dim1;
	    i__5 = i__ + (c_dim1 << 1);
	    z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - c__[
		    i__5].i;
	    z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
		    .86602540378443864;
	    t2.r = z__1.r, t2.i = z__1.i;
	    i__6 = i__;
	    i__5 = i__;
	    z__1.r = c__[i__5].r + t0.r, z__1.i = c__[i__5].i + t0.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    i__6 = i__ + c_dim1;
	    d__1 = -d_imag(&t2);
	    d__2 = t2.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t1.r - z__2.r, z__1.i = t1.i - z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    i__6 = i__ + (c_dim1 << 1);
	    d__1 = -d_imag(&t2);
	    d__2 = t2.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t1.r + z__2.r, z__1.i = t1.i + z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L183: */
	}
/* L193: */
    }
} /* mfftb4_ */

/* Subroutine */ int mfftb5_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3, z__4;

    /* Builtin functions */
    double d_imag();

    /* Local variables */
    integer lamf, i__;
    doublecomplex f1, f2, t0, t1, t2;
    integer mu, lam;


/*   purpose: */
/*       elementary cooley-tukey radix 3 step applied to a vector-of */
/*       vectors-of-complex c[ivs,nv [ies,ne]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftiv, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

/* ..  lam > 0 */
    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    lamf = mfftpa_1.mx;
    i__1 = mfftpa_1.llim;
    i__2 = mfftpa_1.lstep;
    for (lam = mfftpa_1.lstep; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam += 
	    i__2) {
	i__3 = lamf;
	f1.r = fac[i__3].r, f1.i = fac[i__3].i;
	i__3 = lamf << 1;
	f2.r = fac[i__3].r, f2.i = fac[i__3].i;
	i__3 = lam + mfftpa_1.mlim;
	i__4 = mfftpa_1.mstep;
	for (mu = lam; i__4 < 0 ? mu >= i__3 : mu <= i__3; mu += i__4) {
	    i__5 = mu + mfftpa_1.ilim;
	    i__6 = mfftpa_1.ies;
	    for (i__ = mu; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += i__6) 
		    {
		i__7 = i__ + c_dim1;
		z__2.r = c__[i__7].r * f1.r - c__[i__7].i * f1.i, z__2.i = 
			c__[i__7].r * f1.i + c__[i__7].i * f1.r;
		i__8 = i__ + (c_dim1 << 1);
		z__3.r = c__[i__8].r * f2.r - c__[i__8].i * f2.i, z__3.i = 
			c__[i__8].r * f2.i + c__[i__8].i * f2.r;
		z__1.r = z__2.r + z__3.r, z__1.i = z__2.i + z__3.i;
		t0.r = z__1.r, t0.i = z__1.i;
		i__7 = i__ + c_dim1;
		z__3.r = c__[i__7].r * f1.r - c__[i__7].i * f1.i, z__3.i = 
			c__[i__7].r * f1.i + c__[i__7].i * f1.r;
		i__8 = i__ + (c_dim1 << 1);
		z__4.r = c__[i__8].r * f2.r - c__[i__8].i * f2.i, z__4.i = 
			c__[i__8].r * f2.i + c__[i__8].i * f2.r;
		z__2.r = z__3.r - z__4.r, z__2.i = z__3.i - z__4.i;
		z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
			.86602540378443864;
		t2.r = z__1.r, t2.i = z__1.i;
		i__7 = i__;
		z__2.r = t0.r * .5, z__2.i = t0.i * .5;
		z__1.r = c__[i__7].r - z__2.r, z__1.i = c__[i__7].i - z__2.i;
		t1.r = z__1.r, t1.i = z__1.i;
		i__7 = i__;
		i__8 = i__;
		z__1.r = c__[i__8].r + t0.r, z__1.i = c__[i__8].i + t0.i;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		i__7 = i__ + c_dim1;
		d__1 = -d_imag(&t2);
		d__2 = t2.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t1.r + z__2.r, z__1.i = t1.i + z__2.i;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		i__7 = i__ + (c_dim1 << 1);
		d__1 = -d_imag(&t2);
		d__2 = t2.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t1.r - z__2.r, z__1.i = t1.i - z__2.i;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L80: */
	    }
/* L90: */
	}
	lamf += mfftpa_1.mx;
/* L100: */
    }
/* .. lam=0 */
    i__2 = mfftpa_1.mlim;
    i__1 = mfftpa_1.mstep;
    for (mu = 0; i__1 < 0 ? mu >= i__2 : mu <= i__2; mu += i__1) {
	i__4 = mu + mfftpa_1.ilim;
	i__3 = mfftpa_1.ies;
	for (i__ = mu; i__3 < 0 ? i__ >= i__4 : i__ <= i__4; i__ += i__3) {
	    i__6 = i__ + c_dim1;
	    i__5 = i__ + (c_dim1 << 1);
	    z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + c__[
		    i__5].i;
	    t0.r = z__1.r, t0.i = z__1.i;
	    i__6 = i__ + c_dim1;
	    i__5 = i__ + (c_dim1 << 1);
	    z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - c__[
		    i__5].i;
	    z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
		    .86602540378443864;
	    t2.r = z__1.r, t2.i = z__1.i;
	    i__6 = i__;
	    z__2.r = t0.r * .5, z__2.i = t0.i * .5;
	    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - z__2.i;
	    t1.r = z__1.r, t1.i = z__1.i;
	    i__6 = i__;
	    i__5 = i__;
	    z__1.r = c__[i__5].r + t0.r, z__1.i = c__[i__5].i + t0.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    i__6 = i__ + c_dim1;
	    d__1 = -d_imag(&t2);
	    d__2 = t2.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t1.r + z__2.r, z__1.i = t1.i + z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    i__6 = i__ + (c_dim1 << 1);
	    d__1 = -d_imag(&t2);
	    d__2 = t2.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t1.r - z__2.r, z__1.i = t1.i - z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L82: */
	}
/* L92: */
    }
} /* mfftb5_ */

/* Subroutine */ int mfftb6_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8, i__9, 
	    i__10;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3;

    /* Builtin functions */
    void d_cnjg();
    double d_imag();

    /* Local variables */
    integer i__;
    doublecomplex f1, f2, t0, t1, t2;
    integer iv, mu, lam, muf;


/*   purpose: */
/*       elementary gentleman-sande radix 3 step applied to a vector-of */
/*       2-vectors-of-complex c[ims,nm [ivs,nv [ies,ne]]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftdm, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

/* ..  mu > 0 */
    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    muf = mfftpa_1.lx;
    i__1 = mfftpa_1.mlim;
    i__2 = mfftpa_1.mstep;
    for (mu = mfftpa_1.mstep; i__2 < 0 ? mu >= i__1 : mu <= i__1; mu += i__2) 
	    {
	d_cnjg(&z__1, &fac[muf]);
	f1.r = z__1.r, f1.i = z__1.i;
	d_cnjg(&z__1, &fac[muf * 2]);
	f2.r = z__1.r, f2.i = z__1.i;
	i__3 = mu + mfftpa_1.llim;
	i__4 = mfftpa_1.lstep;
	for (lam = mu; i__4 < 0 ? lam >= i__3 : lam <= i__3; lam += i__4) {
	    i__5 = lam + mfftpa_1.ivlim;
	    i__6 = mfftpa_1.ivs;
	    for (iv = lam; i__6 < 0 ? iv >= i__5 : iv <= i__5; iv += i__6) {
		i__7 = iv + mfftpa_1.ilim;
		i__8 = mfftpa_1.ies;
		for (i__ = iv; i__8 < 0 ? i__ >= i__7 : i__ <= i__7; i__ += 
			i__8) {
		    i__9 = i__ + c_dim1;
		    i__10 = i__ + (c_dim1 << 1);
		    z__1.r = c__[i__9].r + c__[i__10].r, z__1.i = c__[i__9].i 
			    + c__[i__10].i;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__9 = i__ + c_dim1;
		    i__10 = i__ + (c_dim1 << 1);
		    z__2.r = c__[i__9].r - c__[i__10].r, z__2.i = c__[i__9].i 
			    - c__[i__10].i;
		    z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
			    .86602540378443864;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__9 = i__;
		    z__2.r = t0.r * .5, z__2.i = t0.i * .5;
		    z__1.r = c__[i__9].r - z__2.r, z__1.i = c__[i__9].i - 
			    z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__9 = i__;
		    i__10 = i__;
		    z__1.r = c__[i__10].r + t0.r, z__1.i = c__[i__10].i + 
			    t0.i;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    i__9 = i__ + c_dim1;
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t1.r - z__3.r, z__2.i = t1.i - z__3.i;
		    z__1.r = z__2.r * f1.r - z__2.i * f1.i, z__1.i = z__2.r * 
			    f1.i + z__2.i * f1.r;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    i__9 = i__ + (c_dim1 << 1);
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t1.r + z__3.r, z__2.i = t1.i + z__3.i;
		    z__1.r = z__2.r * f2.r - z__2.i * f2.i, z__1.i = z__2.r * 
			    f2.i + z__2.i * f2.r;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L180: */
		}
	    }
/* L190: */
	}
	muf += mfftpa_1.lx;
/* L200: */
    }
    i__2 = mfftpa_1.llim;
    i__1 = mfftpa_1.lstep;
    for (lam = 0; i__1 < 0 ? lam >= i__2 : lam <= i__2; lam += i__1) {
	i__4 = lam + mfftpa_1.ivlim;
	i__3 = mfftpa_1.ivs;
	for (iv = lam; i__3 < 0 ? iv >= i__4 : iv <= i__4; iv += i__3) {
	    i__8 = iv + mfftpa_1.ilim;
	    i__7 = mfftpa_1.ies;
	    for (i__ = iv; i__7 < 0 ? i__ >= i__8 : i__ <= i__8; i__ += i__7) 
		    {
		i__6 = i__ + c_dim1;
		i__5 = i__ + (c_dim1 << 1);
		z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + 
			c__[i__5].i;
		t0.r = z__1.r, t0.i = z__1.i;
		i__6 = i__ + c_dim1;
		i__5 = i__ + (c_dim1 << 1);
		z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - 
			c__[i__5].i;
		z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
			.86602540378443864;
		t2.r = z__1.r, t2.i = z__1.i;
		i__6 = i__;
		z__2.r = t0.r * .5, z__2.i = t0.i * .5;
		z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - z__2.i;
		t1.r = z__1.r, t1.i = z__1.i;
		i__6 = i__;
		i__5 = i__;
		z__1.r = c__[i__5].r + t0.r, z__1.i = c__[i__5].i + t0.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		i__6 = i__ + c_dim1;
		d__1 = -d_imag(&t2);
		d__2 = t2.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t1.r - z__2.r, z__1.i = t1.i - z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		i__6 = i__ + (c_dim1 << 1);
		d__1 = -d_imag(&t2);
		d__2 = t2.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t1.r + z__2.r, z__1.i = t1.i + z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L183: */
	    }
	}
/* L193: */
    }
} /* mfftb6_ */

/* Subroutine */ int mfftb7_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8, i__9, 
	    i__10;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3, z__4;

    /* Builtin functions */
    double d_imag();

    /* Local variables */
    integer lamf, i__;
    doublecomplex f1, f2, t0, t1, t2;
    integer iv, mu, lam;


/*   purpose: */
/*       elementary cooley-tukey radix 3 step applied to a vector-of */
/*       2-vectors-of-complex c[ims,nm [ivs,nv [ies,ne]]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftim, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

/* ..  lam>0 */
    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    lamf = mfftpa_1.mx;
    i__1 = mfftpa_1.llim;
    i__2 = mfftpa_1.lstep;
    for (lam = mfftpa_1.lstep; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam += 
	    i__2) {
	i__3 = lamf;
	f1.r = fac[i__3].r, f1.i = fac[i__3].i;
	i__3 = lamf << 1;
	f2.r = fac[i__3].r, f2.i = fac[i__3].i;
	i__3 = lam + mfftpa_1.mlim;
	i__4 = mfftpa_1.mstep;
	for (mu = lam; i__4 < 0 ? mu >= i__3 : mu <= i__3; mu += i__4) {
	    i__5 = mu + mfftpa_1.ivlim;
	    i__6 = mfftpa_1.ivs;
	    for (iv = mu; i__6 < 0 ? iv >= i__5 : iv <= i__5; iv += i__6) {
		i__7 = iv + mfftpa_1.ilim;
		i__8 = mfftpa_1.ies;
		for (i__ = iv; i__8 < 0 ? i__ >= i__7 : i__ <= i__7; i__ += 
			i__8) {
		    i__9 = i__ + c_dim1;
		    z__2.r = c__[i__9].r * f1.r - c__[i__9].i * f1.i, z__2.i =
			     c__[i__9].r * f1.i + c__[i__9].i * f1.r;
		    i__10 = i__ + (c_dim1 << 1);
		    z__3.r = c__[i__10].r * f2.r - c__[i__10].i * f2.i, 
			    z__3.i = c__[i__10].r * f2.i + c__[i__10].i * 
			    f2.r;
		    z__1.r = z__2.r + z__3.r, z__1.i = z__2.i + z__3.i;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__9 = i__ + c_dim1;
		    z__3.r = c__[i__9].r * f1.r - c__[i__9].i * f1.i, z__3.i =
			     c__[i__9].r * f1.i + c__[i__9].i * f1.r;
		    i__10 = i__ + (c_dim1 << 1);
		    z__4.r = c__[i__10].r * f2.r - c__[i__10].i * f2.i, 
			    z__4.i = c__[i__10].r * f2.i + c__[i__10].i * 
			    f2.r;
		    z__2.r = z__3.r - z__4.r, z__2.i = z__3.i - z__4.i;
		    z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
			    .86602540378443864;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__9 = i__;
		    z__2.r = t0.r * .5, z__2.i = t0.i * .5;
		    z__1.r = c__[i__9].r - z__2.r, z__1.i = c__[i__9].i - 
			    z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__9 = i__;
		    i__10 = i__;
		    z__1.r = c__[i__10].r + t0.r, z__1.i = c__[i__10].i + 
			    t0.i;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    i__9 = i__ + c_dim1;
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t1.r + z__2.r, z__1.i = t1.i + z__2.i;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    i__9 = i__ + (c_dim1 << 1);
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t1.r - z__2.r, z__1.i = t1.i - z__2.i;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L80: */
		}
	    }
/* L90: */
	}
	lamf += mfftpa_1.mx;
/* L100: */
    }
    i__2 = mfftpa_1.mlim;
    i__1 = mfftpa_1.mstep;
    for (mu = 0; i__1 < 0 ? mu >= i__2 : mu <= i__2; mu += i__1) {
	i__4 = mu + mfftpa_1.ivlim;
	i__3 = mfftpa_1.ivs;
	for (iv = mu; i__3 < 0 ? iv >= i__4 : iv <= i__4; iv += i__3) {
	    i__8 = iv + mfftpa_1.ilim;
	    i__7 = mfftpa_1.ies;
	    for (i__ = iv; i__7 < 0 ? i__ >= i__8 : i__ <= i__8; i__ += i__7) 
		    {
		i__6 = i__ + c_dim1;
		i__5 = i__ + (c_dim1 << 1);
		z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + 
			c__[i__5].i;
		t0.r = z__1.r, t0.i = z__1.i;
		i__6 = i__ + c_dim1;
		i__5 = i__ + (c_dim1 << 1);
		z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - 
			c__[i__5].i;
		z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
			.86602540378443864;
		t2.r = z__1.r, t2.i = z__1.i;
		i__6 = i__;
		z__2.r = t0.r * .5, z__2.i = t0.i * .5;
		z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - z__2.i;
		t1.r = z__1.r, t1.i = z__1.i;
		i__6 = i__;
		i__5 = i__;
		z__1.r = c__[i__5].r + t0.r, z__1.i = c__[i__5].i + t0.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		i__6 = i__ + c_dim1;
		d__1 = -d_imag(&t2);
		d__2 = t2.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t1.r + z__2.r, z__1.i = t1.i + z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		i__6 = i__ + (c_dim1 << 1);
		d__1 = -d_imag(&t2);
		d__2 = t2.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t1.r - z__2.r, z__1.i = t1.i - z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L82: */
	    }
	}
/* L92: */
    }
} /* mfftb7_ */

/* Subroutine */ int mfftb8_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3;

    /* Builtin functions */
    double d_imag();

    /* Local variables */
    integer imuf;
    doublecomplex t0, t1, t2;
    integer iv, lam, imu;


/*   purpose: */
/*       elementary gentleman-sande radix 3 step applied to a vector-of */
/*       2-vectors-of-complex c[ims,nm [ivs,nv [ies,ne]]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftdm, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    if (mfftpa_1.mx != 1) {
	i__1 = mfftpa_1.llim;
	i__2 = mfftpa_1.lstep;
	for (lam = 0; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam += i__2) {
	    i__3 = lam + mfftpa_1.ivlim;
	    i__4 = mfftpa_1.ivs;
	    for (iv = lam; i__4 < 0 ? iv >= i__3 : iv <= i__3; iv += i__4) {
		imuf = 0;
		i__5 = iv + mfftpa_1.ilim;
		for (imu = iv; imu <= i__5; ++imu) {
		    i__6 = imu + c_dim1;
		    i__7 = imu + (c_dim1 << 1);
		    z__1.r = c__[i__6].r + c__[i__7].r, z__1.i = c__[i__6].i 
			    + c__[i__7].i;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__6 = imu + c_dim1;
		    i__7 = imu + (c_dim1 << 1);
		    z__2.r = c__[i__6].r - c__[i__7].r, z__2.i = c__[i__6].i 
			    - c__[i__7].i;
		    z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
			    .86602540378443864;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = imu;
		    z__2.r = t0.r * .5, z__2.i = t0.i * .5;
		    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - 
			    z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = imu;
		    i__7 = imu;
		    z__1.r = c__[i__7].r + t0.r, z__1.i = c__[i__7].i + t0.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + c_dim1;
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t1.r - z__3.r, z__2.i = t1.i - z__3.i;
		    i__7 = imuf;
		    z__1.r = z__2.r * fac[i__7].r - z__2.i * fac[i__7].i, 
			    z__1.i = z__2.r * fac[i__7].i + z__2.i * fac[i__7]
			    .r;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + (c_dim1 << 1);
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t1.r + z__3.r, z__2.i = t1.i + z__3.i;
		    i__7 = imuf + mfftpa_1.nustep;
		    z__1.r = z__2.r * fac[i__7].r - z__2.i * fac[i__7].i, 
			    z__1.i = z__2.r * fac[i__7].i + z__2.i * fac[i__7]
			    .r;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    ++imuf;
/* L180: */
		}
/* L190: */
	    }
/* L200: */
	}
    } else {
	i__2 = mfftpa_1.llim;
	i__1 = mfftpa_1.lstep;
	for (lam = 0; i__1 < 0 ? lam >= i__2 : lam <= i__2; lam += i__1) {
	    i__4 = lam + mfftpa_1.ivlim;
	    i__3 = mfftpa_1.ivs;
	    for (iv = lam; i__3 < 0 ? iv >= i__4 : iv <= i__4; iv += i__3) {
		i__5 = iv + mfftpa_1.ilim;
		for (imu = iv; imu <= i__5; ++imu) {
		    i__6 = imu + c_dim1;
		    i__7 = imu + (c_dim1 << 1);
		    z__1.r = c__[i__6].r + c__[i__7].r, z__1.i = c__[i__6].i 
			    + c__[i__7].i;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__6 = imu + c_dim1;
		    i__7 = imu + (c_dim1 << 1);
		    z__2.r = c__[i__6].r - c__[i__7].r, z__2.i = c__[i__6].i 
			    - c__[i__7].i;
		    z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
			    .86602540378443864;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = imu;
		    z__2.r = t0.r * .5, z__2.i = t0.i * .5;
		    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - 
			    z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = imu;
		    i__7 = imu;
		    z__1.r = c__[i__7].r + t0.r, z__1.i = c__[i__7].i + t0.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + c_dim1;
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t1.r - z__2.r, z__1.i = t1.i - z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + (c_dim1 << 1);
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t1.r + z__2.r, z__1.i = t1.i + z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L380: */
		}
/* L390: */
	    }
/* L400: */
	}
    }
} /* mfftb8_ */

/* Subroutine */ int mfftb9_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8, i__9;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3, z__4;

    /* Builtin functions */
    double d_imag();

    /* Local variables */
    integer ilam, ilamf;
    doublecomplex t0, t1, t2;
    integer iv, mu;


/*   purpose: */
/*       elementary cooley-tukey radix 3 step applied to a vector-of */
/*       2-vectors-of-complex c[ims,nm [ivs,nv [ies,ne]]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftim, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    if (mfftpa_1.lx != 1) {
	i__1 = mfftpa_1.mlim;
	i__2 = mfftpa_1.mstep;
	for (mu = 0; i__2 < 0 ? mu >= i__1 : mu <= i__1; mu += i__2) {
	    i__3 = mu + mfftpa_1.ivlim;
	    i__4 = mfftpa_1.ivs;
	    for (iv = mu; i__4 < 0 ? iv >= i__3 : iv <= i__3; iv += i__4) {
		ilamf = 0;
		i__5 = iv + mfftpa_1.ilim;
		for (ilam = iv; ilam <= i__5; ++ilam) {
		    i__6 = ilam + c_dim1;
		    i__7 = ilamf;
		    z__2.r = c__[i__6].r * fac[i__7].r - c__[i__6].i * fac[
			    i__7].i, z__2.i = c__[i__6].r * fac[i__7].i + c__[
			    i__6].i * fac[i__7].r;
		    i__8 = ilam + (c_dim1 << 1);
		    i__9 = ilamf + mfftpa_1.nustep;
		    z__3.r = c__[i__8].r * fac[i__9].r - c__[i__8].i * fac[
			    i__9].i, z__3.i = c__[i__8].r * fac[i__9].i + c__[
			    i__8].i * fac[i__9].r;
		    z__1.r = z__2.r + z__3.r, z__1.i = z__2.i + z__3.i;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__6 = ilam + c_dim1;
		    i__7 = ilamf;
		    z__3.r = c__[i__6].r * fac[i__7].r - c__[i__6].i * fac[
			    i__7].i, z__3.i = c__[i__6].r * fac[i__7].i + c__[
			    i__6].i * fac[i__7].r;
		    i__8 = ilam + (c_dim1 << 1);
		    i__9 = ilamf + mfftpa_1.nustep;
		    z__4.r = c__[i__8].r * fac[i__9].r - c__[i__8].i * fac[
			    i__9].i, z__4.i = c__[i__8].r * fac[i__9].i + c__[
			    i__8].i * fac[i__9].r;
		    z__2.r = z__3.r - z__4.r, z__2.i = z__3.i - z__4.i;
		    z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
			    .86602540378443864;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = ilam;
		    z__2.r = t0.r * .5, z__2.i = t0.i * .5;
		    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - 
			    z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = ilam;
		    i__7 = ilam;
		    z__1.r = c__[i__7].r + t0.r, z__1.i = c__[i__7].i + t0.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam + c_dim1;
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t1.r + z__2.r, z__1.i = t1.i + z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam + (c_dim1 << 1);
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t1.r - z__2.r, z__1.i = t1.i - z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    ++ilamf;
/* L100: */
		}
/* L150: */
	    }
/* L200: */
	}
    } else {
	i__2 = mfftpa_1.mlim;
	i__1 = mfftpa_1.mstep;
	for (mu = 0; i__1 < 0 ? mu >= i__2 : mu <= i__2; mu += i__1) {
	    i__4 = mu + mfftpa_1.ivlim;
	    i__3 = mfftpa_1.ivs;
	    for (iv = mu; i__3 < 0 ? iv >= i__4 : iv <= i__4; iv += i__3) {
		i__5 = iv + mfftpa_1.ilim;
		for (ilam = iv; ilam <= i__5; ++ilam) {
		    i__6 = ilam + c_dim1;
		    i__7 = ilam + (c_dim1 << 1);
		    z__1.r = c__[i__6].r + c__[i__7].r, z__1.i = c__[i__6].i 
			    + c__[i__7].i;
		    t0.r = z__1.r, t0.i = z__1.i;
		    i__6 = ilam + c_dim1;
		    i__7 = ilam + (c_dim1 << 1);
		    z__2.r = c__[i__6].r - c__[i__7].r, z__2.i = c__[i__6].i 
			    - c__[i__7].i;
		    z__1.r = z__2.r * .86602540378443864, z__1.i = z__2.i * 
			    .86602540378443864;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = ilam;
		    z__2.r = t0.r * .5, z__2.i = t0.i * .5;
		    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - 
			    z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = ilam;
		    i__7 = ilam;
		    z__1.r = c__[i__7].r + t0.r, z__1.i = c__[i__7].i + t0.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam + c_dim1;
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t1.r + z__2.r, z__1.i = t1.i + z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam + (c_dim1 << 1);
		    d__1 = -d_imag(&t2);
		    d__2 = t2.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t1.r - z__2.r, z__1.i = t1.i - z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L300: */
		}
/* L350: */
	    }
/* L400: */
	}
    }
} /* mfftb9_ */

/* Subroutine */ int mfftc4_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3;

    /* Builtin functions */
    void d_cnjg();
    double d_imag();

    /* Local variables */
    integer i__;
    doublecomplex f1, f2, f3, f4, t1, t2, t3, t4, t5;
    integer mu, lam, muf;


/*   purpose: */
/*       elementary gentleman-sande radix 5 step applied to a vector-of */
/*       vectors-of-complex c[ivs,nve[ies,ne]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftdv, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

/* ..  mu > 1 */
    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    muf = mfftpa_1.lx;
    i__1 = mfftpa_1.mlim;
    i__2 = mfftpa_1.mstep;
    for (mu = mfftpa_1.mstep; i__2 < 0 ? mu >= i__1 : mu <= i__1; mu += i__2) 
	    {
	d_cnjg(&z__1, &fac[muf]);
	f1.r = z__1.r, f1.i = z__1.i;
	d_cnjg(&z__1, &fac[muf * 2]);
	f2.r = z__1.r, f2.i = z__1.i;
	d_cnjg(&z__1, &fac[muf * 3]);
	f3.r = z__1.r, f3.i = z__1.i;
	d_cnjg(&z__1, &fac[muf * 4]);
	f4.r = z__1.r, f4.i = z__1.i;
	i__3 = mu + mfftpa_1.llim;
	i__4 = mfftpa_1.lstep;
	for (lam = mu; i__4 < 0 ? lam >= i__3 : lam <= i__3; lam += i__4) {
	    i__5 = lam + mfftpa_1.ilim;
	    i__6 = mfftpa_1.ies;
	    for (i__ = lam; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += i__6)
		     {
		i__7 = i__ + c_dim1;
		i__8 = i__ + (c_dim1 << 2);
		z__1.r = c__[i__7].r + c__[i__8].r, z__1.i = c__[i__7].i + 
			c__[i__8].i;
		t1.r = z__1.r, t1.i = z__1.i;
		i__7 = i__ + (c_dim1 << 1);
		i__8 = i__ + c_dim1 * 3;
		z__1.r = c__[i__7].r + c__[i__8].r, z__1.i = c__[i__7].i + 
			c__[i__8].i;
		t2.r = z__1.r, t2.i = z__1.i;
		i__7 = i__ + c_dim1;
		i__8 = i__ + (c_dim1 << 2);
		z__2.r = c__[i__7].r - c__[i__8].r, z__2.i = c__[i__7].i - 
			c__[i__8].i;
		z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			z__2.i * .951056516295153572116439333;
		t3.r = z__1.r, t3.i = z__1.i;
		i__7 = i__ + (c_dim1 << 1);
		i__8 = i__ + c_dim1 * 3;
		z__2.r = c__[i__7].r - c__[i__8].r, z__2.i = c__[i__7].i - 
			c__[i__8].i;
		z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			z__2.i * .951056516295153572116439333;
		t4.r = z__1.r, t4.i = z__1.i;
		z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
		t5.r = z__1.r, t5.i = z__1.i;
		z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
		z__1.r = z__2.r * .559016994374947424102293417, z__1.i = 
			z__2.i * .559016994374947424102293417;
		t1.r = z__1.r, t1.i = z__1.i;
		i__7 = i__;
		z__2.r = t5.r * .25, z__2.i = t5.i * .25;
		z__1.r = c__[i__7].r - z__2.r, z__1.i = c__[i__7].i - z__2.i;
		t2.r = z__1.r, t2.i = z__1.i;
		i__7 = i__;
		i__8 = i__;
		z__1.r = c__[i__8].r + t5.r, z__1.i = c__[i__8].i + t5.i;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
		t5.r = z__1.r, t5.i = z__1.i;
		z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
		t2.r = z__1.r, t2.i = z__1.i;
		z__2.r = t4.r * .618033988749894848204586834, z__2.i = t4.i * 
			.618033988749894848204586834;
		z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
		t1.r = z__1.r, t1.i = z__1.i;
		z__2.r = t3.r * .618033988749894848204586834, z__2.i = t3.i * 
			.618033988749894848204586834;
		z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
		t3.r = z__1.r, t3.i = z__1.i;
		i__7 = i__ + c_dim1;
		d__1 = -d_imag(&t1);
		d__2 = t1.r;
		z__3.r = d__1, z__3.i = d__2;
		z__2.r = t5.r - z__3.r, z__2.i = t5.i - z__3.i;
		z__1.r = z__2.r * f1.r - z__2.i * f1.i, z__1.i = z__2.r * 
			f1.i + z__2.i * f1.r;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		i__7 = i__ + (c_dim1 << 2);
		d__1 = -d_imag(&t1);
		d__2 = t1.r;
		z__3.r = d__1, z__3.i = d__2;
		z__2.r = t5.r + z__3.r, z__2.i = t5.i + z__3.i;
		z__1.r = z__2.r * f4.r - z__2.i * f4.i, z__1.i = z__2.r * 
			f4.i + z__2.i * f4.r;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		i__7 = i__ + (c_dim1 << 1);
		d__1 = -d_imag(&t3);
		d__2 = t3.r;
		z__3.r = d__1, z__3.i = d__2;
		z__2.r = t2.r - z__3.r, z__2.i = t2.i - z__3.i;
		z__1.r = z__2.r * f2.r - z__2.i * f2.i, z__1.i = z__2.r * 
			f2.i + z__2.i * f2.r;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		i__7 = i__ + c_dim1 * 3;
		d__1 = -d_imag(&t3);
		d__2 = t3.r;
		z__3.r = d__1, z__3.i = d__2;
		z__2.r = t2.r + z__3.r, z__2.i = t2.i + z__3.i;
		z__1.r = z__2.r * f3.r - z__2.i * f3.i, z__1.i = z__2.r * 
			f3.i + z__2.i * f3.r;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L180: */
	    }
/* L190: */
	}
	muf += mfftpa_1.lx;
/* L200: */
    }
/* ..  mu=0 */
/* L1000: */
    i__2 = mfftpa_1.llim;
    i__1 = mfftpa_1.lstep;
    for (lam = 0; i__1 < 0 ? lam >= i__2 : lam <= i__2; lam += i__1) {
	i__4 = lam + mfftpa_1.ilim;
	i__3 = mfftpa_1.ies;
	for (i__ = lam; i__3 < 0 ? i__ >= i__4 : i__ <= i__4; i__ += i__3) {
	    i__6 = i__ + c_dim1;
	    i__5 = i__ + (c_dim1 << 2);
	    z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + c__[
		    i__5].i;
	    t1.r = z__1.r, t1.i = z__1.i;
	    i__6 = i__ + (c_dim1 << 1);
	    i__5 = i__ + c_dim1 * 3;
	    z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + c__[
		    i__5].i;
	    t2.r = z__1.r, t2.i = z__1.i;
	    i__6 = i__ + c_dim1;
	    i__5 = i__ + (c_dim1 << 2);
	    z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - c__[
		    i__5].i;
	    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = z__2.i * 
		    .951056516295153572116439333;
	    t3.r = z__1.r, t3.i = z__1.i;
	    i__6 = i__ + (c_dim1 << 1);
	    i__5 = i__ + c_dim1 * 3;
	    z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - c__[
		    i__5].i;
	    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = z__2.i * 
		    .951056516295153572116439333;
	    t4.r = z__1.r, t4.i = z__1.i;
	    z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
	    t5.r = z__1.r, t5.i = z__1.i;
	    z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
	    z__1.r = z__2.r * .559016994374947424102293417, z__1.i = z__2.i * 
		    .559016994374947424102293417;
	    t1.r = z__1.r, t1.i = z__1.i;
	    i__6 = i__;
	    z__2.r = t5.r * .25, z__2.i = t5.i * .25;
	    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - z__2.i;
	    t2.r = z__1.r, t2.i = z__1.i;
	    i__6 = i__;
	    i__5 = i__;
	    z__1.r = c__[i__5].r + t5.r, z__1.i = c__[i__5].i + t5.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
	    t5.r = z__1.r, t5.i = z__1.i;
	    z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
	    t2.r = z__1.r, t2.i = z__1.i;
	    z__2.r = t4.r * .618033988749894848204586834, z__2.i = t4.i * 
		    .618033988749894848204586834;
	    z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
	    t1.r = z__1.r, t1.i = z__1.i;
	    z__2.r = t3.r * .618033988749894848204586834, z__2.i = t3.i * 
		    .618033988749894848204586834;
	    z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
	    t3.r = z__1.r, t3.i = z__1.i;
	    i__6 = i__ + c_dim1;
	    d__1 = -d_imag(&t1);
	    d__2 = t1.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t5.r - z__2.r, z__1.i = t5.i - z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    i__6 = i__ + (c_dim1 << 2);
	    d__1 = -d_imag(&t1);
	    d__2 = t1.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t5.r + z__2.r, z__1.i = t5.i + z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    i__6 = i__ + (c_dim1 << 1);
	    d__1 = -d_imag(&t3);
	    d__2 = t3.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t2.r - z__2.r, z__1.i = t2.i - z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    i__6 = i__ + c_dim1 * 3;
	    d__1 = -d_imag(&t3);
	    d__2 = t3.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t2.r + z__2.r, z__1.i = t2.i + z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L183: */
	}
/* L193: */
    }
} /* mfftc4_ */

/* Subroutine */ int mfftc5_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3, z__4;

    /* Builtin functions */
    double d_imag();

    /* Local variables */
    integer lamf, i__;
    doublecomplex f1, f2, f3, f4, t1, t2, t3, t4, t5;
    integer mu, lam;


/*   purpose: */
/*       elementary cooley-tukey radix 5 step applied to a vector-of */
/*       vectors-of-complex c[ivs,nv [ies,ne]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftiv, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

/* ..  lam > 0 */
    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    lamf = mfftpa_1.mx;
    i__1 = mfftpa_1.llim;
    i__2 = mfftpa_1.lstep;
    for (lam = mfftpa_1.lstep; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam += 
	    i__2) {
	i__3 = lamf;
	f1.r = fac[i__3].r, f1.i = fac[i__3].i;
	i__3 = lamf << 1;
	f2.r = fac[i__3].r, f2.i = fac[i__3].i;
	i__3 = lamf * 3;
	f3.r = fac[i__3].r, f3.i = fac[i__3].i;
	i__3 = lamf << 2;
	f4.r = fac[i__3].r, f4.i = fac[i__3].i;
	i__3 = lam + mfftpa_1.mlim;
	i__4 = mfftpa_1.mstep;
	for (mu = lam; i__4 < 0 ? mu >= i__3 : mu <= i__3; mu += i__4) {
	    i__5 = mu + mfftpa_1.ilim;
	    i__6 = mfftpa_1.ies;
	    for (i__ = mu; i__6 < 0 ? i__ >= i__5 : i__ <= i__5; i__ += i__6) 
		    {
		i__7 = i__ + c_dim1;
		z__2.r = c__[i__7].r * f1.r - c__[i__7].i * f1.i, z__2.i = 
			c__[i__7].r * f1.i + c__[i__7].i * f1.r;
		i__8 = i__ + (c_dim1 << 2);
		z__3.r = c__[i__8].r * f4.r - c__[i__8].i * f4.i, z__3.i = 
			c__[i__8].r * f4.i + c__[i__8].i * f4.r;
		z__1.r = z__2.r + z__3.r, z__1.i = z__2.i + z__3.i;
		t1.r = z__1.r, t1.i = z__1.i;
		i__7 = i__ + (c_dim1 << 1);
		z__2.r = c__[i__7].r * f2.r - c__[i__7].i * f2.i, z__2.i = 
			c__[i__7].r * f2.i + c__[i__7].i * f2.r;
		i__8 = i__ + c_dim1 * 3;
		z__3.r = c__[i__8].r * f3.r - c__[i__8].i * f3.i, z__3.i = 
			c__[i__8].r * f3.i + c__[i__8].i * f3.r;
		z__1.r = z__2.r + z__3.r, z__1.i = z__2.i + z__3.i;
		t2.r = z__1.r, t2.i = z__1.i;
		i__7 = i__ + c_dim1;
		z__3.r = c__[i__7].r * f1.r - c__[i__7].i * f1.i, z__3.i = 
			c__[i__7].r * f1.i + c__[i__7].i * f1.r;
		i__8 = i__ + (c_dim1 << 2);
		z__4.r = c__[i__8].r * f4.r - c__[i__8].i * f4.i, z__4.i = 
			c__[i__8].r * f4.i + c__[i__8].i * f4.r;
		z__2.r = z__3.r - z__4.r, z__2.i = z__3.i - z__4.i;
		z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			z__2.i * .951056516295153572116439333;
		t3.r = z__1.r, t3.i = z__1.i;
		i__7 = i__ + (c_dim1 << 1);
		z__3.r = c__[i__7].r * f2.r - c__[i__7].i * f2.i, z__3.i = 
			c__[i__7].r * f2.i + c__[i__7].i * f2.r;
		i__8 = i__ + c_dim1 * 3;
		z__4.r = c__[i__8].r * f3.r - c__[i__8].i * f3.i, z__4.i = 
			c__[i__8].r * f3.i + c__[i__8].i * f3.r;
		z__2.r = z__3.r - z__4.r, z__2.i = z__3.i - z__4.i;
		z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			z__2.i * .951056516295153572116439333;
		t4.r = z__1.r, t4.i = z__1.i;
		z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
		t5.r = z__1.r, t5.i = z__1.i;
		z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
		z__1.r = z__2.r * .559016994374947424102293417, z__1.i = 
			z__2.i * .559016994374947424102293417;
		t1.r = z__1.r, t1.i = z__1.i;
		i__7 = i__;
		z__2.r = t5.r * .25, z__2.i = t5.i * .25;
		z__1.r = c__[i__7].r - z__2.r, z__1.i = c__[i__7].i - z__2.i;
		t2.r = z__1.r, t2.i = z__1.i;
		i__7 = i__;
		i__8 = i__;
		z__1.r = c__[i__8].r + t5.r, z__1.i = c__[i__8].i + t5.i;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
		t5.r = z__1.r, t5.i = z__1.i;
		z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
		t2.r = z__1.r, t2.i = z__1.i;
		z__2.r = t4.r * .618033988749894848204586834, z__2.i = t4.i * 
			.618033988749894848204586834;
		z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
		t1.r = z__1.r, t1.i = z__1.i;
		z__2.r = t3.r * .618033988749894848204586834, z__2.i = t3.i * 
			.618033988749894848204586834;
		z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
		t3.r = z__1.r, t3.i = z__1.i;
		i__7 = i__ + c_dim1;
		d__1 = -d_imag(&t1);
		d__2 = t1.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t5.r + z__2.r, z__1.i = t5.i + z__2.i;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		i__7 = i__ + (c_dim1 << 2);
		d__1 = -d_imag(&t1);
		d__2 = t1.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t5.r - z__2.r, z__1.i = t5.i - z__2.i;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		i__7 = i__ + (c_dim1 << 1);
		d__1 = -d_imag(&t3);
		d__2 = t3.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t2.r + z__2.r, z__1.i = t2.i + z__2.i;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
		i__7 = i__ + c_dim1 * 3;
		d__1 = -d_imag(&t3);
		d__2 = t3.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t2.r - z__2.r, z__1.i = t2.i - z__2.i;
		c__[i__7].r = z__1.r, c__[i__7].i = z__1.i;
/* L80: */
	    }
/* L90: */
	}
	lamf += mfftpa_1.mx;
/* L100: */
    }
/* .. lam=0 */
    i__2 = mfftpa_1.mlim;
    i__1 = mfftpa_1.mstep;
    for (mu = 0; i__1 < 0 ? mu >= i__2 : mu <= i__2; mu += i__1) {
	i__4 = mu + mfftpa_1.ilim;
	i__3 = mfftpa_1.ies;
	for (i__ = mu; i__3 < 0 ? i__ >= i__4 : i__ <= i__4; i__ += i__3) {
	    i__6 = i__ + c_dim1;
	    i__5 = i__ + (c_dim1 << 2);
	    z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + c__[
		    i__5].i;
	    t1.r = z__1.r, t1.i = z__1.i;
	    i__6 = i__ + (c_dim1 << 1);
	    i__5 = i__ + c_dim1 * 3;
	    z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + c__[
		    i__5].i;
	    t2.r = z__1.r, t2.i = z__1.i;
	    i__6 = i__ + c_dim1;
	    i__5 = i__ + (c_dim1 << 2);
	    z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - c__[
		    i__5].i;
	    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = z__2.i * 
		    .951056516295153572116439333;
	    t3.r = z__1.r, t3.i = z__1.i;
	    i__6 = i__ + (c_dim1 << 1);
	    i__5 = i__ + c_dim1 * 3;
	    z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - c__[
		    i__5].i;
	    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = z__2.i * 
		    .951056516295153572116439333;
	    t4.r = z__1.r, t4.i = z__1.i;
	    z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
	    t5.r = z__1.r, t5.i = z__1.i;
	    z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
	    z__1.r = z__2.r * .559016994374947424102293417, z__1.i = z__2.i * 
		    .559016994374947424102293417;
	    t1.r = z__1.r, t1.i = z__1.i;
	    i__6 = i__;
	    z__2.r = t5.r * .25, z__2.i = t5.i * .25;
	    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - z__2.i;
	    t2.r = z__1.r, t2.i = z__1.i;
	    i__6 = i__;
	    i__5 = i__;
	    z__1.r = c__[i__5].r + t5.r, z__1.i = c__[i__5].i + t5.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
	    t5.r = z__1.r, t5.i = z__1.i;
	    z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
	    t2.r = z__1.r, t2.i = z__1.i;
	    z__2.r = t4.r * .618033988749894848204586834, z__2.i = t4.i * 
		    .618033988749894848204586834;
	    z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
	    t1.r = z__1.r, t1.i = z__1.i;
	    z__2.r = t3.r * .618033988749894848204586834, z__2.i = t3.i * 
		    .618033988749894848204586834;
	    z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
	    t3.r = z__1.r, t3.i = z__1.i;
	    i__6 = i__ + c_dim1;
	    d__1 = -d_imag(&t1);
	    d__2 = t1.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t5.r + z__2.r, z__1.i = t5.i + z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    i__6 = i__ + (c_dim1 << 2);
	    d__1 = -d_imag(&t1);
	    d__2 = t1.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t5.r - z__2.r, z__1.i = t5.i - z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    i__6 = i__ + (c_dim1 << 1);
	    d__1 = -d_imag(&t3);
	    d__2 = t3.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t2.r + z__2.r, z__1.i = t2.i + z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
	    i__6 = i__ + c_dim1 * 3;
	    d__1 = -d_imag(&t3);
	    d__2 = t3.r;
	    z__2.r = d__1, z__2.i = d__2;
	    z__1.r = t2.r - z__2.r, z__1.i = t2.i - z__2.i;
	    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L82: */
	}
/* L92: */
    }
} /* mfftc5_ */

/*     ###################    fft5 ends here    ################## */
/* Subroutine */ int mfftc6_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8, i__9, 
	    i__10;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3;

    /* Builtin functions */
    void d_cnjg();
    double d_imag();

    /* Local variables */
    integer i__;
    doublecomplex f1, f2, f3, f4, t1, t2, t3, t4, t5;
    integer iv, mu, lam, muf;


/*   purpose: */
/*       elementary gentleman-sande radix 5 step applied to a vector-of */
/*       2-vectors-of-complex c[ims,nm [ivs,nv [ies,ne]]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftdm, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

/* ..  mu > 0 */
    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    muf = mfftpa_1.lx;
    i__1 = mfftpa_1.mlim;
    i__2 = mfftpa_1.mstep;
    for (mu = mfftpa_1.mstep; i__2 < 0 ? mu >= i__1 : mu <= i__1; mu += i__2) 
	    {
	d_cnjg(&z__1, &fac[muf]);
	f1.r = z__1.r, f1.i = z__1.i;
	d_cnjg(&z__1, &fac[muf * 2]);
	f2.r = z__1.r, f2.i = z__1.i;
	d_cnjg(&z__1, &fac[muf * 3]);
	f3.r = z__1.r, f3.i = z__1.i;
	d_cnjg(&z__1, &fac[muf * 4]);
	f4.r = z__1.r, f4.i = z__1.i;
	i__3 = mu + mfftpa_1.llim;
	i__4 = mfftpa_1.lstep;
	for (lam = mu; i__4 < 0 ? lam >= i__3 : lam <= i__3; lam += i__4) {
	    i__5 = lam + mfftpa_1.ivlim;
	    i__6 = mfftpa_1.ivs;
	    for (iv = lam; i__6 < 0 ? iv >= i__5 : iv <= i__5; iv += i__6) {
		i__7 = iv + mfftpa_1.ilim;
		i__8 = mfftpa_1.ies;
		for (i__ = iv; i__8 < 0 ? i__ >= i__7 : i__ <= i__7; i__ += 
			i__8) {
		    i__9 = i__ + c_dim1;
		    i__10 = i__ + (c_dim1 << 2);
		    z__1.r = c__[i__9].r + c__[i__10].r, z__1.i = c__[i__9].i 
			    + c__[i__10].i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__9 = i__ + (c_dim1 << 1);
		    i__10 = i__ + c_dim1 * 3;
		    z__1.r = c__[i__9].r + c__[i__10].r, z__1.i = c__[i__9].i 
			    + c__[i__10].i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__9 = i__ + c_dim1;
		    i__10 = i__ + (c_dim1 << 2);
		    z__2.r = c__[i__9].r - c__[i__10].r, z__2.i = c__[i__9].i 
			    - c__[i__10].i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__9 = i__ + (c_dim1 << 1);
		    i__10 = i__ + c_dim1 * 3;
		    z__2.r = c__[i__9].r - c__[i__10].r, z__2.i = c__[i__9].i 
			    - c__[i__10].i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t4.r = z__1.r, t4.i = z__1.i;
		    z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
		    z__1.r = z__2.r * .559016994374947424102293417, z__1.i = 
			    z__2.i * .559016994374947424102293417;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__9 = i__;
		    z__2.r = t5.r * .25, z__2.i = t5.i * .25;
		    z__1.r = c__[i__9].r - z__2.r, z__1.i = c__[i__9].i - 
			    z__2.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__9 = i__;
		    i__10 = i__;
		    z__1.r = c__[i__10].r + t5.r, z__1.i = c__[i__10].i + 
			    t5.i;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    z__2.r = t4.r * .618033988749894848204586834, z__2.i = 
			    t4.i * .618033988749894848204586834;
		    z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    z__2.r = t3.r * .618033988749894848204586834, z__2.i = 
			    t3.i * .618033988749894848204586834;
		    z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__9 = i__ + c_dim1;
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t5.r - z__3.r, z__2.i = t5.i - z__3.i;
		    z__1.r = z__2.r * f1.r - z__2.i * f1.i, z__1.i = z__2.r * 
			    f1.i + z__2.i * f1.r;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    i__9 = i__ + (c_dim1 << 2);
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t5.r + z__3.r, z__2.i = t5.i + z__3.i;
		    z__1.r = z__2.r * f4.r - z__2.i * f4.i, z__1.i = z__2.r * 
			    f4.i + z__2.i * f4.r;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    i__9 = i__ + (c_dim1 << 1);
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t2.r - z__3.r, z__2.i = t2.i - z__3.i;
		    z__1.r = z__2.r * f2.r - z__2.i * f2.i, z__1.i = z__2.r * 
			    f2.i + z__2.i * f2.r;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    i__9 = i__ + c_dim1 * 3;
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t2.r + z__3.r, z__2.i = t2.i + z__3.i;
		    z__1.r = z__2.r * f3.r - z__2.i * f3.i, z__1.i = z__2.r * 
			    f3.i + z__2.i * f3.r;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L180: */
		}
	    }
/* L190: */
	}
	muf += mfftpa_1.lx;
/* L200: */
    }
    i__2 = mfftpa_1.llim;
    i__1 = mfftpa_1.lstep;
    for (lam = 0; i__1 < 0 ? lam >= i__2 : lam <= i__2; lam += i__1) {
	i__4 = lam + mfftpa_1.ivlim;
	i__3 = mfftpa_1.ivs;
	for (iv = lam; i__3 < 0 ? iv >= i__4 : iv <= i__4; iv += i__3) {
	    i__8 = iv + mfftpa_1.ilim;
	    i__7 = mfftpa_1.ies;
	    for (i__ = iv; i__7 < 0 ? i__ >= i__8 : i__ <= i__8; i__ += i__7) 
		    {
		i__6 = i__ + c_dim1;
		i__5 = i__ + (c_dim1 << 2);
		z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + 
			c__[i__5].i;
		t1.r = z__1.r, t1.i = z__1.i;
		i__6 = i__ + (c_dim1 << 1);
		i__5 = i__ + c_dim1 * 3;
		z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + 
			c__[i__5].i;
		t2.r = z__1.r, t2.i = z__1.i;
		i__6 = i__ + c_dim1;
		i__5 = i__ + (c_dim1 << 2);
		z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - 
			c__[i__5].i;
		z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			z__2.i * .951056516295153572116439333;
		t3.r = z__1.r, t3.i = z__1.i;
		i__6 = i__ + (c_dim1 << 1);
		i__5 = i__ + c_dim1 * 3;
		z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - 
			c__[i__5].i;
		z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			z__2.i * .951056516295153572116439333;
		t4.r = z__1.r, t4.i = z__1.i;
		z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
		t5.r = z__1.r, t5.i = z__1.i;
		z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
		z__1.r = z__2.r * .559016994374947424102293417, z__1.i = 
			z__2.i * .559016994374947424102293417;
		t1.r = z__1.r, t1.i = z__1.i;
		i__6 = i__;
		z__2.r = t5.r * .25, z__2.i = t5.i * .25;
		z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - z__2.i;
		t2.r = z__1.r, t2.i = z__1.i;
		i__6 = i__;
		i__5 = i__;
		z__1.r = c__[i__5].r + t5.r, z__1.i = c__[i__5].i + t5.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
		t5.r = z__1.r, t5.i = z__1.i;
		z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
		t2.r = z__1.r, t2.i = z__1.i;
		z__2.r = t4.r * .618033988749894848204586834, z__2.i = t4.i * 
			.618033988749894848204586834;
		z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
		t1.r = z__1.r, t1.i = z__1.i;
		z__2.r = t3.r * .618033988749894848204586834, z__2.i = t3.i * 
			.618033988749894848204586834;
		z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
		t3.r = z__1.r, t3.i = z__1.i;
		i__6 = i__ + c_dim1;
		d__1 = -d_imag(&t1);
		d__2 = t1.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t5.r - z__2.r, z__1.i = t5.i - z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		i__6 = i__ + (c_dim1 << 2);
		d__1 = -d_imag(&t1);
		d__2 = t1.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t5.r + z__2.r, z__1.i = t5.i + z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		i__6 = i__ + (c_dim1 << 1);
		d__1 = -d_imag(&t3);
		d__2 = t3.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t2.r - z__2.r, z__1.i = t2.i - z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		i__6 = i__ + c_dim1 * 3;
		d__1 = -d_imag(&t3);
		d__2 = t3.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t2.r + z__2.r, z__1.i = t2.i + z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L183: */
	    }
	}
/* L193: */
    }
} /* mfftc6_ */

/* Subroutine */ int mfftc7_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8, i__9, 
	    i__10;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3, z__4;

    /* Builtin functions */
    double d_imag();

    /* Local variables */
    integer lamf, i__;
    doublecomplex f1, f2, f3, f4, t1, t2, t3, t4, t5;
    integer iv, mu, lam;


/*   purpose: */
/*       elementary cooley-tukey radix 5 step applied to a vector-of */
/*       2-vectors-of-complex c[ims,nm [ivs,nv [ies,ne]]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftim, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

/* ..  lam>0 */
    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    lamf = mfftpa_1.mx;
    i__1 = mfftpa_1.llim;
    i__2 = mfftpa_1.lstep;
    for (lam = mfftpa_1.lstep; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam += 
	    i__2) {
	i__3 = lamf;
	f1.r = fac[i__3].r, f1.i = fac[i__3].i;
	i__3 = lamf << 1;
	f2.r = fac[i__3].r, f2.i = fac[i__3].i;
	i__3 = lamf * 3;
	f3.r = fac[i__3].r, f3.i = fac[i__3].i;
	i__3 = lamf << 2;
	f4.r = fac[i__3].r, f4.i = fac[i__3].i;
	i__3 = lam + mfftpa_1.mlim;
	i__4 = mfftpa_1.mstep;
	for (mu = lam; i__4 < 0 ? mu >= i__3 : mu <= i__3; mu += i__4) {
	    i__5 = mu + mfftpa_1.ivlim;
	    i__6 = mfftpa_1.ivs;
	    for (iv = mu; i__6 < 0 ? iv >= i__5 : iv <= i__5; iv += i__6) {
		i__7 = iv + mfftpa_1.ilim;
		i__8 = mfftpa_1.ies;
		for (i__ = iv; i__8 < 0 ? i__ >= i__7 : i__ <= i__7; i__ += 
			i__8) {
		    i__9 = i__ + c_dim1;
		    z__2.r = c__[i__9].r * f1.r - c__[i__9].i * f1.i, z__2.i =
			     c__[i__9].r * f1.i + c__[i__9].i * f1.r;
		    i__10 = i__ + (c_dim1 << 2);
		    z__3.r = c__[i__10].r * f4.r - c__[i__10].i * f4.i, 
			    z__3.i = c__[i__10].r * f4.i + c__[i__10].i * 
			    f4.r;
		    z__1.r = z__2.r + z__3.r, z__1.i = z__2.i + z__3.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__9 = i__ + (c_dim1 << 1);
		    z__2.r = c__[i__9].r * f2.r - c__[i__9].i * f2.i, z__2.i =
			     c__[i__9].r * f2.i + c__[i__9].i * f2.r;
		    i__10 = i__ + c_dim1 * 3;
		    z__3.r = c__[i__10].r * f3.r - c__[i__10].i * f3.i, 
			    z__3.i = c__[i__10].r * f3.i + c__[i__10].i * 
			    f3.r;
		    z__1.r = z__2.r + z__3.r, z__1.i = z__2.i + z__3.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__9 = i__ + c_dim1;
		    z__3.r = c__[i__9].r * f1.r - c__[i__9].i * f1.i, z__3.i =
			     c__[i__9].r * f1.i + c__[i__9].i * f1.r;
		    i__10 = i__ + (c_dim1 << 2);
		    z__4.r = c__[i__10].r * f4.r - c__[i__10].i * f4.i, 
			    z__4.i = c__[i__10].r * f4.i + c__[i__10].i * 
			    f4.r;
		    z__2.r = z__3.r - z__4.r, z__2.i = z__3.i - z__4.i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__9 = i__ + (c_dim1 << 1);
		    z__3.r = c__[i__9].r * f2.r - c__[i__9].i * f2.i, z__3.i =
			     c__[i__9].r * f2.i + c__[i__9].i * f2.r;
		    i__10 = i__ + c_dim1 * 3;
		    z__4.r = c__[i__10].r * f3.r - c__[i__10].i * f3.i, 
			    z__4.i = c__[i__10].r * f3.i + c__[i__10].i * 
			    f3.r;
		    z__2.r = z__3.r - z__4.r, z__2.i = z__3.i - z__4.i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t4.r = z__1.r, t4.i = z__1.i;
		    z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
		    z__1.r = z__2.r * .559016994374947424102293417, z__1.i = 
			    z__2.i * .559016994374947424102293417;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__9 = i__;
		    z__2.r = t5.r * .25, z__2.i = t5.i * .25;
		    z__1.r = c__[i__9].r - z__2.r, z__1.i = c__[i__9].i - 
			    z__2.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__9 = i__;
		    i__10 = i__;
		    z__1.r = c__[i__10].r + t5.r, z__1.i = c__[i__10].i + 
			    t5.i;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    z__2.r = t4.r * .618033988749894848204586834, z__2.i = 
			    t4.i * .618033988749894848204586834;
		    z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    z__2.r = t3.r * .618033988749894848204586834, z__2.i = 
			    t3.i * .618033988749894848204586834;
		    z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__9 = i__ + c_dim1;
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t5.r + z__2.r, z__1.i = t5.i + z__2.i;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    i__9 = i__ + (c_dim1 << 2);
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t5.r - z__2.r, z__1.i = t5.i - z__2.i;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    i__9 = i__ + (c_dim1 << 1);
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t2.r + z__2.r, z__1.i = t2.i + z__2.i;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
		    i__9 = i__ + c_dim1 * 3;
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t2.r - z__2.r, z__1.i = t2.i - z__2.i;
		    c__[i__9].r = z__1.r, c__[i__9].i = z__1.i;
/* L80: */
		}
	    }
/* L90: */
	}
	lamf += mfftpa_1.mx;
/* L100: */
    }
    i__2 = mfftpa_1.mlim;
    i__1 = mfftpa_1.mstep;
    for (mu = 0; i__1 < 0 ? mu >= i__2 : mu <= i__2; mu += i__1) {
	i__4 = mu + mfftpa_1.ivlim;
	i__3 = mfftpa_1.ivs;
	for (iv = mu; i__3 < 0 ? iv >= i__4 : iv <= i__4; iv += i__3) {
	    i__8 = iv + mfftpa_1.ilim;
	    i__7 = mfftpa_1.ies;
	    for (i__ = iv; i__7 < 0 ? i__ >= i__8 : i__ <= i__8; i__ += i__7) 
		    {
		i__6 = i__ + c_dim1;
		i__5 = i__ + (c_dim1 << 2);
		z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + 
			c__[i__5].i;
		t1.r = z__1.r, t1.i = z__1.i;
		i__6 = i__ + (c_dim1 << 1);
		i__5 = i__ + c_dim1 * 3;
		z__1.r = c__[i__6].r + c__[i__5].r, z__1.i = c__[i__6].i + 
			c__[i__5].i;
		t2.r = z__1.r, t2.i = z__1.i;
		i__6 = i__ + c_dim1;
		i__5 = i__ + (c_dim1 << 2);
		z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - 
			c__[i__5].i;
		z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			z__2.i * .951056516295153572116439333;
		t3.r = z__1.r, t3.i = z__1.i;
		i__6 = i__ + (c_dim1 << 1);
		i__5 = i__ + c_dim1 * 3;
		z__2.r = c__[i__6].r - c__[i__5].r, z__2.i = c__[i__6].i - 
			c__[i__5].i;
		z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			z__2.i * .951056516295153572116439333;
		t4.r = z__1.r, t4.i = z__1.i;
		z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
		t5.r = z__1.r, t5.i = z__1.i;
		z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
		z__1.r = z__2.r * .559016994374947424102293417, z__1.i = 
			z__2.i * .559016994374947424102293417;
		t1.r = z__1.r, t1.i = z__1.i;
		i__6 = i__;
		z__2.r = t5.r * .25, z__2.i = t5.i * .25;
		z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - z__2.i;
		t2.r = z__1.r, t2.i = z__1.i;
		i__6 = i__;
		i__5 = i__;
		z__1.r = c__[i__5].r + t5.r, z__1.i = c__[i__5].i + t5.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
		t5.r = z__1.r, t5.i = z__1.i;
		z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
		t2.r = z__1.r, t2.i = z__1.i;
		z__2.r = t4.r * .618033988749894848204586834, z__2.i = t4.i * 
			.618033988749894848204586834;
		z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
		t1.r = z__1.r, t1.i = z__1.i;
		z__2.r = t3.r * .618033988749894848204586834, z__2.i = t3.i * 
			.618033988749894848204586834;
		z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
		t3.r = z__1.r, t3.i = z__1.i;
		i__6 = i__ + c_dim1;
		d__1 = -d_imag(&t1);
		d__2 = t1.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t5.r + z__2.r, z__1.i = t5.i + z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		i__6 = i__ + (c_dim1 << 2);
		d__1 = -d_imag(&t1);
		d__2 = t1.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t5.r - z__2.r, z__1.i = t5.i - z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		i__6 = i__ + (c_dim1 << 1);
		d__1 = -d_imag(&t3);
		d__2 = t3.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t2.r + z__2.r, z__1.i = t2.i + z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		i__6 = i__ + c_dim1 * 3;
		d__1 = -d_imag(&t3);
		d__2 = t3.r;
		z__2.r = d__1, z__2.i = d__2;
		z__1.r = t2.r - z__2.r, z__1.i = t2.i - z__2.i;
		c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L82: */
	    }
	}
/* L92: */
    }
} /* mfftc7_ */

/* Subroutine */ int mfftc8_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3;

    /* Builtin functions */
    double d_imag();

    /* Local variables */
    integer imuf, imuf2, imuf3, imuf4;
    doublecomplex t1, t2, t3, t4, t5;
    integer iv, lam, imu;


/*   purpose: */
/*       elementary gentleman-sande radix 5 step applied to a vector-of */
/*       2-vectors-of-complex c[ims,nm [ivs,nv [ies,ne]]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftds, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    if (mfftpa_1.mx != 1) {
	i__1 = mfftpa_1.llim;
	i__2 = mfftpa_1.lstep;
	for (lam = 0; i__2 < 0 ? lam >= i__1 : lam <= i__1; lam += i__2) {
	    i__3 = lam + mfftpa_1.ivlim;
	    i__4 = mfftpa_1.ivs;
	    for (iv = lam; i__4 < 0 ? iv >= i__3 : iv <= i__3; iv += i__4) {
		imuf = 0;
		imuf2 = mfftpa_1.nustep;
		imuf3 = mfftpa_1.nustep << 1;
		imuf4 = mfftpa_1.nustep * 3;
		i__5 = iv + mfftpa_1.ilim;
		for (imu = iv; imu <= i__5; ++imu) {
		    i__6 = imu + c_dim1;
		    i__7 = imu + (c_dim1 << 2);
		    z__1.r = c__[i__6].r + c__[i__7].r, z__1.i = c__[i__6].i 
			    + c__[i__7].i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = imu + (c_dim1 << 1);
		    i__7 = imu + c_dim1 * 3;
		    z__1.r = c__[i__6].r + c__[i__7].r, z__1.i = c__[i__6].i 
			    + c__[i__7].i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = imu + c_dim1;
		    i__7 = imu + (c_dim1 << 2);
		    z__2.r = c__[i__6].r - c__[i__7].r, z__2.i = c__[i__6].i 
			    - c__[i__7].i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__6 = imu + (c_dim1 << 1);
		    i__7 = imu + c_dim1 * 3;
		    z__2.r = c__[i__6].r - c__[i__7].r, z__2.i = c__[i__6].i 
			    - c__[i__7].i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t4.r = z__1.r, t4.i = z__1.i;
		    z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
		    z__1.r = z__2.r * .559016994374947424102293417, z__1.i = 
			    z__2.i * .559016994374947424102293417;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = imu;
		    z__2.r = t5.r * .25, z__2.i = t5.i * .25;
		    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - 
			    z__2.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = imu;
		    i__7 = imu;
		    z__1.r = c__[i__7].r + t5.r, z__1.i = c__[i__7].i + t5.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    z__2.r = t4.r * .618033988749894848204586834, z__2.i = 
			    t4.i * .618033988749894848204586834;
		    z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    z__2.r = t3.r * .618033988749894848204586834, z__2.i = 
			    t3.i * .618033988749894848204586834;
		    z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__6 = imu + c_dim1;
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t5.r - z__3.r, z__2.i = t5.i - z__3.i;
		    i__7 = imuf;
		    z__1.r = z__2.r * fac[i__7].r - z__2.i * fac[i__7].i, 
			    z__1.i = z__2.r * fac[i__7].i + z__2.i * fac[i__7]
			    .r;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + (c_dim1 << 2);
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t5.r + z__3.r, z__2.i = t5.i + z__3.i;
		    i__7 = imuf4;
		    z__1.r = z__2.r * fac[i__7].r - z__2.i * fac[i__7].i, 
			    z__1.i = z__2.r * fac[i__7].i + z__2.i * fac[i__7]
			    .r;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + (c_dim1 << 1);
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t2.r - z__3.r, z__2.i = t2.i - z__3.i;
		    i__7 = imuf2;
		    z__1.r = z__2.r * fac[i__7].r - z__2.i * fac[i__7].i, 
			    z__1.i = z__2.r * fac[i__7].i + z__2.i * fac[i__7]
			    .r;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + c_dim1 * 3;
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__3.r = d__1, z__3.i = d__2;
		    z__2.r = t2.r + z__3.r, z__2.i = t2.i + z__3.i;
		    i__7 = imuf3;
		    z__1.r = z__2.r * fac[i__7].r - z__2.i * fac[i__7].i, 
			    z__1.i = z__2.r * fac[i__7].i + z__2.i * fac[i__7]
			    .r;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    ++imuf;
		    ++imuf2;
		    ++imuf3;
		    ++imuf4;
/* L180: */
		}
/* L190: */
	    }
/* L200: */
	}
    } else {
	i__2 = mfftpa_1.llim;
	i__1 = mfftpa_1.lstep;
	for (lam = 0; i__1 < 0 ? lam >= i__2 : lam <= i__2; lam += i__1) {
	    i__4 = lam + mfftpa_1.ivlim;
	    i__3 = mfftpa_1.ivs;
	    for (iv = lam; i__3 < 0 ? iv >= i__4 : iv <= i__4; iv += i__3) {
		i__5 = iv + mfftpa_1.ilim;
		for (imu = iv; imu <= i__5; ++imu) {
		    i__6 = imu + c_dim1;
		    i__7 = imu + (c_dim1 << 2);
		    z__1.r = c__[i__6].r + c__[i__7].r, z__1.i = c__[i__6].i 
			    + c__[i__7].i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = imu + (c_dim1 << 1);
		    i__7 = imu + c_dim1 * 3;
		    z__1.r = c__[i__6].r + c__[i__7].r, z__1.i = c__[i__6].i 
			    + c__[i__7].i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = imu + c_dim1;
		    i__7 = imu + (c_dim1 << 2);
		    z__2.r = c__[i__6].r - c__[i__7].r, z__2.i = c__[i__6].i 
			    - c__[i__7].i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__6 = imu + (c_dim1 << 1);
		    i__7 = imu + c_dim1 * 3;
		    z__2.r = c__[i__6].r - c__[i__7].r, z__2.i = c__[i__6].i 
			    - c__[i__7].i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t4.r = z__1.r, t4.i = z__1.i;
		    z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
		    z__1.r = z__2.r * .559016994374947424102293417, z__1.i = 
			    z__2.i * .559016994374947424102293417;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = imu;
		    z__2.r = t5.r * .25, z__2.i = t5.i * .25;
		    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - 
			    z__2.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = imu;
		    i__7 = imu;
		    z__1.r = c__[i__7].r + t5.r, z__1.i = c__[i__7].i + t5.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    z__2.r = t4.r * .618033988749894848204586834, z__2.i = 
			    t4.i * .618033988749894848204586834;
		    z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    z__2.r = t3.r * .618033988749894848204586834, z__2.i = 
			    t3.i * .618033988749894848204586834;
		    z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__6 = imu + c_dim1;
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t5.r - z__2.r, z__1.i = t5.i - z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + (c_dim1 << 2);
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t5.r + z__2.r, z__1.i = t5.i + z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + (c_dim1 << 1);
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t2.r - z__2.r, z__1.i = t2.i - z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = imu + c_dim1 * 3;
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t2.r + z__2.r, z__1.i = t2.i + z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L380: */
		}
/* L390: */
	    }
/* L400: */
	}
    }
} /* mfftc8_ */

/* Subroutine */ int mfftc9_(c__, fac)
doublecomplex *c__, *fac;
{
    /* System generated locals */
    integer c_dim1, i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8, i__9;
    doublereal d__1, d__2;
    doublecomplex z__1, z__2, z__3, z__4;

    /* Builtin functions */
    double d_imag();

    /* Local variables */
    integer ilam, ilamf;
    doublecomplex t1, t2, t3, t4, t5;
    integer ilamf2, ilamf3, ilamf4, iv, mu;


/*   purpose: */
/*       elementary cooley-tukey radix 5 step applied to a vector-of */
/*       2-vectors-of-complex c[ims,nm [ivs,nv [ies,ne]]]. */
/*       see ref.[1] for notations. */
/*       this routine can be used only by routine mfftis, which controls 
*/
/*       its operation through the mfftpa common */

/*   dummy arguments : */

/*   c   array being fourier  transformed */
/*   fac phase factors, prepared by mfftp; not modified in output */

    /* Parameter adjustments */
    c_dim1 = mfftpa_1.nustep - 1 + 1;

    /* Function Body */
    if (mfftpa_1.lx != 1) {
	i__1 = mfftpa_1.mlim;
	i__2 = mfftpa_1.mstep;
	for (mu = 0; i__2 < 0 ? mu >= i__1 : mu <= i__1; mu += i__2) {
	    i__3 = mu + mfftpa_1.ivlim;
	    i__4 = mfftpa_1.ivs;
	    for (iv = mu; i__4 < 0 ? iv >= i__3 : iv <= i__3; iv += i__4) {
		ilamf = 0;
		ilamf2 = mfftpa_1.nustep;
		ilamf3 = mfftpa_1.nustep << 1;
		ilamf4 = mfftpa_1.nustep * 3;
		i__5 = iv + mfftpa_1.ilim;
		for (ilam = iv; ilam <= i__5; ++ilam) {
		    i__6 = ilam + c_dim1;
		    i__7 = ilamf;
		    z__2.r = c__[i__6].r * fac[i__7].r - c__[i__6].i * fac[
			    i__7].i, z__2.i = c__[i__6].r * fac[i__7].i + c__[
			    i__6].i * fac[i__7].r;
		    i__8 = ilam + (c_dim1 << 2);
		    i__9 = ilamf4;
		    z__3.r = c__[i__8].r * fac[i__9].r - c__[i__8].i * fac[
			    i__9].i, z__3.i = c__[i__8].r * fac[i__9].i + c__[
			    i__8].i * fac[i__9].r;
		    z__1.r = z__2.r + z__3.r, z__1.i = z__2.i + z__3.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = ilam + (c_dim1 << 1);
		    i__7 = ilamf2;
		    z__2.r = c__[i__6].r * fac[i__7].r - c__[i__6].i * fac[
			    i__7].i, z__2.i = c__[i__6].r * fac[i__7].i + c__[
			    i__6].i * fac[i__7].r;
		    i__8 = ilam + c_dim1 * 3;
		    i__9 = ilamf3;
		    z__3.r = c__[i__8].r * fac[i__9].r - c__[i__8].i * fac[
			    i__9].i, z__3.i = c__[i__8].r * fac[i__9].i + c__[
			    i__8].i * fac[i__9].r;
		    z__1.r = z__2.r + z__3.r, z__1.i = z__2.i + z__3.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = ilam + c_dim1;
		    i__7 = ilamf;
		    z__3.r = c__[i__6].r * fac[i__7].r - c__[i__6].i * fac[
			    i__7].i, z__3.i = c__[i__6].r * fac[i__7].i + c__[
			    i__6].i * fac[i__7].r;
		    i__8 = ilam + (c_dim1 << 2);
		    i__9 = ilamf4;
		    z__4.r = c__[i__8].r * fac[i__9].r - c__[i__8].i * fac[
			    i__9].i, z__4.i = c__[i__8].r * fac[i__9].i + c__[
			    i__8].i * fac[i__9].r;
		    z__2.r = z__3.r - z__4.r, z__2.i = z__3.i - z__4.i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__6 = ilam + (c_dim1 << 1);
		    i__7 = ilamf2;
		    z__3.r = c__[i__6].r * fac[i__7].r - c__[i__6].i * fac[
			    i__7].i, z__3.i = c__[i__6].r * fac[i__7].i + c__[
			    i__6].i * fac[i__7].r;
		    i__8 = ilam + c_dim1 * 3;
		    i__9 = ilamf3;
		    z__4.r = c__[i__8].r * fac[i__9].r - c__[i__8].i * fac[
			    i__9].i, z__4.i = c__[i__8].r * fac[i__9].i + c__[
			    i__8].i * fac[i__9].r;
		    z__2.r = z__3.r - z__4.r, z__2.i = z__3.i - z__4.i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t4.r = z__1.r, t4.i = z__1.i;
		    z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
		    z__1.r = z__2.r * .559016994374947424102293417, z__1.i = 
			    z__2.i * .559016994374947424102293417;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = ilam;
		    z__2.r = t5.r * .25, z__2.i = t5.i * .25;
		    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - 
			    z__2.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = ilam;
		    i__7 = ilam;
		    z__1.r = c__[i__7].r + t5.r, z__1.i = c__[i__7].i + t5.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    z__2.r = t4.r * .618033988749894848204586834, z__2.i = 
			    t4.i * .618033988749894848204586834;
		    z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    z__2.r = t3.r * .618033988749894848204586834, z__2.i = 
			    t3.i * .618033988749894848204586834;
		    z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__6 = ilam + c_dim1;
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t5.r + z__2.r, z__1.i = t5.i + z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam + (c_dim1 << 2);
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t5.r - z__2.r, z__1.i = t5.i - z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam + (c_dim1 << 1);
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t2.r + z__2.r, z__1.i = t2.i + z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam + c_dim1 * 3;
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t2.r - z__2.r, z__1.i = t2.i - z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    ++ilamf;
		    ++ilamf2;
		    ++ilamf3;
		    ++ilamf4;
/* L100: */
		}
/* L150: */
	    }
/* L200: */
	}
    } else {
	i__2 = mfftpa_1.mlim;
	i__1 = mfftpa_1.mstep;
	for (mu = 0; i__1 < 0 ? mu >= i__2 : mu <= i__2; mu += i__1) {
	    i__4 = mu + mfftpa_1.ivlim;
	    i__3 = mfftpa_1.ivs;
	    for (iv = mu; i__3 < 0 ? iv >= i__4 : iv <= i__4; iv += i__3) {
		i__5 = iv + mfftpa_1.ilim;
		for (ilam = iv; ilam <= i__5; ++ilam) {
		    i__6 = ilam + c_dim1;
		    i__7 = ilam + (c_dim1 << 2);
		    z__1.r = c__[i__6].r + c__[i__7].r, z__1.i = c__[i__6].i 
			    + c__[i__7].i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = ilam + (c_dim1 << 1);
		    i__7 = ilam + c_dim1 * 3;
		    z__1.r = c__[i__6].r + c__[i__7].r, z__1.i = c__[i__6].i 
			    + c__[i__7].i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = ilam + c_dim1;
		    i__7 = ilam + (c_dim1 << 2);
		    z__2.r = c__[i__6].r - c__[i__7].r, z__2.i = c__[i__6].i 
			    - c__[i__7].i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__6 = ilam + (c_dim1 << 1);
		    i__7 = ilam + c_dim1 * 3;
		    z__2.r = c__[i__6].r - c__[i__7].r, z__2.i = c__[i__6].i 
			    - c__[i__7].i;
		    z__1.r = z__2.r * .951056516295153572116439333, z__1.i = 
			    z__2.i * .951056516295153572116439333;
		    t4.r = z__1.r, t4.i = z__1.i;
		    z__1.r = t1.r + t2.r, z__1.i = t1.i + t2.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__2.r = t1.r - t2.r, z__2.i = t1.i - t2.i;
		    z__1.r = z__2.r * .559016994374947424102293417, z__1.i = 
			    z__2.i * .559016994374947424102293417;
		    t1.r = z__1.r, t1.i = z__1.i;
		    i__6 = ilam;
		    z__2.r = t5.r * .25, z__2.i = t5.i * .25;
		    z__1.r = c__[i__6].r - z__2.r, z__1.i = c__[i__6].i - 
			    z__2.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    i__6 = ilam;
		    i__7 = ilam;
		    z__1.r = c__[i__7].r + t5.r, z__1.i = c__[i__7].i + t5.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    z__1.r = t2.r + t1.r, z__1.i = t2.i + t1.i;
		    t5.r = z__1.r, t5.i = z__1.i;
		    z__1.r = t2.r - t1.r, z__1.i = t2.i - t1.i;
		    t2.r = z__1.r, t2.i = z__1.i;
		    z__2.r = t4.r * .618033988749894848204586834, z__2.i = 
			    t4.i * .618033988749894848204586834;
		    z__1.r = t3.r + z__2.r, z__1.i = t3.i + z__2.i;
		    t1.r = z__1.r, t1.i = z__1.i;
		    z__2.r = t3.r * .618033988749894848204586834, z__2.i = 
			    t3.i * .618033988749894848204586834;
		    z__1.r = z__2.r - t4.r, z__1.i = z__2.i - t4.i;
		    t3.r = z__1.r, t3.i = z__1.i;
		    i__6 = ilam + c_dim1;
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t5.r + z__2.r, z__1.i = t5.i + z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam + (c_dim1 << 2);
		    d__1 = -d_imag(&t1);
		    d__2 = t1.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t5.r - z__2.r, z__1.i = t5.i - z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam + (c_dim1 << 1);
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t2.r + z__2.r, z__1.i = t2.i + z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
		    i__6 = ilam + c_dim1 * 3;
		    d__1 = -d_imag(&t3);
		    d__2 = t3.r;
		    z__2.r = d__1, z__2.i = d__2;
		    z__1.r = t2.r - z__2.r, z__1.i = t2.i - z__2.i;
		    c__[i__6].r = z__1.r, c__[i__6].i = z__1.i;
/* L300: */
		}
/* L350: */
	    }
/* L400: */
	}
    }
} /* mfftc9_ */

/* Subroutine */ int mfftp1_(w, nm, ierr)
integer *w, *nm, *ierr;
{
    /* Initialized data */

    static integer factor[3] = { 2,3,5 };

    integer i__, n;


/*   purpose : */
/*     factorization of nm storing the powers of each factor in w */
/*     ( nm = 2**w(1)*3**w(2)*... ) */
/*     the maximum factor found  is stored in w(14) */

    /* Parameter adjustments */
    --w;

    /* Function Body */
    n = *nm;
    for (i__ = 1; i__ <= 3; ++i__) {
	w[i__] = 0;
L10:
	if (n % factor[i__ - 1] == 0) {
	    ++w[i__];
	    n /= factor[i__ - 1];
	    goto L10;
	}
	if (n == 1) {
	    goto L200;
	}
/* L100: */
    }
    *ierr = 2;
    return 0;
L200:
    w[14] = i__;
} /* mfftp1_ */

/* Subroutine */ int mfftp2_(indx, indxi, i2, iw, nm)
integer *indx, *indxi, *i2, *iw, *nm;
{
    /* Initialized data */

    static integer factor[3] = { 2,3,5 };

    /* System generated locals */
    integer i__1, i__2;

    /* Local variables */
    integer ifac, i__, idest;
    extern /* Subroutine */ int mfftp3_();
    integer it, lx, mx;


/*     this routine computes two index tables for the */
/*     permutation due to representation inversion ("bit reversal") */
/*     the index tables are stored one after the other, and are */
/*     reciprocal. */

/*     warning: by "bit reversal" we mean the shuffling of indexes */
/*              as required by in-place fft algorithms, regardless */
/*              of what is their radix (i.e. 2,3,5). */
/*              the shuffling is effectively an 'integer bit reversal' */
/*              only in case of radix-2 algorithms. */

    /* Parameter adjustments */
    --iw;

    /* Function Body */
    i__1 = *nm - 1;
    for (i__ = 0; i__ <= i__1; ++i__) {
	indx[i__] = i__;
/* L1: */
    }
    ifac = iw[14];
    lx = 1;
    mx = *nm;
    i__1 = ifac;
    for (ifac = 1; ifac <= i__1; ++ifac) {
	i__2 = iw[ifac] - 1;
	for (i__ = 1; i__ <= i__2; i__ += 2) {
	    mx /= factor[ifac - 1];
	    mfftp3_(indx, i2, &mx, &factor[ifac - 1], &lx);
	    lx *= factor[ifac - 1];
	    mx /= factor[ifac - 1];
	    mfftp3_(i2, indx, &mx, &factor[ifac - 1], &lx);
	    lx *= factor[ifac - 1];
/* L10: */
	}
/* ...  if w(ifac)odd,then */
	if (i__ == iw[ifac]) {
	    mx /= factor[ifac - 1];
	    mfftp3_(indx, i2, &mx, &factor[ifac - 1], &lx);
	    lx *= factor[ifac - 1];
	    i__2 = *nm - 1;
	    for (i__ = 0; i__ <= i__2; ++i__) {
		indx[i__] = i2[i__];
/* L20: */
	    }
	}
/* L30: */
    }
/* ...     inverse permutation */
    i__1 = *nm - 1;
    for (i__ = 0; i__ <= i__1; ++i__) {
	i2[i__] = indx[i__];
	indxi[i__] = i__;
/* L40: */
    }
    i__1 = *nm - 3;
    for (i__ = 1; i__ <= i__1; ++i__) {
L51:
	if (i2[i__] != i__) {
	    idest = i2[i__];
	    it = indxi[i__];
	    indxi[i__] = indxi[idest];
	    indxi[idest] = it;
	    i2[i__] = i2[idest];
	    i2[idest] = idest;
	    goto L51;
	}
/* L59: */
    }
} /* mfftp2_ */

/* Subroutine */ int mfftp3_(indx, i1, mx, nx, lx)
integer *indx, *i1, *mx, *nx, *lx;
{
    /* System generated locals */
    integer indx_dim1, indx_dim2, indx_offset, i1_dim1, i1_dim2, i1_offset, 
	    i__1, i__2, i__3;

    /* Local variables */
    integer mu, nu, lam;


/*     this subroutine performs a "bit reversal" permutation */

    /* Parameter adjustments */
    i1_dim1 = *mx;
    i1_dim2 = *lx;
    i1_offset = i1_dim1 * (i1_dim2 + 1) + 1;
    i1 -= i1_offset;
    indx_dim1 = *mx;
    indx_dim2 = *nx;
    indx_offset = indx_dim1 * (indx_dim2 + 1) + 1;
    indx -= indx_offset;

    /* Function Body */
    i__1 = *nx;
    for (nu = 1; nu <= i__1; ++nu) {
	i__2 = *mx;
	for (mu = 1; mu <= i__2; ++mu) {
	    i__3 = *lx;
	    for (lam = 1; lam <= i__3; ++lam) {
		i1[mu + (lam + nu * i1_dim2) * i1_dim1] = indx[mu + (nu + lam 
			* indx_dim2) * indx_dim1];
/* L1: */
	    }
	}
    }
} /* mfftp3_ */

/* Subroutine */ int mfftp4_(exptab, spetab, factab, n, n1)
doublecomplex *exptab, *spetab;
integer *factab, *n, *n1;
{
    /* Initialized data */

    static integer factor[3] = { 2,3,5 };

    /* System generated locals */
    integer i__1, i__2, i__3, i__4, i__5, i__6, i__7;
    doublecomplex z__1;

    /* Builtin functions */
    void d_cnjg();

    /* Local variables */
    integer ipow, j, ifact, i1, lambda, mu, nu, lx, mx, nx;


/*     this subroutine builds the twiddle factor tables for use */
/*     of mfft?s routines (special optimization for small */
/*     data matrices); it must be used by mfftp only. */

/*     parameters: */
/*     exptab: twiddle factor table */
/*     spetab: special twiddle factor table */
/*     factab: factorization of n */
/*     n: order of the transform */
/*     n1: first dimension of the array to be transformed (.ge.n) */

    /* Parameter adjustments */
    --factab;

    /* Function Body */
    mx = *n;
    lx = 1;
    j = 0;
    for (ifact = factab[14]; ifact >= 1; --ifact) {
	nx = factor[ifact - 1];
	i__1 = factab[ifact];
	for (ipow = 1; ipow <= i__1; ++ipow) {
	    mx /= nx;
	    i__2 = nx - 1;
	    for (nu = 1; nu <= i__2; ++nu) {
		i__3 = mx - 1;
		for (mu = 0; mu <= i__3; ++mu) {
		    i__4 = *n1 - 1;
		    for (i1 = 0; i1 <= i__4; ++i1) {
			i__5 = j;
			d_cnjg(&z__1, &exptab[mu * lx * nu]);
			spetab[i__5].r = z__1.r, spetab[i__5].i = z__1.i;
			++j;
/* L10: */
		    }
/* L20: */
		}
/* L30: */
	    }
	    lx *= nx;
/* L40: */
	}
/* L50: */
    }
    mx = *n;
    lx = 1;
    j = *n * *n1;
    i__1 = factab[14];
    for (ifact = 1; ifact <= i__1; ++ifact) {
	nx = factor[ifact - 1];
	i__2 = factab[ifact];
	for (ipow = 1; ipow <= i__2; ++ipow) {
	    mx /= nx;
	    i__3 = nx - 1;
	    for (nu = 1; nu <= i__3; ++nu) {
		i__4 = lx - 1;
		for (lambda = 0; lambda <= i__4; ++lambda) {
		    i__5 = *n1 - 1;
		    for (i1 = 0; i1 <= i__5; ++i1) {
			i__6 = j;
			i__7 = mx * lambda * nu;
			spetab[i__6].r = exptab[i__7].r, spetab[i__6].i = 
				exptab[i__7].i;
			++j;
/* L60: */
		    }
/* L70: */
		}
/* L80: */
	    }
	    lx *= nx;
/* L90: */
	}
/* L100: */
    }
} /* mfftp4_ */

/* Subroutine */ int mfftz0_(w1, ise1, ne, w2, ise2)
doublecomplex *w1;
integer *ise1, *ne;
doublecomplex *w2;
integer *ise2;
{
    /* System generated locals */
    integer i__1, i__2, i__3, i__4;

    /* Local variables */
    integer i__, j;

/* *** purpose : vector copy routine */
/*    parameters : */
/*        w1 : vector to be copied */
/*        ise1: stride of w1 */
/*        ne : number of elements */
/*        w2 : destination vector */
/*        ise2: stride of w2 */
    j = 0;
    i__1 = (*ne - 1) * *ise1;
    i__2 = *ise1;
    for (i__ = 0; i__2 < 0 ? i__ >= i__1 : i__ <= i__1; i__ += i__2) {
	i__3 = j;
	i__4 = i__;
	w2[i__3].r = w1[i__4].r, w2[i__3].i = w1[i__4].i;
	j += *ise2;
/* L1: */
    }
} /* mfftz0_ */

