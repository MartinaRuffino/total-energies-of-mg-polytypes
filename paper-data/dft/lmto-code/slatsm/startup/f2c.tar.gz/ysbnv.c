/* ysbnv.f -- translated by f2c (version 19970805).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* #define RECUR */
/* #define AIX */
/* #define RECUR */
/* Subroutine */ int ysbnv_(mode, ap, ofapi, ldap, ija, offs, nlev, nn1, nn2, 
	w, ldw, a, ofai, lda, ierr)
integer *mode;
doublereal *ap;
integer *ofapi, *ldap, *ija, *offs, *nlev, *nn1, *nn2;
doublereal *w;
integer *ldw;
doublereal *a;
integer *ofai, *lda, *ierr;
{
    /* System generated locals */
    integer w_dim1, w_offset;

    /* Local variables */
    extern /* Subroutine */ int yysbnv_();

/* - Inversion of a complex block sparse matrix using Strassen's algorithm
 */
/* ---------------------------------------------------------------- */
/* i Inputs: */
/* i   mode   :1s digit */
/* i           1 only the diagonal parts subblocks of matrix are complex 
*/
/* i             (only case tested so far) */
/* i           2 full matrix is complex */
/* i           3 matrix is hermetian (not tested) */
/* i          10s digit fixes how array is partitioned */
/* i             It is passed as first argument to psybnv */
/* i           0 partitions array into approximately equal numbers */
/* i             of nonzero subblocks */
/* i           1 partitions array into approximately equal dimensions */
/* i   nnmin  :fewest subblocks for which ysbnv calls itself recursively. 
*/
/* i   ap     :array to invert, in packed form */
/* i   ofapi  :number of elements separating real, imaginary parts of ap 
*/
/* i   ldap   :leading dimensions of apr,api */
/* i   ofai   :number of elements separating real, imaginary parts of a */
/* i   lda    :leading dimension of ar,ai */
/* i   ija    :column index packed array pointer data; see Remarks */
/* i   offs   :offsets to first entries in matrix subblocks. NB: offs(1)=0
 */
/* i           Subblock dimension of row(or col) i = offs(i+1) - offs(i) 
*/
/* i   nn1,nn2:range of subblocks which comprise the matrix to be inverted
 */
/* i           the matrix subblock to be inverted consist of the */
/* i           rows and columns  offs(nn1)+1...offs(nn2+1) */
/* i   nlev   :the maximum number of recursion levels allowed. */
/* i           To avoid roundoff errors, nlev=2 is suggested. */
/* i   w,ldw  :complex work array of dimension ldw*n */
/* o Outputs: */
/* o   a      :inverse of matrix, stored in a(i:j,i:j) with */
/* o           i = offs(nn1)+1 and j = offs(nn2+1). */
/* o   ierr is returned nonzero if matrix could not be inverted. */
/* r Remarks: */
/* r  *ysbnv uses the Strassen algorithm to invert a subblock of a matrix 
*/
/* r   stored in block packed form.  The inverse is not assumed to be */
/* r   sparse, and is returned in conventional form in ar,ai.  Arrays */
/* r   ija,offs,apr,api contain data for the matrix; see yysp2a for a */
/* r   description of block matrix storage conventions, the use of these 
*/
/* r   arrays, and how a matrix subblock may be unpacked from them into */
/* r   conventional form. */
/* r */
/* r  *The matrix to be inverted comprises the rows (and columns) */
/* r   offs(nn1)+1...offs(nn2+1) of a.  ysqnv partitions these rows and */
/* r   columns into four subblocks a11,a21,a12,a22.  (See below for how */
/* r   the 1 and 2 partitions are apportioned.)  Let c be the inverse, */
/* r   with subblocks c11,c21,c12,c22.  Then inversion proceeds by: */
/* r      (1) invert   a22 (see below for recursive inversion) */
/* r      (2) generate (c11)^-1 = (a11 - a12 a22^-1 a21) */
/* r      (3) invert   (c11)^-1 */
/* r      (4) generate c21 = -(a22^-1 a21) c11 is */
/* r      (5) generate c12 = -c11 a12 a22^-1 is generated */
/* r      (6) generate c22 = a22^-1 + (a22^-1 a21 c11) (a12 a22^-1) */
/* r   These steps require two inversions, three sparse and three normal 
*/
/* r   multiplications. */
/* r */
/* r  *Partitioning into subblocks.  Partitions 1 and 2 consist of */
/* r   offs(nn1)+1...offs(nm1+1) and offs(nm1+1)+1...offs(nn2+1). */
/* r   nm1 is set in psybnv according to the 10s digit of mode. */
/* r */
/* r  *Inversion of the subblocks.  It is more efficient to allow */
/* r   inversion of a22 to proceed recursively, if your compiler allows */
/* r   it.  Recursion proceeds provided nlev>0, the number of subblocks */
/* r   exceeds nnmin and the dimension of the matrix to be inverted */
/* r   exceeds nmin.  (c11)^-1 is inverted calling yyqinv, which can */
/* r   also proceed recursively. */
/* b Bugs */
/* b   ysbnv has not been tested for the hermetian case, */
/* b   nor handle it efficiently. */
/* ---------------------------------------------------------------- */
    /* Parameter adjustments */
    --ap;
    ija -= 3;
    --offs;
    w_dim1 = *ldw;
    w_offset = w_dim1 + 1;
    w -= w_offset;
    --a;

    /* Function Body */
    yysbnv_(mode, &ap[1], &ap[*ofapi + 1], ldap, &ija[3], &offs[1], nlev, nn1,
	     nn2, &w[w_offset], ldw, &a[1], &a[*ofai + 1], lda, ierr);
} /* ysbnv_ */

