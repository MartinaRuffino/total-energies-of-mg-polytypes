/* dqinv.f -- translated by f2c (version 19970805).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Table of constant values */

static integer c__1 = 1;
static doublereal c_b14 = 1.;
static doublereal c_b15 = 0.;
static doublereal c_b29 = -1.;

/* #define RECUR */
/* #define AIX */
/* #define RECUR */
/* Subroutine */ int dqinv_0_(n__, cs, a, lda, nlev, n, w, ldw, ierr, nmin0, 
	isw, cs_len)
int n__;
char *cs;
doublereal *a;
integer *lda, *nlev, *n;
doublereal *w;
integer *ldw, *ierr, *nmin0, *isw;
ftnlen cs_len;
{
    /* Initialized data */

    static integer nmin = 32;

    /* System generated locals */
    integer a_dim1, a_offset, w_dim1, w_offset, i__1, i__2;

    /* Local variables */
    extern /* Subroutine */ int dgefa_();
    integer i__, j;
    extern /* Subroutine */ int dgedi_(), dsifa_(), dgemm_(), dsidi_(), 
	    dsmpy_();
    integer m1, m2;
    extern /* Subroutine */ int rx_();
    doublereal xx[2];

/* - Inversion of a real matrix using Strassen's algorithm */
/* ---------------------------------------------------------------- */
/* i Inputs: */
/* i   a,lda matrix to be inverted and its leading dimension */
/* i   n    rank of the matrix to be inverted */
/* i   nlev is the maximum number of recursion levels allowed. */
/* i         To avoid roundoff errors, nlev=2 is suggested. */
/* i   w     is a real work array of dimension lda*n */
/* i   cs:   if 's', a is assumed symmetric */
/* o Outputs: */
/* o   a^-1 is returned in a */
/* o   ierr is returned nonzero if matrix was not fully inverted. */
/* r Remarks: */
/* r   See Numerical Recipes, 2.11. */
/* r   It is more efficient to allow inversion to proceed recursively, */
/* r   if your compiler allows it.  Recursion proceeds provided nlev>0 */
/* r   and the dimension of the matrix to be inverted exceeds nmin. */
/* r   The latter should be chosen where the tradoff between */
/* r   the extra overhead and fewer O(N^3) operations takes place. */
/* r   The AIX xlf90 compiler overwrites locally declared variables, */
/* r   (use the -qrecur switch when compiling).  Compiling with AIX */
/*r   code uncommented restores necessary variables after a recursive call
.*/
/* r   (For debugging:) */
/* r   mc -f4f16.10 a -split a 1,3,5 1,3,5  a11 -i -a r1  a21 r1 -x -a r2\
 */
/* r   r2 a12 -x -a r4  r4 a22 -- -a r5  r5 -i -a r6  r1 a12 -x -a r3\ */
/* r   r3 r6 -x -a c12  r6 r2 -x -a c21  r3 c21 -x -a r7 r1 r7 -- -a c11\ 
*/
/* r   r6 -s-1 -a c22 c11 c12 -ccat c21 c22 -ccat -rcat */
/* ---------------------------------------------------------------- */
/* #ifdefC DEBUG */
/*      character*10 fmt */
/*      data fmt /'(8f16.10)'/ */
/* #endif */
    /* Parameter adjustments */
    if (a) {
	a_dim1 = *lda;
	a_offset = a_dim1 + 1;
	a -= a_offset;
	}
    if (w) {
	w_dim1 = *ldw;
	w_offset = w_dim1 + 1;
	w -= w_offset;
	}

    /* Function Body */
    switch(n__) {
	case 1: goto L_dqinv0;
	}

/* #ifdefC DEBUG */
/*      print *, 'entering dqinv cs=',cs,' nlev,n=',nlev,n */
/* #endif */
    m1 = *n / 2;
    m2 = *n - m1;
/* --- Straight dgefa,di if n lt nmin --- */
    if (*n <= nmin) {
	if (*(unsigned char *)cs != 's' || *n <= 2) {
	    dgefa_(&a[a_offset], lda, n, &w[w_offset], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    if (*n <= 2) {
		dgedi_(&a[a_offset], lda, n, &w[w_offset], xx, xx, &c__1);
	    } else {
		dgedi_(&a[a_offset], lda, n, &w[w_offset], xx, &w[(w_dim1 << 
			1) + 1], &c__1);
	    }
	} else {
	    dsifa_(&a[a_offset], lda, n, &w[w_offset], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    dsidi_(&a[a_offset], lda, n, &w[w_offset], xx, &i__, &w[(w_dim1 <<
		     1) + 1], &c__1);
	    i__1 = *n;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		i__2 = i__;
		for (j = 1; j <= i__2; ++j) {
/* L10: */
		    a[i__ + j * a_dim1] = a[j + i__ * a_dim1];
		}
	    }
	}
/* #ifdefC DEBUG */
/*        print *, 'exit dqinv, no Strassen' */
/* #endif */
	return 0;
    }
    if (*lda < *n) {
	rx_("dqinv: lda lt n", 15L);
    }
/* --- R1 = a11^-1 in a11 --- */
/* #ifdef RECUR */
    if (m1 < nmin || *nlev == 0) {
/* #endif */
	if (*(unsigned char *)cs == 's') {
	    dsifa_(&a[a_offset], lda, &m1, &w[w_offset], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    dsidi_(&a[a_offset], lda, &m1, &w[w_offset], xx, &i__, &w[(w_dim1 
		    << 1) + 1], &c__1);
	    i__2 = *n;
	    for (i__ = 1; i__ <= i__2; ++i__) {
		i__1 = i__;
		for (j = 1; j <= i__1; ++j) {
/* L12: */
		    a[i__ + j * a_dim1] = a[j + i__ * a_dim1];
		}
	    }
	} else {
	    dgefa_(&a[a_offset], lda, &m1, &w[w_offset], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    dgedi_(&a[a_offset], lda, &m1, &w[w_offset], xx, &w[(w_dim1 << 1) 
		    + 1], &c__1);
	}
/* #ifdef RECUR */
    } else {
/* #ifdefC DEBUG */
/*        print *, 'recursive call to dqinv n,m1,m2=',n,m1,m2 */
/* #endif */
/* #ifdef AIX | SUN-ULTRA */
	i__1 = *nlev - 1;
	i__2 = m1;
	dqinv_(cs, &a[a_offset], lda, &i__1, &i__2, &w[w_offset], ldw, ierr, 
		1L);
	m1 = *n / 2;
	m2 = *n - m1;
/* #elseC */
/*        call dqinv(cs,a,lda,nlev-1,m1,w,ldw,ierr) */
/* #endif */
/* #ifdefC DEBUG */
/*        print *, 'recursive call exit dqinv n,m1,m2=',n,m1,m2 */
/* #endif */
	if (*ierr != 0) {
	    return 0;
	}
    }
/* #endif */
/*     call ywrm(0,'R1',1,6,fmt,a,1,lda,m1,m1) */
/* --- R3 = R1 a12 in w  --- */
    dgemm_("N", "N", &m1, &m2, &m1, &c_b14, &a[a_offset], lda, &a[(m1 + 1) * 
	    a_dim1 + 1], lda, &c_b15, &w[w_offset], ldw, 1L, 1L);
/*     call ywrm(0,'R3',1,6,fmt,w,1,ldw,m1,m2) */
/* --- R4 = a21 R3 = a21 a11^-1 a12 in w21  --- */
    if (*(unsigned char *)cs == 's') {
	dsmpy_(&m2, &m1, &a[m1 + 1 + a_dim1], lda, &w[w_offset], ldw, &c_b15, 
		&w[m1 + 1 + w_dim1], ldw);
    } else {
	dgemm_("N", "N", &m2, &m2, &m1, &c_b14, &a[m1 + 1 + a_dim1], lda, &w[
		w_offset], ldw, &c_b15, &w[m1 + 1 + w_dim1], ldw, 1L, 1L);
    }
/*     call ywrm(0,'R4',1,6,fmt,w(1+m1,1),1,ldw,m2,m2) */
/* --- -R5 = a22 - R4 = a22 - a21 a11^-1 a12 in a22 --- */
    i__1 = m2;
    for (j = 1; j <= i__1; ++j) {
	i__2 = m2;
	for (i__ = 1; i__ <= i__2; ++i__) {
/* L20: */
	    a[i__ + m1 + (j + m1) * a_dim1] -= w[i__ + m1 + j * w_dim1];
	}
    }
/*     call ywrm(0,'-R5',1,6,fmt,a(1+m1,1+m1),1,lda,m2,m2) */
/* --- c22 = -R6 = -R5^-1 = (a22 - a21 a11^-1 a12)^-1 in a22 --- */
/* #ifdef RECUR */
    if (m2 < nmin || *nlev == 0) {
/* #endif RECUR */
	if (*(unsigned char *)cs == 's') {
	    dsifa_(&a[m1 + 1 + (m1 + 1) * a_dim1], lda, &m2, &w[m1 + 1 + 
		    w_dim1], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    dsidi_(&a[m1 + 1 + (m1 + 1) * a_dim1], lda, &m2, &w[m1 + 1 + 
		    w_dim1], xx, &i__, &w[m1 + 1 + (w_dim1 << 1)], &c__1);
	    i__2 = *n;
	    for (i__ = 1; i__ <= i__2; ++i__) {
		i__1 = i__;
		for (j = 1; j <= i__1; ++j) {
/* L16: */
		    a[i__ + j * a_dim1] = a[j + i__ * a_dim1];
		}
	    }
	} else {
	    dgefa_(&a[m1 + 1 + (m1 + 1) * a_dim1], lda, &m2, &w[m1 + 1 + 
		    w_dim1], ierr);
	    if (*ierr != 0) {
		return 0;
	    }
	    dgedi_(&a[m1 + 1 + (m1 + 1) * a_dim1], lda, &m2, &w[m1 + 1 + 
		    w_dim1], xx, &w[m1 + 1 + (w_dim1 << 1)], &c__1);
	}
/* #ifdef RECUR */
    } else {
/* #ifdefC DEBUG */
/*        print *, 'recursive call to dqinv n,m1,m2=',n,m1,m2 */
/* #endif */
/* #ifdef AIX | SUN-ULTRA */
	i__1 = *nlev - 1;
	i__2 = m2;
	dqinv_(cs, &a[m1 + 1 + (m1 + 1) * a_dim1], lda, &i__1, &i__2, &w[m1 + 
		1 + w_dim1], ldw, ierr, 1L);
	m1 = *n / 2;
	m2 = *n - m1;
/* #elseC */
/*        call dqinv(cs,a(1+m1,1+m1),lda,nlev-1,m2,w(1+m1,1),ldw,ierr)
 */
/* #endif */
/* #ifdefC DEBUG */
/*        print *, 'recursive call exit dqinv n,m1,m2=',n,m1,m2 */
/* #endif */
	if (*ierr != 0) {
	    return 0;
	}
    }
/* #endif RECUR */
/*     call ywrm(0,'-R6',1,6,fmt,a(1+m1,1+m1),1,lda,m2,m2) */
/* --- c12 = R3 * R6 = -a11^-1 a12 c22 in a12 --- */
    dgemm_("N", "N", &m1, &m2, &m2, &c_b29, &w[w_offset], ldw, &a[m1 + 1 + (
	    m1 + 1) * a_dim1], lda, &c_b15, &a[(m1 + 1) * a_dim1 + 1], lda, 
	    1L, 1L);
/*     call ywrm(0,'c12',1,6,fmt,a(1,1+m1),1,lda,m1,m2) */
/* --- Symmetric case: R2 = R3+ and c21=c12+ --- */
    if (*(unsigned char *)cs == 's') {
	i__1 = m1;
	for (j = 1; j <= i__1; ++j) {
	    i__2 = m2;
	    for (i__ = 1; i__ <= i__2; ++i__) {
/* L30: */
		a[i__ + m1 + j * a_dim1] = a[j + (i__ + m1) * a_dim1];
	    }
	}
/*   ... a11 -= R3 * R6 * R2 = R3 * c21 */
	dgemm_("N", "N", &m1, &m1, &m2, &c_b29, &w[w_offset], ldw, &a[m1 + 1 
		+ a_dim1], lda, &c_b14, &a[a_offset], lda, 1L, 1L);
/* --- Nonsymmetric case --- */
    } else {
/*   --- R2 = a21 * R1 in w(2,1) --- */
	dgemm_("N", "N", &m2, &m1, &m1, &c_b14, &a[m1 + 1 + a_dim1], lda, &a[
		a_offset], lda, &c_b15, &w[m1 + 1 + w_dim1], ldw, 1L, 1L);
/*       call ywrm(0,'R2',1,6,fmt,w(1+m1,1),1,ldw,m2,m1) */
/*   --- c21 = R6 * R2 = -c22 a21 a11^-1 --- */
	dgemm_("N", "N", &m2, &m1, &m2, &c_b29, &a[m1 + 1 + (m1 + 1) * a_dim1]
		, lda, &w[m1 + 1 + w_dim1], ldw, &c_b15, &a[m1 + 1 + a_dim1], 
		lda, 1L, 1L);
/*       call ywrm(0,'c21',1,6,fmt,a(1+m1,1),1,lda,m2,m1) */
/*   --- c11 = R1 - R3 * R6 * R2 = a11^-1 - c12 * R2 --- */
	dgemm_("N", "N", &m1, &m1, &m2, &c_b29, &a[(m1 + 1) * a_dim1 + 1], 
		lda, &w[m1 + 1 + w_dim1], ldw, &c_b14, &a[a_offset], lda, 1L, 
		1L);
/*       call ywrm(0,'c11',1,6,fmt,a,1,lda,m1,m1) */
    }
/* #ifdefC DEBUG */
/*      call yprm(.false.,'a^-1',1,6,fmt,ar,lda,n,lda,n) */
/*      print *, 'exiting dqinv',n,m1,m2 */
/* #endif */
    return 0;

L_dqinv0:
    if (*isw > 0) {
	nmin = *nmin0;
    } else {
	*nmin0 = nmin;
    }
} /* dqinv_ */

/* Subroutine */ int dqinv_(cs, a, lda, nlev, n, w, ldw, ierr, cs_len)
char *cs;
doublereal *a;
integer *lda, *nlev, *n;
doublereal *w;
integer *ldw, *ierr;
ftnlen cs_len;
{
    return dqinv_0_(0, cs, a, lda, nlev, n, w, ldw, ierr, (integer *)0, (
	    integer *)0, cs_len);
    }

/* Subroutine */ int dqinv0_(nmin0, isw)
integer *nmin0, *isw;
{
    return dqinv_0_(1, (char *)0, (doublereal *)0, (integer *)0, (integer *)0,
	     (integer *)0, (doublereal *)0, (integer *)0, (integer *)0, nmin0,
	     isw, (ftnint)0);
    }

