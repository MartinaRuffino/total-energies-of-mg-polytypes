/* yyqinv.f -- translated by f2c (version 19970805).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Table of constant values */

static integer c__1 = 1;
static doublereal c_b16 = 1.;
static doublereal c_b17 = 0.;
static doublereal c_b29 = -1.;

/* #define RECUR */
/* #define AIX */
/* #define RECUR */
/* Subroutine */ int yyqinv_0_(n__, cs, ar, ai, lda, nlev, n, w, ldw, ierr, 
	nmin0, isw, cs_len)
int n__;
char *cs;
doublereal *ar, *ai;
integer *lda, *nlev, *n;
doublereal *w;
integer *ldw, *ierr, *nmin0, *isw;
ftnlen cs_len;
{
    /* Initialized data */

    static integer nmin = 32;

    /* System generated locals */
    integer ar_dim1, ar_offset, ai_dim1, ai_offset, w_dim1, w_offset, i__1, 
	    i__2;

    /* Local variables */
    integer i__, j, m1, m2;
    extern /* Subroutine */ int rx_();
    doublereal xx;
    extern /* Subroutine */ int yygefa_(), yyhifa_(), yygedi_(), yyhidi_(), 
	    yygemm_();

/* - Inversion of a complex matrix using Strassen's algorithm */
/* ---------------------------------------------------------------- */
/* i Inputs: */
/* i   cs:   :if 'h', a is assumed hermetian */
/* i   a     :matrix to be inverted */
/* i   lda   :leading dimension of a */
/* i   n     :rank of the matrix to be inverted */
/* i   nlev  :the maximum number of recursion levels allowed. */
/* i          To avoid roundoff errors, nlev=2 is suggested. */
/* i   w     :double precision work array of dimension ldw*(n+1) */
/* i   ldw   :leading dimension of w */
/* o Outputs: */
/* o   a     :is overwritten by inverse of input a */
/* o   ierr  :returned nonzero if matrix was not fully inverted. */
/* b Bugs */
/* b   The algorithm fails if a22 is singular, even if a is not. */
/* b   Similarly, if smaller subblocks are singular, yyqinv may fail */
/* b   when called recursively. */
/* r Remarks: */
/* r   See Numerical Recipes, 2.11. */
/* r   It is more efficient to allow inversion to proceed recursively, */
/* r   if your compiler allows it.  Recursion proceeds provided nlev>0 */
/* r   and the dimension of the matrix to be inverted exceeds nmin. */
/* r   The latter should be chosen where the tradoff between */
/* r   the extra overhead and fewer O(N^3) operations takes place. */
/* r   The AIX xlf90 compiler overwrites locally declared variables, */
/* r   (NB: compile using -qrecur).  Compiling with AIX code uncommented 
*/
/* r   restores necessary variables after a recursive call. */
/* r   (For debugging:) */
/* r   mc -f4f16.10 a -split a 1,3,5 1,3,5  a11 -i -a r1  a21 r1 -x -a r2\
 */
/* r   r2 a12 -x -a r4  r4 a22 -- -a r5  r5 -i -a r6  r1 a12 -x -a r3\ */
/* r   r3 r6 -x -a c12  r6 r2 -x -a c21  r3 c21 -x -a r7 r1 r7 -- -a c11\ 
*/
/* r   r6 -s-1 -a c22 c11 c12 -ccat c21 c22 -ccat -rcat */
/* r   Alternative, starting with a22 */
/* r   mc -f4f16.10 a -split a 1,3,5 1,3,5  a22 -i -a r1  a12 r1 -x -a r2\
 */
/* r   r2 a21 -x -a r4  r4 a11 -- -a r5  r5 -i -a r6  r1 a21 -x -a r3\ */
/* r   r3 r6 -x -a c21  r6 r2 -x -a c12  r3 c12 -x -a r7 r1 r7 -- -a c22 
*/
/* r   r6 -s-1 -a c11 c11 c12 -ccat c21 c22 -ccat -rcat */
/* r */
/* r   See yqinv for an equivalent version where real and imaginary */
/* r   parts are linked by an an offset. */
/* ---------------------------------------------------------------- */
/* #ifdefC DEBUG */
/*      character*10 fmt */
/*      data fmt /'(8f16.10)'/ */
/* #endif */
    /* Parameter adjustments */
    if (ar) {
	ar_dim1 = *lda;
	ar_offset = ar_dim1 + 1;
	ar -= ar_offset;
	}
    if (ai) {
	ai_dim1 = *lda;
	ai_offset = ai_dim1 + 1;
	ai -= ai_offset;
	}
    if (w) {
	w_dim1 = *ldw;
	w_offset = w_dim1 + 1;
	w -= w_offset;
	}

    /* Function Body */
    switch(n__) {
	case 1: goto L_yqinv0;
	}

/* #ifdefC DEBUG */
/*      print 334, 'entering yyqinv: cs=',cs,nlev,n */
/*  334 format(1x,a,a,': nlev=',i1,'  n=',i4) */
/* #endif */
    m1 = *n / 2;
    m2 = *n - m1;
/*     call tcn('yyqinv') */
/* --- Straight yygefa,di if n lt nmin --- */
    if (*n <= nmin) {
	if (*(unsigned char *)cs != 'h' || *n == 1) {
	    yygefa_(&ar[ar_offset], &ai[ai_offset], lda, n, &w[w_offset], 
		    ierr);
	    if (*ierr != 0) {
		goto L99;
	    }
	    if (*n == 1) {
		yygedi_(&ar[ar_offset], &ai[ai_offset], lda, n, &w[w_offset], 
			&xx, &w[(w_dim1 << 1) + 1], &xx, &c__1);
	    } else {
		yygedi_(&ar[ar_offset], &ai[ai_offset], lda, n, &w[w_offset], 
			&xx, &w[(w_dim1 << 1) + 1], &w[w_dim1 * 3 + 1], &c__1)
			;
	    }
	} else {
	    yyhifa_(&ar[ar_offset], &ai[ai_offset], lda, n, &w[w_offset], 
		    ierr);
	    if (*ierr != 0) {
		goto L99;
	    }
	    yyhidi_(&ar[ar_offset], &ai[ai_offset], lda, n, &w[w_offset], &xx,
		     &i__, &w[(w_dim1 << 1) + 1], &w[w_dim1 * 3 + 1], &c__1);
	    i__1 = *n;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		i__2 = i__;
		for (j = 1; j <= i__2; ++j) {
		    ar[i__ + j * ar_dim1] = ar[j + i__ * ar_dim1];
/* L10: */
		    ai[i__ + j * ai_dim1] = -ai[j + i__ * ai_dim1];
		}
	    }
	}
/* #ifdefC DEBUG */
/*        print *, 'exit yyqinv, LU decomposition' */
/* #endif */
	goto L99;
    }
    if (*lda < *n) {
	rx_("yyqinv: lda lt n", 16L);
    }
    if (*ldw < *n) {
	rx_("yyqinv: ldw lt n", 16L);
    }
/* --- R1 = a11^-1 in a11 --- */
/* #ifdef RECUR */
    if (m1 < nmin || *nlev == 0) {
/* #endif */
	if (*(unsigned char *)cs == 'h') {
	    yyhifa_(&ar[ar_offset], &ai[ai_offset], lda, &m1, &w[w_offset], 
		    ierr);
	    if (*ierr != 0) {
		goto L99;
	    }
	    yyhidi_(&ar[ar_offset], &ai[ai_offset], lda, &m1, &w[w_offset], &
		    xx, &i__, &w[(w_dim1 << 1) + 1], &w[w_dim1 * 3 + 1], &
		    c__1);
	    i__2 = m1;
	    for (i__ = 1; i__ <= i__2; ++i__) {
		i__1 = i__;
		for (j = 1; j <= i__1; ++j) {
		    ar[i__ + j * ar_dim1] = ar[j + i__ * ar_dim1];
/* L12: */
		    ai[i__ + j * ai_dim1] = -ai[j + i__ * ai_dim1];
		}
	    }
	} else {
	    yygefa_(&ar[ar_offset], &ai[ai_offset], lda, &m1, &w[w_offset], 
		    ierr);
	    if (*ierr != 0) {
		goto L99;
	    }
	    yygedi_(&ar[ar_offset], &ai[ai_offset], lda, &m1, &w[w_offset], &
		    xx, &w[(w_dim1 << 1) + 1], &w[w_dim1 * 3 + 1], &c__1);
	}
/* #ifdef RECUR */
    } else {
/* #ifdefC DEBUG */
/*        print *, 'recursive call to yyqinv n,m1,m2=',n,m1,m2 */
/* #endif */
/* #ifdef AIX | SUN-ULTRA */
	i__1 = *nlev - 1;
	i__2 = m1;
	yyqinv_(cs, &ar[ar_offset], &ai[ai_offset], lda, &i__1, &i__2, &w[
		w_offset], ldw, ierr, 1L);
	m1 = *n / 2;
	m2 = *n - m1;
/* #elseC */
/*        call yyqinv(cs,ar,ai,lda,nlev-1,m1,w,ldw,ierr) */
/* #endif */
/* #ifdefC DEBUG */
/*        print 333, 'recursive call exit',nlev,n,m1,m2 */
/* #endif */
	if (*ierr != 0) {
	    goto L99;
	}
    }
/* #endif */
/*     call yprm(.false.,'R1',2,6,fmt,ar,lda,m1,lda,m1) */
/* --- R3 = R1 a12 in w: uses w(1:m1,1:2*m2) --- */
    yygemm_("N", "N", &m1, &m2, &m1, &c_b16, &ar[ar_offset], &ai[ai_offset], 
	    lda, &ar[(m1 + 1) * ar_dim1 + 1], &ai[(m1 + 1) * ai_dim1 + 1], 
	    lda, &c_b17, &w[w_offset], &w[(m2 + 1) * w_dim1 + 1], ldw, 1L, 1L)
	    ;
/*     call yprm(.false.,'R3',2,6,fmt,w,lda,m1,m2,m2) */
/* --- R4 = a21 R3 = a21 a11^-1 a12 in w2; uses w(1+m1:n,1:2*m2) --- */
    yygemm_("N", "N", &m2, &m2, &m1, &c_b16, &ar[m1 + 1 + ar_dim1], &ai[m1 + 
	    1 + ai_dim1], lda, &w[w_offset], &w[(m2 + 1) * w_dim1 + 1], ldw, &
	    c_b17, &w[m1 + 1 + w_dim1], &w[m1 + 1 + (m2 + 1) * w_dim1], ldw, 
	    1L, 1L);
/*     call yprm(.false.,'R4',2,6,fmt,w(1+m1,1),ldw,m2,m2,m2) */
/* --- -R5 = a22 - R4 = a22 - a21 a11^-1 a12 in a22 --- */
    i__1 = m2;
    for (j = 1; j <= i__1; ++j) {
	i__2 = m2;
	for (i__ = 1; i__ <= i__2; ++i__) {
	    ar[i__ + m1 + (j + m1) * ar_dim1] -= w[i__ + m1 + j * w_dim1];
/* L20: */
	    ai[i__ + m1 + (j + m1) * ai_dim1] -= w[i__ + m1 + (j + m2) * 
		    w_dim1];
	}
    }
/*     R4 = w2 isn't needed beyond this point */
/*     call yprm(.false.,'-R5',2,6,fmt,ar(1+m1,1+m1),lda,m2,lda,m2) */
/* --- c22 = -R6 = -R5^-1 = (a22 - a21 a11^-1 a12)^-1 in a22 --- */
/* #ifdef RECUR */
    if (m2 < nmin || *nlev == 0) {
/* #endif RECUR */
	if (*(unsigned char *)cs == 'h') {
	    yyhifa_(&ar[m1 + 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (m1 + 1) * 
		    ai_dim1], lda, &m2, &w[m1 + 1 + w_dim1], ierr);
	    if (*ierr != 0) {
		goto L99;
	    }
	    yyhidi_(&ar[m1 + 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (m1 + 1) * 
		    ai_dim1], lda, &m2, &w[m1 + 1 + w_dim1], &xx, &i__, &w[m1 
		    + 1 + (w_dim1 << 1)], &w[m1 + 1 + w_dim1 * 3], &c__1);
	    i__2 = *n;
	    for (i__ = m1 + 1; i__ <= i__2; ++i__) {
		i__1 = i__;
		for (j = m1 + 1; j <= i__1; ++j) {
		    ar[i__ + j * ar_dim1] = ar[j + i__ * ar_dim1];
/* L16: */
		    ai[i__ + j * ai_dim1] = -ai[j + i__ * ai_dim1];
		}
	    }
	} else {
	    yygefa_(&ar[m1 + 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (m1 + 1) * 
		    ai_dim1], lda, &m2, &w[m1 + 1 + w_dim1], ierr);
	    if (*ierr != 0) {
		goto L99;
	    }
	    yygedi_(&ar[m1 + 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (m1 + 1) * 
		    ai_dim1], lda, &m2, &w[m1 + 1 + w_dim1], &xx, &w[m1 + 1 + 
		    (w_dim1 << 1)], &w[m1 + 1 + w_dim1 * 3], &c__1);
	}
/* #ifdef RECUR */
    } else {
/* #ifdefC DEBUG */
/*        print *, 'recursive call to yyqinv n,m1,m2=',n,m1,m2 */
/* #endif */
/* #ifdef AIX | SUN-ULTRA */
	i__1 = *nlev - 1;
	i__2 = m2;
	yyqinv_(cs, &ar[m1 + 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (m1 + 1) * 
		ai_dim1], lda, &i__1, &i__2, &w[m1 + 1 + w_dim1], ldw, ierr, 
		1L);
	m1 = *n / 2;
	m2 = *n - m1;
/* #elseC */
/*        call yyqinv(cs,ar(1+m1,1+m1),ai(1+m1,1+m1),lda, */
/*     .    nlev-1,m2,w(1+m1,1),ldw,ierr) */
/* #endif */
/* #ifdefC DEBUG */
/*        print 333, 'recursive call exit',nlev,n,m1,m2 */
/* #endif */
	if (*ierr != 0) {
	    goto L99;
	}
    }
/* #endif RECUR */
/*     call yprm(.false.,'-R6',2,6,fmt,ar(1+m1,1+m1),lda,m2,lda,m2) */
/* --- c12 = R3 * R6 = -a11^-1 a12 c22 in a12 --- */
    yygemm_("N", "N", &m1, &m2, &m2, &c_b29, &w[w_offset], &w[(m2 + 1) * 
	    w_dim1 + 1], ldw, &ar[m1 + 1 + (m1 + 1) * ar_dim1], &ai[m1 + 1 + (
	    m1 + 1) * ai_dim1], lda, &c_b17, &ar[(m1 + 1) * ar_dim1 + 1], &ai[
	    (m1 + 1) * ai_dim1 + 1], lda, 1L, 1L);
/*     call yprm(.false.,'c12',2,6,fmt,ar(1,1+m1),lda,m1,lda,m2) */
/* --- Hermetian case: R2 = R3+ and c21=c12+ --- */
    if (*(unsigned char *)cs == 'h') {
	i__1 = m1;
	for (j = 1; j <= i__1; ++j) {
	    i__2 = m2;
	    for (i__ = 1; i__ <= i__2; ++i__) {
		ar[i__ + m1 + j * ar_dim1] = ar[j + (i__ + m1) * ar_dim1];
/* L30: */
		ai[i__ + m1 + j * ai_dim1] = -ai[j + (i__ + m1) * ai_dim1];
	    }
	}
/* NB: do following in two steps to avoid beta=1 in yygemm call */
/*   ... R7 = R3 * R6 * R2 = R3 * c21 */
	yygemm_("N", "N", &m1, &m1, &m2, &c_b16, &w[w_offset], &w[(m2 + 1) * 
		w_dim1 + 1], ldw, &ar[m1 + 1 + ar_dim1], &ai[m1 + 1 + ai_dim1]
		, lda, &c_b17, &w[m1 + 1 + w_dim1], &w[m1 + 1 + (m2 + 1) * 
		w_dim1], ldw, 1L, 1L);
/*   ... c11 = R1 - R7 = R1 - R3 * R6 * R2 = R1 - R3 * c21 */
	i__2 = m1;
	for (j = 1; j <= i__2; ++j) {
	    i__1 = j;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		ar[i__ + j * ar_dim1] -= (w[i__ + m1 + j * w_dim1] + w[j + m1 
			+ i__ * w_dim1]) * .5;
/* L32: */
		ai[i__ + j * ai_dim1] -= (w[i__ + m1 + (j + m2) * w_dim1] - w[
			j + m1 + (i__ + m2) * w_dim1]) * .5;
	    }
	}
/*       call yygemm('N','N',m1,m1,m2,-1d0,w,w(1,1+m2),ldw, */
/*    .    ar(1+m1,1),ai(1+m1,1),lda,1d0,ar,ai,lda) */
/*   ... Force hermetian explicitly */
	i__1 = m1;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    i__2 = i__;
	    for (j = 1; j <= i__2; ++j) {
		ar[i__ + j * ar_dim1] = ar[j + i__ * ar_dim1];
/* L34: */
		ai[i__ + j * ai_dim1] = -ai[j + i__ * ai_dim1];
	    }
	}
/* --- Nonhermetian case --- */
    } else {
/*   --- R2 = a21 * R1 in w(2); uses w(1+m1:n,1:2*m1) --- */
	yygemm_("N", "N", &m2, &m1, &m1, &c_b16, &ar[m1 + 1 + ar_dim1], &ai[
		m1 + 1 + ai_dim1], lda, &ar[ar_offset], &ai[ai_offset], lda, &
		c_b17, &w[m1 + 1 + w_dim1], &w[m1 + 1 + (m1 + 1) * w_dim1], 
		ldw, 1L, 1L);
/*       call yprm(.false.,'R2',2,6,fmt,w(1+m1,1),ldw,m2,m2,m1) */
/*   --- c21 = R6 * R2 = -c22 a21 a11^-1 --- */
	yygemm_("N", "N", &m2, &m1, &m2, &c_b29, &ar[m1 + 1 + (m1 + 1) * 
		ar_dim1], &ai[m1 + 1 + (m1 + 1) * ai_dim1], lda, &w[m1 + 1 + 
		w_dim1], &w[m1 + 1 + (m1 + 1) * w_dim1], ldw, &c_b17, &ar[m1 
		+ 1 + ar_dim1], &ai[m1 + 1 + ai_dim1], lda, 1L, 1L);
/*       call yprm(.false.,'c21',2,6,fmt,ar(1+m1,1),lda,m2,lda,m1) */
/*   --- c11 = R1 - R3 * R6 * R2 = a11^-1 + a11^-1 a12 c22 a21 a11^-1 
--- */
	yygemm_("N", "N", &m1, &m1, &m2, &c_b29, &ar[(m1 + 1) * ar_dim1 + 1], 
		&ai[(m1 + 1) * ai_dim1 + 1], lda, &w[m1 + 1 + w_dim1], &w[m1 
		+ 1 + (m1 + 1) * w_dim1], ldw, &c_b16, &ar[ar_offset], &ai[
		ai_offset], lda, 1L, 1L);
/*       call yprm(.false.,'R7',2,6,fmt,w,ldw,m1,m2,m1) */
    }
/* #ifdefC DEBUG */
/* C     call yprm(.false.,'a^-1',2,6,fmt,ar,lda,n,lda,n) */
/*      print 333, 'exiting  yyqinv',nlev,n,m1,m2 */
/*  333 format(1x,a,': nlev=',i1,'  ndim=',i3,' partitioned into',2i3) */
/* #endif */
L99:
/*     call tcx('yyqinv') */
    return 0;
/* #ifdefC DEBUG */
/*      call yprm(.false.,'a^-1',2,6,fmt,ar,lda,n,lda,n) */
/* #endif */

L_yqinv0:
    if (*isw > 0) {
	nmin = *nmin0;
    } else {
	*nmin0 = nmin;
    }
} /* yyqinv_ */

/* Subroutine */ int yyqinv_(cs, ar, ai, lda, nlev, n, w, ldw, ierr, cs_len)
char *cs;
doublereal *ar, *ai;
integer *lda, *nlev, *n;
doublereal *w;
integer *ldw, *ierr;
ftnlen cs_len;
{
    return yyqinv_0_(0, cs, ar, ai, lda, nlev, n, w, ldw, ierr, (integer *)0, 
	    (integer *)0, cs_len);
    }

/* Subroutine */ int yqinv0_(nmin0, isw)
integer *nmin0, *isw;
{
    return yyqinv_0_(1, (char *)0, (doublereal *)0, (doublereal *)0, (integer 
	    *)0, (integer *)0, (integer *)0, (doublereal *)0, (integer *)0, (
	    integer *)0, nmin0, isw, (ftnint)0);
    }

