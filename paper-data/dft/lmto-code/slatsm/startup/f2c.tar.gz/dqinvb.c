/* dqinvb.f -- translated by f2c (version 19970805).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Table of constant values */

static integer c__0 = 0;
static integer c__1 = 1;
static doublereal c_b30 = 1.;
static doublereal c_b31 = 0.;
static doublereal c_b43 = -1.;

/* #define RECUR */
/* #define AIX */
/* #define RECUR */
/* Subroutine */ int dqinvb_0_(n__, cs, a, lda, nlev, n, nb, w, ldw, w2, b, 
	ldb, ierr, nmin0, isw, cs_len)
int n__;
char *cs;
doublereal *a;
integer *lda, *nlev, *n, *nb;
doublereal *w;
integer *ldw;
doublereal *w2, *b;
integer *ldb, *ierr, *nmin0, *isw;
ftnlen cs_len;
{
    /* Initialized data */

    static integer nmin = 32;

    /* System generated locals */
    integer a_dim1, a_offset, b_dim1, b_offset, w_dim1, w_offset, i__1, i__2;

    /* Builtin functions */
    integer i_len(), s_cmp();

    /* Local variables */
    extern /* Subroutine */ int dgefa_();
    integer i__, j;
    extern /* Subroutine */ int dsifa_(), dgemm_(), dgesl_(), dsisl_(), 
	    dqinv_(), dsmpy_();
    integer m1, m2;
    logical ltrns;
    integer jr;
    extern /* Subroutine */ int rx_();
    doublereal ww[2];
    logical lrecur;
    char css[1];
    logical lsx;
    extern /* Subroutine */ int rxs_();

/* - Solution of a x = b by vectorizable multiplications and inversions */
/* ---------------------------------------------------------------- */
/* i Inputs: */
/* i   cs:   : a string containing any of the following characters. */
/* i          't'  solve b = x a instead of a x = b */
/* i          's'  a is assumed symmetric. */
/* i          'b'  Assume partial inverse for a is already performed. */
/* i               ar,ai must be preserved between successive calls. */
/* i   a,lda :First matrix in eqation a x = b, and leading dimension */
/* i   nlev  :the maximum number of recursion levels allowed. */
/* i          To avoid roundoff errors, nlev=2 is suggested. */
/* i   n     :solve a x = b for matrix a(1:n,1:n) */
/* i   w,ldw :a double precision work array of dimension ldw*n: */
/* i   w2    :a double precision work array of dimension nb*(n+1) */
/* i          w and w2 may use the same address space */
/* i   b,ldb :the rhs, and its leading dimension */
/* i   nb    :the number of columns (rows, if cs contains 't') in x and b 
*/
/* o Outputs: */
/* o   a     :is OVERWRITTEN, into a partially decomposed form */
/* o   ierr  :is returned nonzero if matrix was not successfully inverted 
*/
/* o   a^-1 b (b a^-1) is returned in b(1..n,1..nb) (b(1..nb,1..n)) */
/* r Remarks */
/* r   dqinvb uses a block decomposition to solve the linear system */
/* r   a x = b.  a is partitioned into subblocks a11,a21,a12,a22 and */
/* r   b is similarly partioned into b1,b2.  Let c be the inverse, */
/* r   with subblocks c11,c21,c12,c22.  Solution proceeds by: */
/* r     (1) invert   a22 -> a22^-1 */
/* r     (2) multiply a12 a22^-1 */
/* r     (3) multiply to obtain c11^-1 = (a11 - a12 a22^-1 a21) */
/* r     ... At this point there are two options.  Standard option: */
/* r     (4) invert   c11^-1 -> c11 = (a11 - a12 a22^-1 a21)^-1 */
/* r     (5) multiply to obtain x1 = c11 (b1 - (a12 a22^-1) b2) */
/* r     (6) multiply to obtain x2 = a22^-1 (b2 - a21 x1) */
/* r     ... the recursive option omits explicit inversion for c11: */
/* r     (4) multiply to obtain (b1 - a12 a22^-1 b2) */
/* r     (5) solve    c11^-1 x1 = (b1 - a12 a22^-1 b2) calling dqinvb */
/* r     (6) multiply to obtain x2 = a22^-1 (b2 - a21 x1) */
/* r */
/* r   If the decomposition has already been effected, x may be calculated
 */
/* r   for new vectors b without decomposing the matrix again (cs='b') */
/* r   Debugging: */
/* r   mc a -split a 1,4,6 1,4,6 a22 -i a12 -tog -x a21 -x -s-1 a11 -+ -i 
*/
/* r   -a P11 b -split b 1,4,6 1,6 a12 a22 -i -x b21 -x -s-1 b11 -+ */
/* r   P11 -tog -x -a x1 a21 x1 -x -s-1 b21 -+ a22 -i -tog -x -a x2 */
/* r   x1 x2 -rcat a -i b -x -- */
/* r */
/* r   Alternative, swapping indices 1 and 2 */
/* r   mc a -split a 1,4,nr+1 1,4,nr+1 a21 a11 -i -x a12 -x -s-1 a22 -+ -i
 */
/* r   -a P22 b -split b 1,4,nr+1 1,nc+1 a21 a11 -i -x b11 -x -s-1 b21 -+ 
*/
/* r   P22 -tog -x -a x2 a12 x2 -x -s-1 b11 -+ a11 -i -tog -x x2 -rcat */
/* r   a -i b -x -- -px */
/* r */
/* r   For the transpose case: */
/* r   mc a -split a 1,4,6 1,4,6 a22 -i a12 -tog -x a21 -x -s-1 a11 -+ -i 
*/
/* r   -a P11 b -split b 1,5 1,4,6 a22 -i a21 -x b12 -tog -x -s-1 b11 -+ 
*/
/* r   P11 -x -a x1 x1 a12 -x -s-1 b12 -+ a22 -i -x -a x2 x1 x2 -ccat */
/* r   b a -i -x -- */
/* b Bugs */
/* b   dqinvb fails if a22 is singular, even if a is not. */
/* b   Similarly, dqinv may fail to invert a22 even if it is not singular.
 */
/* ---------------------------------------------------------------- */
/* Local variables */
/*     parameter(nmin=70) */
    /* Parameter adjustments */
    if (a) {
	a_dim1 = *lda;
	a_offset = a_dim1 + 1;
	a -= a_offset;
	}
    if (w2) {
	--w2;
	}
    if (w) {
	w_dim1 = *ldw;
	w_offset = w_dim1 + 1;
	w -= w_offset;
	}
    if (b) {
	b_dim1 = *ldb;
	b_offset = b_dim1 + 1;
	b -= b_offset;
	}

    /* Function Body */
    switch(n__) {
	case 1: goto L_dqnvb0;
	}

/* #ifdefC DEBUG */
/* c     character*10 fmt */
/* C     data fmt /'(8f16.10)'/ */
/* C     call ywrm(0,'a',1,6,fmt,a,1,lda,n,n) */
/*      print 334, 'entering dqinvb',cs,nlev,n,(n+1)/2,n-(n+1)/2 */
/*  334 format(1x,a,': cs=',a,': nlev=',i1, */
/*     .       '  n=',i3,'  m1=',i3,'  m2=',i3) */
/* #endif */
    *ierr = 0;
    ltrns = FALSE_;
    lrecur = FALSE_;
    lsx = FALSE_;
    *(unsigned char *)css = ' ';
    j = i_len(cs, cs_len);
    i__1 = j;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (*(unsigned char *)&cs[i__ - 1] == 't') {
	    ltrns = TRUE_;
	} else if (*(unsigned char *)&cs[i__ - 1] == 'b') {
	    lsx = TRUE_;
	} else if (*(unsigned char *)&cs[i__ - 1] == 's') {
	    *(unsigned char *)css = 's';
	} else if (*(unsigned char *)&cs[i__ - 1] == 'r') {
	    lrecur = TRUE_;
	} else if (*(unsigned char *)&cs[i__ - 1] != ' ') {
	    rxs_("dqinvb: bad input cs", cs, 20L, cs_len);
	}
/* L2: */
    }
/* #ifndefC RECUR */
/*      lrecur = .false. */
/* #endif */
/* --- For n<nmin, do directly by dgefa,dgesl --- */
    if (*n < nmin) {
	if (! lsx) {
	    if (*(unsigned char *)css == 's') {
		dsifa_(&a[a_offset], lda, n, &w[w_offset], ierr);
	    }
	    if (*(unsigned char *)css != 's') {
		dgefa_(&a[a_offset], lda, n, &w[w_offset], ierr);
	    }
	    if (*ierr != 0) {
		return 0;
	    }
	}
	i__1 = *nb;
	for (j = 1; j <= i__1; ++j) {
	    if (! ltrns && *(unsigned char *)css == 's') {
		dsisl_(&a[a_offset], lda, n, &w[w_offset], &b[j * b_dim1 + 1])
			;
	    } else if (! ltrns && *(unsigned char *)css != 's') {
		dgesl_(&a[a_offset], lda, n, &w[w_offset], &b[j * b_dim1 + 1],
			 &c__0);
	    } else {
/*       ... Do for special case n<=2: w may not be large enou
gh! */
		if (*n <= 2) {
		    i__2 = *n;
		    for (i__ = 1; i__ <= i__2; ++i__) {
			ww[i__ - 1] = b[j + i__ * b_dim1];
			if (*(unsigned char *)css == 's') {
			    dsisl_(&a[a_offset], lda, n, &w[w_offset], ww);
			}
			if (*(unsigned char *)css != 's') {
			    dgesl_(&a[a_offset], lda, n, &w[w_offset], ww, &
				    c__1);
			}
/* L116: */
		    }
		    i__2 = *n;
		    for (i__ = 1; i__ <= i__2; ++i__) {
/* L118: */
			b[j + i__ * b_dim1] = ww[i__ - 1];
		    }
		} else {
		    i__2 = *n;
		    for (i__ = 1; i__ <= i__2; ++i__) {
/* L16: */
			w[i__ + (w_dim1 << 1)] = b[j + i__ * b_dim1];
		    }
		    if (*(unsigned char *)css == 's') {
			dsisl_(&a[a_offset], lda, n, &w[w_offset], &w[(w_dim1 
				<< 1) + 1]);
		    }
		    if (*(unsigned char *)css != 's') {
			dgesl_(&a[a_offset], lda, n, &w[w_offset], &w[(w_dim1 
				<< 1) + 1], &c__1);
		    }
		    i__2 = *n;
		    for (i__ = 1; i__ <= i__2; ++i__) {
/* L18: */
			b[j + i__ * b_dim1] = w[i__ + (w_dim1 << 1)];
		    }
		}
	    }
/* L12: */
	}
	return 0;
    }
    if (*ldw < *n) {
	rx_("dqinvb: ldw lt n", 16L);
    }
    m1 = (*n + 1) / 2;
    m2 = *n - m1;
/* --- Decompose matrix --- */
    if (! lsx) {
/* --- a22^-1 in a22 --- */
/* Computing MAX */
	i__2 = *nlev - 1;
	i__1 = max(i__2,0);
	dqinv_(css, &a[m1 + 1 + (m1 + 1) * a_dim1], lda, &i__1, &m2, &w[
		w_offset], ldw, ierr, 1L);
/*     call ywrm(0,'a22^-1',1,6,fmt,a(1+m1,1+m1),1,lda,m2,m2) */
	if (*ierr != 0) {
	    return 0;
	}
	if (! ltrns) {
/*   --- a12 a22^-1 in w; copy back to a12 --- */
	    dgemm_("N", "N", &m1, &m2, &m2, &c_b30, &a[(m1 + 1) * a_dim1 + 1],
		     lda, &a[m1 + 1 + (m1 + 1) * a_dim1], lda, &c_b31, &w[
		    w_offset], ldw, 1L, 1L);
	    i__1 = m2;
	    for (j = 1; j <= i__1; ++j) {
		i__2 = m1;
		for (i__ = 1; i__ <= i__2; ++i__) {
/* L20: */
		    a[i__ + (j + m1) * a_dim1] = w[i__ + j * w_dim1];
		}
	    }
	} else {
/*   --- a22^-1 a21 in w; copy back to a21 --- */
	    dgemm_("N", "N", &m2, &m1, &m2, &c_b30, &a[m1 + 1 + (m1 + 1) * 
		    a_dim1], lda, &a[m1 + 1 + a_dim1], lda, &c_b31, &w[
		    w_offset], ldw, 1L, 1L);
	    i__2 = m1;
	    for (j = 1; j <= i__2; ++j) {
		i__1 = m2;
		for (i__ = 1; i__ <= i__1; ++i__) {
/* L22: */
		    a[i__ + m1 + j * a_dim1] = w[i__ + j * w_dim1];
		}
	    }
	}
/* --- c11^-1 = (a11 - a12 a22^-1 a21) in a11 --- */
	if (s_cmp(cs, "s", cs_len, 1L) == 0) {
	    dsmpy_(&m1, &m2, &a[(m1 + 1) * a_dim1 + 1], lda, &a[m1 + 1 + 
		    a_dim1], lda, &c_b31, &w[w_offset], ldw);
	    i__1 = m1;
	    for (j = 1; j <= i__1; ++j) {
		i__2 = m1;
		for (i__ = 1; i__ <= i__2; ++i__) {
/* L24: */
		    a[i__ + j * a_dim1] -= w[i__ + j * w_dim1];
		}
	    }
	} else {
	    dgemm_("N", "N", &m1, &m1, &m2, &c_b43, &a[(m1 + 1) * a_dim1 + 1],
		     lda, &a[m1 + 1 + a_dim1], lda, &c_b30, &a[a_offset], lda,
		     1L, 1L);
	}
/* --- c11 = (a11 - a12 a22^-1 a21)^-1 in a11 --- */
	if (! (lrecur && *nlev > 0 && m1 >= nmin)) {
/* Computing MAX */
	    i__1 = *nlev - 1;
	    i__2 = max(i__1,0);
	    dqinv_(css, &a[a_offset], lda, &i__2, &m1, &w[w_offset], ldw, 
		    ierr, 1L);
	}
	if (*ierr != 0) {
	    return 0;
	}
/*     call yprm(.false.,'c11',1,6,fmt,a,lda,m1,lda,m1) */
    }
/* ... End of matrix decomposition */
    if (*nb == 0) {
	return 0;
    }
    if (! ltrns) {
/* --- Obtain x1 = c11 (b1 - a12 a22^-1 b2) --- */
	if (lrecur && *nlev > 0 && m1 >= nmin) {
/* #ifdef RECUR */
/*   ... (b1 - a12 a22^-1 b2) */
	    dgemm_("N", "N", &m1, nb, &m2, &c_b43, &a[(m1 + 1) * a_dim1 + 1], 
		    lda, &b[m1 + 1 + b_dim1], ldb, &c_b30, &b[b_offset], ldb, 
		    1L, 1L);
/*   ... Solve c11^-1 x1 - (b1 - a12 a22^-1 b2) */
	    i__2 = *nlev - 1;
	    i__1 = m1;
	    dqinvb_(cs, &a[a_offset], lda, &i__2, &i__1, nb, &w[w_offset], 
		    ldw, &w2[1], &b[b_offset], ldb, ierr, cs_len);
/*       AIX and gcc require this */
	    m1 = (*n + 1) / 2;
	    m2 = *n - m1;
/* #endif */
/* #ifdefC DEBUG */
/* C       print 333, 'recursive call exit',nlev,n,m1,m2 */
/* #endif */
	} else {
/*   ... w2 <- b1 - a12 a22^-1 b2 */
	    dgemm_("N", "N", &m1, nb, &m2, &c_b30, &a[(m1 + 1) * a_dim1 + 1], 
		    lda, &b[m1 + 1 + b_dim1], ldb, &c_b31, &w2[1], &m1, 1L, 
		    1L);
	    jr = -m1;
	    i__2 = *nb;
	    for (j = 1; j <= i__2; ++j) {
		jr += m1;
		i__1 = m1;
		for (i__ = 1; i__ <= i__1; ++i__) {
/* L32: */
		    w2[i__ + jr] = b[i__ + j * b_dim1] - w2[i__ + jr];
		}
/* L30: */
	    }
/*       call yprm(.false.,'b1 - a12 a22^-1 b2',1,6,fmt,w2,m1,m1,n
b,nb) */
/*   ... x1 = c11 (b1 - a12 a22^-1 b2) */
	    dgemm_("N", "N", &m1, nb, &m1, &c_b30, &a[a_offset], lda, &w2[1], 
		    &m1, &c_b31, &b[b_offset], ldb, 1L, 1L);
	}
/* --- w2 <- b2 - a21 x1 --- */
	dgemm_("N", "N", &m2, nb, &m1, &c_b30, &a[m1 + 1 + a_dim1], lda, &b[
		b_offset], ldb, &c_b31, &w2[1], &m2, 1L, 1L);
	jr = -m2;
	i__2 = *nb;
	for (j = 1; j <= i__2; ++j) {
	    jr += m2;
	    i__1 = m2;
	    for (i__ = 1; i__ <= i__1; ++i__) {
/* L42: */
		w2[i__ + jr] = b[i__ + m1 + j * b_dim1] - w2[i__ + jr];
	    }
/* L40: */
	}
/* --- x2 = a22^-1 (b2 - a21 x1) --- */
	dgemm_("N", "N", &m2, nb, &m2, &c_b30, &a[m1 + 1 + (m1 + 1) * a_dim1],
		 lda, &w2[1], &m2, &c_b31, &b[m1 + 1 + b_dim1], ldb, 1L, 1L);
/*     call yprm(.false.,'a^-1 b',1,6,fmt,br,ldb,n,ldb,nb) */
    } else {
/* --- Obtain x1 = (b1 - b2 a22^-1 a21) c11 --- */
	if (lrecur && *nlev > 0 && m1 >= nmin) {
/* #ifdef RECUR */
/*   ... (b1 - a12 a22^-1 b2) */
	    dgemm_("N", "N", nb, &m1, &m2, &c_b43, &b[(m1 + 1) * b_dim1 + 1], 
		    ldb, &a[m1 + 1 + a_dim1], lda, &c_b30, &b[b_offset], ldb, 
		    1L, 1L);
/*   ... solve x1 c11^-1 = (b1 - b2 a22^-1 a21) */
	    i__2 = *nlev - 1;
	    i__1 = m1;
	    dqinvb_(cs, &a[a_offset], lda, &i__2, &i__1, nb, &w[w_offset], 
		    ldw, &w2[1], &b[b_offset], ldb, ierr, cs_len);
/*       AIX and gcc require the next two lines */
	    m1 = (*n + 1) / 2;
	    m2 = *n - m1;
/* #endif */
	} else {
/* ... w2 <- b1 - b2 a22^-1 a21 */
	    dgemm_("N", "N", nb, &m1, &m2, &c_b30, &b[(m1 + 1) * b_dim1 + 1], 
		    ldb, &a[m1 + 1 + a_dim1], lda, &c_b31, &w2[1], nb, 1L, 1L)
		    ;
	    jr = -(*nb);
	    i__2 = m1;
	    for (j = 1; j <= i__2; ++j) {
		jr += *nb;
		i__1 = *nb;
		for (i__ = 1; i__ <= i__1; ++i__) {
/* L132: */
		    w2[i__ + jr] = b[i__ + j * b_dim1] - w2[i__ + jr];
		}
/* L130: */
	    }
/* ... x1 = (b1 - b2 a22^-1 a21) c11 */
	    dgemm_("N", "N", nb, &m1, &m1, &c_b30, &w2[1], nb, &a[a_offset], 
		    lda, &c_b31, &b[b_offset], ldb, 1L, 1L);
/*     call yprm(.false.,'x1',1,6,fmt,br,ldb,nb,ldb,m1) */
	}
/* --- w2 <- b2 - x1 a12 --- */
	dgemm_("N", "N", nb, &m2, &m1, &c_b30, &b[b_offset], ldb, &a[(m1 + 1) 
		* a_dim1 + 1], lda, &c_b31, &w2[1], nb, 1L, 1L);
	jr = -(*nb);
	i__2 = m2;
	for (j = 1; j <= i__2; ++j) {
	    jr += *nb;
	    i__1 = *nb;
	    for (i__ = 1; i__ <= i__1; ++i__) {
/* L142: */
		w2[i__ + jr] = b[i__ + (j + m1) * b_dim1] - w2[i__ + jr];
	    }
/* L140: */
	}
/* --- x2 = (b2 - a21 x1) a22^-1 --- */
	dgemm_("N", "N", nb, &m2, &m2, &c_b30, &w2[1], nb, &a[m1 + 1 + (m1 + 
		1) * a_dim1], lda, &c_b31, &b[(m1 + 1) * b_dim1 + 1], ldb, 1L,
		 1L);
/*     call yprm(.false.,'b a^-1',1,6,fmt,br,ldb,nb,ldb,n) */
    }
/* #ifdefC DEBUG */
/*      print 333, 'exiting dqinvb ',nlev,n,m1,m2 */
/*  333 format(1x,a,': nlev=',i1,'  ndim=',i4,' partitioned into',2i4) */
/* #endif */
    return 0;

L_dqnvb0:
    if (*isw > 0) {
	nmin = *nmin0;
    } else {
	*nmin0 = nmin;
    }
} /* dqinvb_ */

/* Subroutine */ int dqinvb_(cs, a, lda, nlev, n, nb, w, ldw, w2, b, ldb, 
	ierr, cs_len)
char *cs;
doublereal *a;
integer *lda, *nlev, *n, *nb;
doublereal *w;
integer *ldw;
doublereal *w2, *b;
integer *ldb, *ierr;
ftnlen cs_len;
{
    return dqinvb_0_(0, cs, a, lda, nlev, n, nb, w, ldw, w2, b, ldb, ierr, (
	    integer *)0, (integer *)0, cs_len);
    }

/* Subroutine */ int dqnvb0_(nmin0, isw)
integer *nmin0, *isw;
{
    return dqinvb_0_(1, (char *)0, (doublereal *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (doublereal *)0, (integer *)0, (
	    doublereal *)0, (doublereal *)0, (integer *)0, (integer *)0, 
	    nmin0, isw, (ftnint)0);
    }

