    /*        Fast GEMM routine for Alpha 21164/21264      */
    /*         on  Linux, Digital UNIX                     */
    /*        by Kazushige Goto <goto@statabo.rim.or.jp>   */

#ifndef VERSION_H
#define VERSION_H

#define VERSION "   Fast GEMM routine for Alpha 21164/21264\n"\
                "       on  Linux, Digital UNIX\n"\
                "                          date : 2000.04.04\n"\
                "     by Kazushige Goto <goto@statabo.rim.or.jp>"
#endif
