    /*        (NOT) Fast GEMV routine for Alpha 21164(A)   */
    /*         on  Linux, Digital UNIX and NT              */
    /*                         date : 98.11.02             */
    /*        by Kazushige Goto <goto@statabo.rim.or.jp>   */

    /*                 This is too slow like a turtle ;-)  */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

#define ONE  1.000e00
#define ZERO 0.000e00

#define MAX(a,b)  ((a)>(b)? (a):(b))

#ifdef DOUBLE
#define GEMV      dgemv_
#define GEMV_N    dgemv_n
#define GEMV_NY   dgemv_ny
#define GEMV_NX   dgemv_nx
#define GEMV_NXY  dgemv_nxy
#define GEMV_T    dgemv_t
#define GEMV_TY   dgemv_ty
#define GEMV_TX   dgemv_tx
#define GEMV_TXY  dgemv_txy
#define FLOAT double
#else
#define GEMV      sgemv_
#define GEMV_N    sgemv_n
#define GEMV_NY   sgemv_ny
#define GEMV_NX   sgemv_nx
#define GEMV_NXY  sgemv_nxy
#define GEMV_T    sgemv_t
#define GEMV_TY   sgemv_ty
#define GEMV_TX   sgemv_tx
#define GEMV_TXY  sgemv_txy
#define FLOAT float
#endif

void GEMV_N(int m, int n, FLOAT alpha, 
	     FLOAT *a, int lda, FLOAT *x, FLOAT *y);

void GEMV_NY(int m, int n, FLOAT alpha, 
	     FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incy);

void GEMV_NX(int m, int n, FLOAT alpha, 
	     FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incx);

void GEMV_NXY(int m, int n, FLOAT alpha, 
	     FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incx, int incy);

void GEMV_T(int m, int n, FLOAT alpha, 
	     FLOAT *a, int lda, FLOAT *x, FLOAT *y);

void GEMV_TY(int m, int n, FLOAT alpha, 
	     FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incy);

void GEMV_TX(int m, int n, FLOAT alpha, 
	     FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incx);

void GEMV_TXY(int m, int n, FLOAT alpha, 
	     FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incx, int incy);


void GEMV(char *TRANS, int *M, int *N,
	   FLOAT *ALPHA, FLOAT *a, int *LDA,
	   FLOAT *x, int *INCX,
	   FLOAT *BETA, FLOAT *y, int *INCY){

#ifndef TEST
  extern int xerbla_();
#endif
  char trans = toupper(*TRANS);
  int  m     = *M;
  int  n     = *N;
  int  lda   = *LDA;
  int  incx  = *INCX;
  int  incy  = *INCY;
  FLOAT alpha = *ALPHA;
  FLOAT beta  = *BETA;

  int lenx, leny;
  int i;

  int info = 0;

  if ((trans != 'N') && (trans != 'T') && (trans != 'C')) info = 1;
  else 
    if (m < 0) info = 2;
  else 
    if (n < 0) info = 3;
  else
    if (lda < MAX(1, m)) info = 6;
  else
    if (incx == 0) info = 8;
  else
    if (incy == 0) info = 11;

  if (info){
#ifndef TEST
#ifdef DOUBLE
    xerbla_("DGEMV ", &info, 6L);
#else
    xerbla_("SGEMV ", &info, 6L);
#endif
#else
    printf(
#ifdef DOUBLE
	    " ** On entry to DGEMV : parameter number %2d had an illegal value", info);
#else
	    " ** On entry to SGEMV : parameter number %2d had an illegal value", info);
#endif
#endif
    exit(0);
  }

  if ((m==0) || (n==0) || ((alpha==ZERO)&&(beta==ONE))) return;

  if (trans == 'N'){
    lenx = n;
    leny = m;
  }else{
    lenx = m;
    leny = n;
  }

  if (incx < 0) x -= (lenx-1)*incx;
  if (incy < 0) y -= (leny-1)*incy;

  if (beta != ONE){
    if (incy == 1){
      if (beta == ZERO){
	for (i=0; i < leny; i++) y[i] = ZERO;
      }else{
	for (i=0; i < leny; i++) y[i] *= beta;
      }
    }else{
      if (beta == ZERO){
	for (i=0; i < leny; i++) y[i*incy] = ZERO;
      }else{
	for (i=0; i < leny; i++) y[i*incy] *= beta;
      }
    }
  }      
  
  if (alpha == ZERO) return;
  
  if (trans == 'N'){
    /*  Form y := alpha*A*x + y  */
    if (incy == 1){
      if (incx ==1){
	GEMV_N(m, n, alpha, a, lda, x, y);
      } else {
	GEMV_NX(m, n, alpha, a, lda, x, y, incx);
      }
    } else {  /* incy != 1 */
      if (incx == 1){
	GEMV_NY(m, n, alpha, a, lda, x, y, incy);
      }else{
	GEMV_NXY(m, n, alpha, a, lda, x, y, incx, incy);
      }
    }
  }else{
    /*  Form y := alpha*A'*x + y  */
    if (incx == 1){
      if (incy == 1){
	GEMV_T(m, n, alpha, a, lda, x, y);
      }else{
	GEMV_TY(m, n, alpha, a, lda, x, y, incy);
      }
    } else {
      if (incy ==1){
	GEMV_TX(m, n, alpha, a, lda, x, y, incx);
      }else{
	GEMV_TXY(m, n, alpha, a, lda, x, y, incx, incy);
      }
    }
  }
  return;
}
