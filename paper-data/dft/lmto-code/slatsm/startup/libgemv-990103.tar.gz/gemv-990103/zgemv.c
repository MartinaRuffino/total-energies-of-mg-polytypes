    /*        Not so Fast ZGEMV routine for Alpha          */
    /*             Linux, Digital UNIX and NT/Alpha        */
    /*                         date : 99.01.03             */
    /*        by Kazushige Goto <goto@statabo.rim.or.jp>   */

#ifdef TEST
#include <stdio.h>
#endif

#include <ctype.h>

#define ZERO 0.0000
#define ONE  1.0000
#define MAX(a,b)  ((a)>(b)? (a):(b))

#ifdef DOUBLE
#define FLOAT  double
#define GEMV_    zgemv_
#define GEMV_N   zgemv_n
#define GEMV_NY  zgemv_ny
#define GEMV_NX  zgemv_nx
#define GEMV_NXY zgemv_nxy
#define GEMV_T   zgemv_t
#define GEMV_TY  zgemv_ty
#define GEMV_TX  zgemv_tx
#define GEMV_TXY zgemv_txy
#define GEMV_C   zgemv_c
#define GEMV_CY  zgemv_cy
#define GEMV_CX  zgemv_cx
#define GEMV_CXY zgemv_cxy
#define GEMV_I   zgemv_init

#else

#define FLOAT  float
#define GEMV_    cgemv_
#define GEMV_N   cgemv_n
#define GEMV_NY  cgemv_ny
#define GEMV_NX  cgemv_nx
#define GEMV_NXY cgemv_nxy
#define GEMV_T   cgemv_t
#define GEMV_TY  cgemv_ty
#define GEMV_TX  cgemv_tx
#define GEMV_TXY cgemv_txy
#define GEMV_C   cgemv_c
#define GEMV_CY  cgemv_cy
#define GEMV_CX  cgemv_cx
#define GEMV_CXY cgemv_cxy
#define GEMV_I   cgemv_init
#endif

int GEMV_N (int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y);

int GEMV_NY(int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incy);

int GEMV_NX(int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incx);

int GEMV_NXY(int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incy, int incx);

int GEMV_T (int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y);

int GEMV_TY(int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incy);

int GEMV_TX(int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incx);

int GEMV_TXY(int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incy, int incx);

int GEMV_C (int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y);

int GEMV_CY(int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incy);

int GEMV_CX(int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incx);

int GEMV_CXY(int m, int n, FLOAT *alpha, 
	    FLOAT *a, int lda, FLOAT *x, FLOAT *y, int incy, int incx);

void GEMV_I(FLOAT *beta, FLOAT *y, int incy, int leny);

int GEMV_(char *TRANS, int *M, int *N,
	   FLOAT *alpha, FLOAT *a, int *LDA,
	   FLOAT *x, int *INCX,
	   FLOAT *beta,  FLOAT *y, int *INCY){

  int    info;
  int    lenx, leny;
#ifndef TEST
  extern int xerbla_();
#endif
  int    noconj;

  char trans = toupper(*TRANS);
  int m = *M;
  int n = *N;
  int lda = *LDA;
  int incx = *INCX;
  int incy = *INCY;

  FLOAT alpha_r = *(alpha+0);
  FLOAT alpha_i = *(alpha+1);

  FLOAT beta_r  = *(beta+0);
  FLOAT beta_i  = *(beta+1);

  info = 0;
  if (trans != 'N' && trans != 'T' && trans != 'C'){
    info = 1;
  } else if (m < 0) {
    info = 2;
  } else if (n < 0) {
    info = 3;
  } else if (lda < MAX(1,m)) {
    info = 6;
  } else if (incx == 0) {
    info = 8;
  } else if (incy == 0) {
    info = 11;
  }
  if (info != 0) {
#ifndef TEST
#ifdef DOUBLE
    xerbla_("ZGEMV ", &info, 6L);
#else
    xerbla_("CGEMV ", &info, 6L);
#endif
#else
    fprintf(stderr, "Error\n");
#endif
    return 0;
  }
  
  /*  Quick return if possible. */

  if (m == 0 || n == 0) return 0;

  noconj = (trans == 'T');
  
  /* Set  LENX  and  LENY, the lengths of the vectors x and y, and set */
  /* up the start points in  X  and  Y. */
  
  if (trans == 'N') {
    lenx = n;
    leny = m;
  } else {
    lenx = m;
    leny = n;
  }

  if (incx < 0) x -= (lenx - 1) * incx * 2;
  if (incy < 0) y -= (leny - 1) * incy * 2;
  
  /* Start the operations. In this version the elements of A are */
  /* accessed sequentially with one pass through A. */
  
  /* First form  y := beta*y. */
  
  if (beta_r != ONE || beta_i != ZERO) {
    GEMV_I(beta, y, incy, leny);
  }

  if (alpha_r == ZERO && alpha_i == ZERO) return 0;

  if (trans == 'N') {
    
    /* Form  y := alpha*A*x + y. */
    if (incy == 1) {
      if (incx == 1){
	GEMV_N(m, n, alpha, a, lda, x, y);
      }else{
	GEMV_NX(m, n, alpha, a, lda, x, y, incx);
      }
    } else {
      if (incx == 1){
	GEMV_NY(m, n, alpha, a, lda, x, y, incy);
      }else{
	GEMV_NXY(m, n, alpha, a, lda, x, y, incy, incx);
      }
    }
  } else {
    if (trans == 'T'){
      /* Form  y := alpha*A'*x + y. */
      if (incx == 1) {
	if (incy == 1){
	  GEMV_T(m, n, alpha, a, lda, x, y);
	}else{
	  GEMV_TY(m, n, alpha, a, lda, x, y, incy);
	}
      } else {
	if (incy == 1){
	  GEMV_TX(m, n, alpha, a, lda, x, y, incx);
	}else{
	  GEMV_TXY(m, n, alpha, a, lda, x, y, incy, incx);
	}
      }
    }
    else {
      /* Form  y := alpha*conjg( A' )*x + y. */
      if (incx == 1) {
	if (incy == 1){
	  GEMV_C(m, n, alpha, a, lda, x, y);
	}else{
	  GEMV_CY(m, n, alpha, a, lda, x, y, incy);
	}
      } else {
	if (incy == 1){
	  GEMV_CX(m, n, alpha, a, lda, x, y, incx);
	}else{
	  GEMV_CXY(m, n, alpha, a, lda, x, y, incy, incx);
	}
      }
    }
  }
  return 0;
}
