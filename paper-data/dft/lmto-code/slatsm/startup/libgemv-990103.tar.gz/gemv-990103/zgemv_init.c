    /*        Not so Fast ZGEMV routine for Alpha          */
    /*             Linux, Digital UNIX and NT/Alpha        */
    /*                         date : 99.01.03             */
    /*        by Kazushige Goto <goto@statabo.rim.or.jp>   */


#define ZERO 0.0000
#define ONE  1.0000

#ifdef DOUBLE
#define FLOAT  double
#define GEMV_I   zgemv_init
#else
#define FLOAT  float
#define GEMV_I   cgemv_init
#endif


void GEMV_I(FLOAT *beta, FLOAT *y, int incy, int leny){

  FLOAT temp_r, temp_i;
  FLOAT beta_r = *(beta + 0);
  FLOAT beta_i = *(beta + 1);

  int i, iy;

  if (incy == 1) {
    if (beta_r == ZERO && beta_i == ZERO) {
      for (i = 0; i < leny; i++) {
	y[i*2  ] = ZERO;
	y[i*2+1] = ZERO;
      }
    } else {
      for (i = 0; i < leny; i++) {
	temp_r = beta_r * y[i*2  ] - beta_i * y[i*2+1];
	temp_i = beta_r * y[i*2+1] + beta_i * y[i*2  ];
	y[i*2  ] = temp_r;
	y[i*2+1] = temp_i;
      }
    }
  } else {
    iy = 0;
    if (beta_r == ZERO && beta_i == ZERO) {
      for (i = 0; i < leny; i++) {
	y[iy*2  ] = ZERO;
	y[iy*2+1] = ZERO;
	iy += incy;
      }
    } else {
      for (i = 0; i < leny; i++) {
	temp_r = beta_r * y[iy*2  ] - beta_i * y[iy*2+1];
	temp_i = beta_r * y[iy*2+1] + beta_i * y[iy*2  ];
	y[iy*2  ] = temp_r;
	y[iy*2+1] = temp_i;
	iy += incy;
      }
    }
  }
}
