
    /*        Fast GEMM routine for Alpha                  */
    /*           Linux, Digital UNIX and NT/Alpha          */
    /*                         date : 98.09.27             */
    /*        by Kazushige Goto <goto@statabo.rim.or.jp>   */

#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "myhead.h"

int main(void){
  int start, stop;
  FLOAT *a, *b, *d;
#ifndef ONLY_NEW
  FLOAT *c;
#endif
  FLOAT alpha, beta;
  int i,j;
  int m, n, k;
  int lda, ldb, ldc;

  m = SIZE_M;
  n = SIZE_N;
  k = SIZE_K;

  lda = SIZE_M;
  ldb = SIZE_K;
  ldc = SIZE_M;

  alpha = ALPHA;
  beta  = BETA;

  if (( a=(FLOAT *)malloc(sizeof(FLOAT) * k * m)) == NULL){
      fprintf(stderr,"Out of Memory!!\n");exit(1);
    }
  if (( b=(FLOAT *)malloc(sizeof(FLOAT) * n * k)) == NULL){
      fprintf(stderr,"Out of Memory!!\n");exit(1);
    }
#ifndef ONLY_NEW
  if (( c=(FLOAT *)malloc(sizeof(FLOAT) * n * m)) == NULL){
      fprintf(stderr,"Out of Memory!!\n");exit(1);
    }
#endif
  if (( d=(FLOAT *)malloc(sizeof(FLOAT) * n * m)) == NULL){
      fprintf(stderr,"Out of Memory!!\n");exit(1);
    }

  srandom(getpid());

  for(i=0;i<k;i++) for(j=0;j<m;j++)
      a[i*m +j]= rand() / ((double) RAND_MAX + 1.0 )*10.0;
  for(i=0;i<n;i++) for(j=0;j<k;j++)
      b[i*k +j]= rand() / ((double) RAND_MAX + 1.0 )*10.0;
  for(i=0;i<n;i++) for(j=0;j<m;j++){
      d[i*k +j]= rand() / ((double) RAND_MAX + 1.0 )*10.0;

#ifndef ONLY_NEW
      c[i*k +j]=d[i*k+j];
#endif
    }

#ifndef ONLY_NEW
  start = realcc();
#ifndef C_VERSION
  GEMMC_(TRANSA, TRANSB, &m, &n, &k, &alpha, a, &lda, b, &ldb, &beta, c, &ldc);
#else
  GEMMC(TRANSA, TRANSB, m, n, k, alpha, a, lda, b, ldb, beta, c, ldc);
#endif

  stop = realcc();
  printf("Original :%8.3f MFLOPS(%6.3f sec)\n", 
	 mflops(SIZE_M, SIZE_N, SIZE_K, (double)(stop - start)),
	 getsecs((double)(stop - start)));

#endif
    
  start = realcc();
#ifndef C_VERSION
  GEMM_(TRANSA, TRANSB, &m, &n, &k, &alpha, a, &lda, b, &ldb, &beta, d, &ldc);
#else
  GEMM(TRANSA, TRANSB, m, n, k, alpha, a, lda, b, ldb, beta, d, ldc);
#endif
  stop = realcc();
  
  printf("New      :");

  printf("%8.3f MFLOPS(%6.3f sec)\n\n", 
	 mflops(SIZE_M, SIZE_N, SIZE_K, (double)(stop - start)),
	 getsecs((double)(stop - start)));

#ifndef ONLY_NEW
  for(i=0;i<n;i++){
    for(j=0;j<m;j++){
      if ((long)(c[i*m+j]*1000.0) != (long)(d[i*m+j]*1000.0)){
	printf("%3d %3d :%6.1f %6.1f\n", i,j, c[i*m +j], d[i*m+j]);
      }
    }
  }
#endif
     
     free(a);
     free(b);
#ifndef ONLY_NEW
     free(c);
#endif
     free(d);
     return 0;
}
