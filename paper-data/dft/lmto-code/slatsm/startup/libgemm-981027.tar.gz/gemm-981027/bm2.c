
    /*        Fast GEMM routine for Alpha                  */
    /*           Linux, Digital UNIX and NT/Alpha          */
    /*                         date : 98.09.27             */
    /*        by Kazushige Goto <goto@statabo.rim.or.jp>   */

#include <stdio.h>
#include <stdlib.h>
#include "common.h"

#undef  USE_CLOCK
#define USE_CLOCK

#include "myhead.h"

#define FASTCHECK
#undef CONSTCHECK

int main(void){

  FLOAT *a, *b, *c, *d;
  FLOAT alpha, beta;
  int i,j;
  int m, n, k;
  int lda, ldb, ldc;
  int errflag;
  int start, stop;

  lda = LDA;
  ldb = LDB;
  ldc = LDC;

  alpha = ALPHA;
  beta  = 2.0;

  if (( a=(FLOAT *)malloc(sizeof(FLOAT) * ldc * lda)) == NULL){
      fprintf(stderr,"Out of Memory!!\n");exit(1);
    }
  if (( b=(FLOAT *)malloc(sizeof(FLOAT) * ldb * ldc)) == NULL){
      fprintf(stderr,"Out of Memory!!\n");exit(1);
    }
  if (( c=(FLOAT *)malloc(sizeof(FLOAT) * ldb * lda)) == NULL){
      fprintf(stderr,"Out of Memory!!\n");exit(1);
    }
  if (( d=(FLOAT *)malloc(sizeof(FLOAT) * ldb * lda)) == NULL){
      fprintf(stderr,"Out of Memory!!\n");exit(1);
    }

#ifdef CONSTCHECK
  for(i=0;i<ldc;i++) for(j=0;j<lda;j++)
      a[i*lda +j]=i;
  for(i=0;i<ldb;i++) for(j=0;j<ldc;j++)
      b[i*ldb +j]=j;
#else
  for(i=0;i<ldc;i++) for(j=0;j<lda;j++)
      a[i*lda +j]=rand() / ((FLOAT) RAND_MAX + 1.0 )*10.0;
  for(i=0;i<ldb;i++) for(j=0;j<ldc;j++)
      b[i*ldb +j]=rand() / ((FLOAT) RAND_MAX + 1.0 )*10.0;
#endif

  for (m=1; m<=M_MAX; m++){
    for (n=1; n<=N_MAX; n++){
      for (k=1; k<=K_MAX; k++){

#ifdef FASTCHECK
	m=k+3;
	n=k+5;
#endif

#ifdef CONSTCHECK
	for(i=0;i<ldb;i++) for(j=0;j<lda;j++){
	  c[i*ldc +j]=0.0;
	  d[i*ldc +j]=0.0;
	}
#else
	for(i=0;i<ldb;i++) for(j=0;j<lda;j++){
	  c[i*ldc +j]=rand() / ((FLOAT) RAND_MAX + 1.0 )*10.0;
	  d[i*ldc +j]=c[i*ldc+j];
	}
#endif

	printf("m:%3d n:%3d k:%3d", m, n, k);

#ifndef C_VERSION
	GEMMC_(TRANSA, TRANSB, &m, &n, &k,
		&alpha, a, &lda, b, &ldb, &beta, c, &ldc);
#else
	GEMMC(TRANSA, TRANSB, m, n, k, alpha, a, lda, b, ldb, beta, c, ldc);
#endif
	start = realcc();
#ifndef C_VERSION
        GEMM_(TRANSA, TRANSB, &m, &n, &k,
	       &alpha, a, &lda, b, &ldb, &beta, d, &ldc);
#else
	GEMM(TRANSA, TRANSB, m, n, k, alpha, a, lda, b, ldb, beta, d, ldc);
#endif
	stop = realcc();
	printf(":%8.3f MFLOPS(%6.3f sec)\n", 
	 mflops(m, n, k, stop-start), getsecs(stop-start));


#if 0
	for(i=0;i<m;i++){
	  for(j=0;j<k;j++){
	    printf("%6.2f ", a[j+i*lda]);
	  }
	  printf("\n");
	}
	printf("\n");

	for(i=0;i<k;i++){
	  for(j=0;j<n;j++){
	    printf("%6.2f ", b[j+i*ldb]);
	  }
	  printf("\n");
	}
	printf("\n");

	for(i=0;i<m;i++){
	  for(j=0;j<n;j++){
	    printf("%6.2f ", c[j+i*ldb]);
	  }
	  printf("\n");
	}
	printf("\n");

	for(i=0;i<10;i++){
	  for(j=0;j<10;j++){
	    printf("%6.2f ", d[j+i*ldc]);
	  }
	  printf("\n");
	}
	exit(1);
#endif

#if 1
      errflag = 0;

      for(i=0;i<ldb;i++){
	for(j=0;j<lda;j++){
	  if ((long)(c[i*ldc+j]*1000.0) != (long)(d[i*ldc+j]*1000.0)){
	    printf("%3d %3d :%e %e\n", i,j, c[i*ldc +j], d[i*ldc+j]);
	    errflag = 1;
	  }
	}
      }
#endif

      if (errflag){
	printf("operation aborted. M is %d\n", m);
	exit(1);
      }
    }
  }
}
  free(a);free(b);free(c);free(d);
  return 0;
}
