
    /*        Fast  GEMM routine for Alpha                 */
    /*           Linux, Digital UNIX and NT/Alpha          */
    /*                         date : 98.09.27             */
    /*        by Kazushige Goto <goto@statabo.rim.or.jp>   */

#ifdef C_VERSION

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "common.h"

/* Check routine */

static void dgemmc_nn(int m, int n, int k, FLOAT alpha, FLOAT *a,
	      int lda, FLOAT *b, int ldb,
	      FLOAT *c, int ldc){

  int x,y,l;

  for (y=0; y<m; y++){
    for (x=0; x<n; x++){
      for (l=0; l<k; l++){
	c[x+y*ldc] += alpha*a[l+y*lda]*b[x+l*ldb];
      }
    }
  }
}

static void dgemmc_nt(int m, int n, int k, FLOAT alpha, FLOAT *a,
	      int lda, FLOAT *b, int ldb,
	      FLOAT *c, int ldc){

  int x,y,l;

  for (y=0; y<m; y++){
    for (x=0; x<n; x++){
      for (l=0; l<k; l++){
	c[x+y*ldc] += alpha*a[l+y*lda]*b[l+x*ldb];
      }
    }
  }
}

static void dgemmc_tn(int m, int n, int k, FLOAT alpha, FLOAT *a,
	      int lda, FLOAT *b, int ldb,
	      FLOAT *c, int ldc){

  int x,y,l;

  for (y=0; y<m; y++){
    for (x=0; x<n; x++){
      for (l=0; l<k; l++){
	c[x+y*ldc] += alpha*a[y+l*lda]*b[x+l*ldb];
      }
    }
  }
}

static void dgemmc_tt(int m, int n, int k, FLOAT alpha, FLOAT *a,
	      int lda, FLOAT *b, int ldb,
	      FLOAT *c, int ldc){

  int x,y,l;

  for (y=0; y<m; y++){
    for (x=0; x<n; x++){
      for (l=0; l<k; l++){
	c[x+y*ldc] += alpha*a[y+l*lda]*b[l+x*ldb];
      }
    }
  }
}


#define ZERO 0.0000
#define ONE  1.0000

/*     C := alpha * A x B + beta * C */

void GEMMC(char *TRANSA, char *TRANSB,
	    int m, int n, int k,
	    FLOAT alpha,
	    FLOAT *a, int lda,
	    FLOAT *b, int ldb,
	    FLOAT beta,
	    FLOAT *c, int ldc){
    
  int nota, notb, i, j, nrowa, nrowb;

  char transA, transB;
  FLOAT *c_offset, *cc_offset;

  FLOAT atemp1, atemp2, atemp3, atemp4;
  FLOAT atemp5, atemp6, atemp7, atemp8;
  FLOAT btemp1, btemp2, btemp3, btemp4;
  FLOAT btemp5, btemp6, btemp7, btemp8;

  int min_i, min_l;

  transA = *TRANSA;
  transB = *TRANSB;

  transA = toupper(transA);
  transB = toupper(transB);

  nota = (transA=='N');
  notb = (transB=='N');

#if 0
printf("Information   M = %d, N = %d, K = %d\n", m,n,k);
printf("              Alpha = %f, Beta = %f  ", alpha, beta);
printf("TransA:%c  TransB:%c \n", transA, transB);
#endif

  if (nota) nrowa = m; else nrowa = k;
  if (notb) nrowb = k; else nrowb = n;

  if (alpha == ZERO){
    if (beta == ZERO)
      for (j=0;j<n;j++)
	for(i=0;i<m;i++) c[ldc*j+i] = ZERO;
    else
      for (j=0;j<n;j++)
	for(i=0;i<m;i++) c[ldc*j+i] = beta*c[ldc*j+i];
    return;
  }
  
  cc_offset = c;
  min_i = (m>>3);
  min_l = (m &7);

  if (beta == ZERO){
    for (j = 0; j < n; j++) {
      c_offset = cc_offset;
      for (i = 0; i < min_i; i++) {
	*(c_offset+0) = ZERO;
	*(c_offset+1) = ZERO;
	*(c_offset+2) = ZERO;
	*(c_offset+3) = ZERO;
	*(c_offset+4) = ZERO;
	*(c_offset+5) = ZERO;
	*(c_offset+6) = ZERO;
	*(c_offset+7) = ZERO;
	c_offset +=8;
      }
      for (i = 0; i < min_l; i++) {
	*c_offset = ZERO;
	c_offset ++;
      }
      cc_offset += ldc;
    }
  } else{
    if(beta != ONE){
      for (j = 0; j < n; j++) {
	c_offset = cc_offset;
	for (i = 0; i < min_i; i++) {
	  atemp1 = *(c_offset+0);
	  atemp2 = *(c_offset+1);
	  atemp3 = *(c_offset+2);
	  atemp4 = *(c_offset+3);
	  atemp5 = *(c_offset+4);
	  atemp6 = *(c_offset+5);
	  atemp7 = *(c_offset+6);
	  atemp8 = *(c_offset+7);

	  btemp1 = beta * atemp1;
	  btemp2 = beta * atemp2;
	  btemp3 = beta * atemp3;
	  btemp4 = beta * atemp4;
	  btemp5 = beta * atemp5;
	  btemp6 = beta * atemp6;
	  btemp7 = beta * atemp7;
	  btemp8 = beta * atemp8;

	  *(c_offset+0) = btemp1;
	  *(c_offset+1) = btemp2;
	  *(c_offset+2) = btemp3;
	  *(c_offset+3) = btemp4;
	  *(c_offset+4) = btemp5;
	  *(c_offset+5) = btemp6;
	  *(c_offset+6) = btemp7;
	  *(c_offset+7) = btemp8;
	  c_offset +=8;
	}
	for (i = 0; i < min_l; i++) {
	  *c_offset = beta * *c_offset;
	  c_offset ++;
	}
	cc_offset += ldc;
      }
    }
  }

  if (notb) {
    if (nota) {
      dgemmc_nn(m, n, k, alpha, a, lda, b, ldb, c, ldc);
    }
    else {
      dgemmc_tn(m, n, k, alpha, a, lda, b, ldb, c, ldc);
    }
  }  
  else {
    if (nota) {
      dgemmc_nt(m, n, k, alpha, a, lda, b, ldb, c, ldc);
    } 
    else {
      dgemmc_tt(m, n, k, alpha, a, lda, b, ldb, c, ldc);
    }  
  }
  return;
}

#endif
