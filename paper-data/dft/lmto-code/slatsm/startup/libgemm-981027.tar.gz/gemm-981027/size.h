
    /*        Fast GEMM routine for Alpha                  */
    /*           Linux, Digital UNIX and NT/Alpha          */
    /*                         date : 98.09.27             */
    /*        by Kazushige Goto <goto@statabo.rim.or.jp>   */


#define LDA    500
#define LDB    500
#define LDC    500

#define SIZE 1000

#if 1
#define SIZE_M SIZE
#define SIZE_N SIZE
#define SIZE_K SIZE
#else
#define SIZE_M 9
#define SIZE_N 9
#define SIZE_K 8
#endif

#define M_MAX 200
#define N_MAX 200
#define K_MAX 200

