
    /*        Fast GEMM routine for Alpha                  */
    /*           Linux, Digital UNIX and NT/Alpha          */
    /*                         date : 98.09.27             */
    /*        by Kazushige Goto <goto@statabo.rim.or.jp>   */

#ifndef MYHEAD_H
#define MYHEAD_H

#include <sys/times.h>
#include <time.h>
#include "common.h"

#include "size.h"

#ifdef USE_CLOCK
#define CLOCK (1.0/600.0e6)
#else
#define CLOCK 0.001
#endif

#ifndef USE_CLOCK
static inline int realcc(){
  struct tms usage_time;
  times(&usage_time);
  return usage_time.tms_utime;
}
#else
#ifndef VIRTUAL
static inline unsigned int realcc(void){
  unsigned long cc;

  asm volatile("rpcc %0" : "=r"(cc)
	       : : "memory");
  return cc;
}
#else
static inline unsigned int realcc(void){
  unsigned long cc;

  asm volatile("rpcc %0" : "=r"(cc)
	       : : "memory");
  return (cc + (cc<<32)) >>32;
}
#endif
#endif

static inline double getsecs(double count){
  return CLOCK*count;
}

static inline double mflops(int m, int n, int k, double count){
  return 2.0 * m * n * k /getsecs(count) *1.0e-6;
}

#ifndef C_VERSION

void GEMMC_(char *transA, char *transB, int *m, int *n, int *k,
	FLOAT *alpha, FLOAT *a, int *lda, FLOAT *b, int *ldb,
	FLOAT *beta, FLOAT *c, int *ldc);

void GEMM_(char *transA, char *transB, int *m, int *n, int *k,
	FLOAT *alpha, FLOAT *a, int *lda, FLOAT *b, int *ldb,
	FLOAT *beta, FLOAT *c, int *ldc);

#else

void GEMMC(char *transA, char *transB, int m, int n, int k,
	FLOAT alpha, FLOAT *a, int lda, FLOAT *b, int ldb,
	FLOAT beta, FLOAT *c, int ldc);

void GEMM(char *transA, char *transB, int m, int n, int k,
	FLOAT alpha, FLOAT *a, int lda, FLOAT *b, int ldb,
	FLOAT beta, FLOAT *c, int ldc);
#endif

#endif
