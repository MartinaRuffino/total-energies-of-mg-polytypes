
    /*        Fast GEMM routine for Alpha                  */
    /*           Linux, Digital UNIX and NT/Alpha          */
    /*                         date : 98.09.27             */
    /*        by Kazushige Goto <goto@statabo.rim.or.jp>   */

#include <stdio.h>
#include <stdlib.h>
#include "common.h"

#ifndef USE_CLOCK
#define USE_CLOCK
#endif

#include "myhead.h"

int main(void){

  FLOAT *a, *b, *c;
  FLOAT alpha, beta;
  int i,j;
  int m, n, k, h;
  int lda, ldb, ldc;
  int start, stop;
  FLOAT mf;

  lda = LDA;
  ldb = LDB;
  ldc = LDC;

  alpha = ALPHA;
  beta  = BETA;

  if (( a=(FLOAT *)malloc(sizeof(FLOAT) * ldc * lda)) == NULL){
      fprintf(stderr,"Out of Memory!!\n");exit(1);
    }
  if (( b=(FLOAT *)malloc(sizeof(FLOAT) * ldb * ldc)) == NULL){
      fprintf(stderr,"Out of Memory!!\n");exit(1);
    }
  if (( c=(FLOAT *)malloc(sizeof(FLOAT) * ldb * lda)) == NULL){
      fprintf(stderr,"Out of Memory!!\n");exit(1);
    }

#ifdef CONSTCHECK
  for(i=0;i<ldc;i++) for(j=0;j<lda;j++)
      a[i*lda +j]=i;
  for(i=0;i<ldb;i++) for(j=0;j<ldc;j++)
      b[i*ldb +j]=j;
#else
  for(i=0;i<ldc;i++) for(j=0;j<lda;j++)
      a[i*lda +j]=rand() / ((FLOAT) RAND_MAX + 1.0 )*10.0;
  for(i=0;i<ldb;i++) for(j=0;j<ldc;j++)
      b[i*ldb +j]=rand() / ((FLOAT) RAND_MAX + 1.0 )*10.0;
#endif

  h = 128;

  for (m=h; m<=M_MAX; m+=4){
    for (n=h; n<=N_MAX; n+=4){
      for (k=h; k<=K_MAX; k+=4){

#ifdef FASTCHECK
	m=k;
	n=k;
#endif

#ifdef CONSTCHECK
	for(i=0;i<ldb;i++) for(j=0;j<lda;j++){
	  c[i*ldc +j]=1.0;
	}
#else
	for(i=0;i<ldb;i++) for(j=0;j<lda;j++){
	  c[i*ldc +j]=rand() / ((FLOAT) RAND_MAX + 1.0 )*10.0;
	}
#endif

	i=0;
	  printf("m:%4d n:%4d k:%4d :", m, n, k);

	do{
	  start = realcc();	
#ifndef C_VERSION
	  GEMM_("No Transposed", "No Transposed", &h, &h, &h,
		 &alpha, a, &m, b, &n, &beta, c, &k);
#else
	  GEMM("No Transposed", "No Transposed", h, h, h,
		 alpha, a, m, b, n, beta, c, k);
#endif

	  stop = realcc();

	  mf = mflops(h, h, h, stop-start);

	  printf("%8.3fMFlops", mf);

	  i++;
	}while((mf<500.0) && (i<5));
 	if (mf < 500.0)  printf(" <-- check!!");
	printf("\n");

    }
  }
}
  free(a);free(b);free(c);
  return 0;
}
